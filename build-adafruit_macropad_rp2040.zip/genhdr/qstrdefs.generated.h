// # words 127
// words ['er', '%q', 'in', 'e ', '\r\n', 'on', 'or', 'mp', ', ', 're', '()', 'it', 'st', '%d', 'at', 'ex', 'en', 'le', '16', 'up', 'ha', 'ing', ' %d', 'out', 'or ', ' is', 'equ', 'oun', 'ed ', 'an ', 'arg', 'put', 'No ', 'all', 'ent', 'ly ', 'PWM', 'tim', 'mat', ' th', 'mod', 'al ', 'ect', 'set', 'USB', 'lic', 'ack', 'col', 'tion', ' for', ' of ', 'byte', 'type', 'able', 'xxxx', ' to ', 'func', 'rang', ' siz', 'and ', 'ould', 'sign', 'not ', 'HCI ', 'file', 'numb', ' use', "'%s'", "n't ", 'ight', 'lock', 'UUID', ' not ', 'array', 'uffer', 'value', ' with', 'match', 'valid', 'first', 'xpect', ' too ', 'given', 'when ', 'from ', '65536', 'pixel', ' does', 'avail', 'sourc', 'alarm', 'length', 'object', 'nvalid', "can't ", ' must ', 'annot ', 'bitmap', ' devic', 'isplay', 'must b', 'haract', 'rogram', 'tribut', 'provid', 'nknown', 'keyword', 'specifi', 'Instruc', 'ttribut', 'already', 'channel', 'default', 'aximum ', 'SD card', 'argument', ' require', 'multiple', 'oo many ', 'subclass', ' must be ', 'supported', 'CIRCUITPY', ' should be ', 'implemented', 'WatchDogTim', 'CircuitPyth']
// 32   1319 000 0
// 115 s 655 0010 2
// 97 a 421 00110 6
// 99 c 325 00111 7
// 100 d 378 01000 8
// 101 e 399 01001 9
// 105 i 348 01010 10
// 111 o 307 01011 11
// 116 t 347 01100 12
// 98 b 145 011010 26
// 131 e  278 011011 27
// 128 er 213 011100 28
// 102 f 183 011101 29
// 130 in 265 011110 30
// 108 l 171 011111 31
// 109 m 168 100000 32
// 110 n 206 100001 33
// 133 on 216 100010 34
// 112 p 253 100011 35
// 114 r 205 100100 36
// 117 u 163 100101 37
// 248  must be  117 1001100 76
// 200  not  77 1001101 77
// 129 %q 75 1001110 78
// 39 \' 119 1001111 79
// 46 . 100 1010000 80
// 95 _ 82 1010001 81
// 142 at 123 1010010 82
// 156 ed  76 1010011 83
// 103 g 85 1010100 84
// 104 h 109 1010101 85
// 149 ing 75 1010110 86
// 139 it 109 1010111 87
// 145 le 100 1011000 88
// 134 or 85 1011001 89
// 152 or  80 1011010 90
// 137 re 121 1011011 91
// 140 st 105 1011100 92
// 118 v 85 1011101 93
// 119 w 89 1011110 94
// 121 y 101 1011111 95
// 150  %d 43 11000000 192
// 177  for 45 11000001 193
// 153  is 62 11000010 194
// 178  of  62 11000011 195
// 167  th 38 11000100 196
// 183  to  47 11000101 197
// 136 ,  67 11000110 198
// 45 - 49 11000111 199
// 48 0 51 11001000 200
// 66 B 37 11001001 201
// 67 C 56 11001010 202
// 73 I 50 11001011 203
// 84 T 44 11001100 204
// 157 an  55 11001101 205
// 243 argument 49 11001110 206
// 201 array 45 11001111 207
// 144 en 50 11010000 208
// 162 ent 41 11010001 209
// 143 ex 47 11010010 210
// 148 ha 41 11010011 211
// 219 length 46 11010100 212
// 135 mp 50 11010101 213
// 151 out 65 11010110 214
// 176 tion 46 11010111 215
// 120 x 61 11011000 216
// 132 \r\n 31 110110010 434
// 223  must  19 110110011 435
// 194  use 21 110110100 436
// 204  with 19 110110101 437
// 141 %d 29 110110110 438
// 40 ( 28 110110111 439
// 41 ) 28 110111000 440
// 47 / 19 110111001 441
// 49 1 29 110111010 442
// 50 2 28 110111011 443
// 58 : 22 110111100 444
// 61 = 23 110111101 445
// 65 A 32 110111110 446
// 68 D 30 110111111 447
// 69 E 24 111000000 448
// 70 F 19 111000001 449
// 77 M 32 111000010 450
// 78 N 19 111000011 451
// 160 No  22 111000100 452
// 79 O 23 111000101 453
// 80 P 32 111000110 454
// 82 R 27 111000111 455
// 83 S 35 111001000 456
// 85 U 19 111001001 457
// 181 able 34 111001010 458
// 169 al  34 111001011 459
// 161 all 34 111001100 460
// 187 and  23 111001101 461
// 224 annot  22 111001110 462
// 158 arg 27 111001111 463
// 179 byte 34 111010000 464
// 222 can\'t  19 111010001 465
// 170 ect 24 111010010 466
// 184 func 20 111010011 467
// 107 k 29 111010100 468
// 163 ly  28 111010101 469
// 166 mat 29 111010110 470
// 168 mod 20 111010111 471
// 220 object 24 111011000 472
// 155 oun 32 111011001 473
// 159 put 31 111011010 474
// 171 set 24 111011011 475
// 249 supported 28 111011100 476
// 165 tim 25 111011101 477
// 180 type 36 111011110 478
// 202 uffer 34 111011111 479
// 147 up 36 111100000 480
// 203 value 28 111100001 481
// 122 z 19 111100010 482
// 226  devic 9 1111000110 966
// 215  does 11 1111000111 967
// 244  require 16 1111001000 968
// 186  siz 16 1111001001 969
// 209  too  17 1111001010 970
// 37 % 16 1111001011 971
// 138 () 15 1111001100 972
// 42 * 9 1111001101 973
// 146 16 11 1111001110 974
// 51 3 12 1111001111 975
// 52 4 13 1111010000 976
// 56 8 12 1111010001 977
// 62 > 12 1111010010 978
// 71 G 10 1111010011 979
// 236 Instruc 11 1111010100 980
// 76 L 16 1111010101 981
// 87 W 10 1111010110 982
// 174 ack 11 1111010111 983
// 225 bitmap 10 1111011000 984
// 175 col 15 1111011001 985
// 154 equ 17 1111011010 986
// 192 file 16 1111011011 987
// 207 first 13 1111011100 988
// 234 keyword 12 1111011101 989
// 173 lic 18 1111011110 990
// 205 match 16 1111011111 991
// 245 multiple 15 1111100000 992
// 196 n\'t  9 1111100001 993
// 190 not  17 1111100010 994
// 221 nvalid 11 1111100011 995
// 188 ould 14 1111100100 996
// 185 rang 17 1111100101 997
// 189 sign 12 1111100110 998
// 235 specifi 12 1111100111 999
// 206 valid 13 1111101000 1000
// 251  should be  9 11111010010 2002
// 34 \" 8 11111010011 2003
// 195 \'%s\' 6 11111010100 2004
// 54 6 6 11111010101 2005
// 60 < 6 11111010110 2006
// 72 H 9 11111010111 2007
// 191 HCI  7 11111011000 2008
// 164 PWM 8 11111011001 2009
// 172 USB 7 11111011010 2010
// 86 V 7 11111011011 2011
// 218 alarm 6 11111011100 2012
// 238 already 9 11111011101 2013
// 216 avail 7 11111011110 2014
// 241 aximum  5 11111011111 2015
// 239 channel 7 11111100000 2016
// 240 default 6 11111100001 2017
// 212 from  8 11111100010 2018
// 210 given 7 11111100011 2019
// 229 haract 9 11111100100 2020
// 197 ight 7 11111100101 2021
// 252 implemented 8 11111100110 2022
// 227 isplay 8 11111100111 2023
// 106 j 9 11111101000 2024
// 198 lock 7 11111101001 2025
// 228 must b 8 11111101010 2026
// 193 numb 8 11111101011 2027
// 246 oo many  8 11111101100 2028
// 214 pixel 7 11111101101 2029
// 232 provid 5 11111101110 2030
// 113 q 9 11111101111 2031
// 230 rogram 7 11111110000 2032
// 217 sourc 7 11111110001 2033
// 247 subclass 6 11111110010 2034
// 231 tribut 8 11111110011 2035
// 211 when  8 11111110100 2036
// 182 xxxx 8 11111110101 2037
// 33 ! 4 111111101100 4076
// 35 # 3 111111101101 4077
// 53 5 3 111111101110 4078
// 213 65536 3 111111101111 4079
// 57 9 3 111111110000 4080
// 59 ; 3 111111110001 4081
// 250 CIRCUITPY 3 111111110010 4082
// 254 CircuitPyth 4 111111110011 4083
// 242 SD card 4 111111110100 4084
// 199 UUID 4 111111110101 4085
// 253 WatchDogTim 4 111111110110 4086
// 89 Y 4 111111110111 4087
// 91 [ 3 111111111000 4088
// 93 ] 3 111111111001 4089
// 96 ` 4 111111111010 4090
// 233 nknown 4 111111111011 4091
// 43 + 2 1111111111000 8184
// 44 , 2 1111111111001 8185
// 88 X 2 1111111111010 8186
// 237 ttribut 2 1111111111011 8187
// 208 xpect 2 1111111111100 8188
// 55 7 1 11111111111010 16378
// 74 J 1 11111111111011 16379
// 75 K 1 11111111111100 16380
// 123 { 1 11111111111101 16381
// 125 } 1 11111111111110 16382
// 126 ~ 1 11111111111111 16383
// length count {3: 1, 4: 1, 5: 7, 6: 12, 7: 20, 8: 25, 9: 49, 10: 35, 11: 36, 12: 16, 13: 5, 14: 6}
// values [' ', 's', 'a', 'c', 'd', 'e', 'i', 'o', 't', 'b', 'e ', 'er', 'f', 'in', 'l', 'm', 'n', 'on', 'p', 'r', 'u', ' must be ', ' not ', '%q', "'", '.', '_', 'at', 'ed ', 'g', 'h', 'ing', 'it', 'le', 'or', 'or ', 're', 'st', 'v', 'w', 'y', ' %d', ' for', ' is', ' of ', ' th', ' to ', ', ', '-', '0', 'B', 'C', 'I', 'T', 'an ', 'argument', 'array', 'en', 'ent', 'ex', 'ha', 'length', 'mp', 'out', 'tion', 'x', '\r\n', ' must ', ' use', ' with', '%d', '(', ')', '/', '1', '2', ':', '=', 'A', 'D', 'E', 'F', 'M', 'N', 'No ', 'O', 'P', 'R', 'S', 'U', 'able', 'al ', 'all', 'and ', 'annot ', 'arg', 'byte', "can't ", 'ect', 'func', 'k', 'ly ', 'mat', 'mod', 'object', 'oun', 'put', 'set', 'supported', 'tim', 'type', 'uffer', 'up', 'value', 'z', ' devic', ' does', ' require', ' siz', ' too ', '%', '()', '*', '16', '3', '4', '8', '>', 'G', 'Instruc', 'L', 'W', 'ack', 'bitmap', 'col', 'equ', 'file', 'first', 'keyword', 'lic', 'match', 'multiple', "n't ", 'not ', 'nvalid', 'ould', 'rang', 'sign', 'specifi', 'valid', ' should be ', '"', "'%s'", '6', '<', 'H', 'HCI ', 'PWM', 'USB', 'V', 'alarm', 'already', 'avail', 'aximum ', 'channel', 'default', 'from ', 'given', 'haract', 'ight', 'implemented', 'isplay', 'j', 'lock', 'must b', 'numb', 'oo many ', 'pixel', 'provid', 'q', 'rogram', 'sourc', 'subclass', 'tribut', 'when ', 'xxxx', '!', '#', '5', '65536', '9', ';', 'CIRCUITPY', 'CircuitPyth', 'SD card', 'UUID', 'WatchDogTim', 'Y', '[', ']', '`', 'nknown', '+', ',', 'X', 'ttribut', 'xpect', '7', 'J', 'K', '{', '}', '~'] lengths 15 bytearray(b'\x00\x00\x01\x01\x07\x0c\x14\x191#$\x10\x05\x06\x00')
// [' ', 's', 'a', 'c', 'd', 'e', 'i', 'o', 't', 'b', 'e ', 'er', 'f', 'in', 'l', 'm', 'n', 'on', 'p', 'r', 'u', ' must be ', ' not ', '%q', "'", '.', '_', 'at', 'ed ', 'g', 'h', 'ing', 'it', 'le', 'or', 'or ', 're', 'st', 'v', 'w', 'y', ' %d', ' for', ' is', ' of ', ' th', ' to ', ', ', '-', '0', 'B', 'C', 'I', 'T', 'an ', 'argument', 'array', 'en', 'ent', 'ex', 'ha', 'length', 'mp', 'out', 'tion', 'x', '\r\n', ' must ', ' use', ' with', '%d', '(', ')', '/', '1', '2', ':', '=', 'A', 'D', 'E', 'F', 'M', 'N', 'No ', 'O', 'P', 'R', 'S', 'U', 'able', 'al ', 'all', 'and ', 'annot ', 'arg', 'byte', "can't ", 'ect', 'func', 'k', 'ly ', 'mat', 'mod', 'object', 'oun', 'put', 'set', 'supported', 'tim', 'type', 'uffer', 'up', 'value', 'z', ' devic', ' does', ' require', ' siz', ' too ', '%', '()', '*', '16', '3', '4', '8', '>', 'G', 'Instruc', 'L', 'W', 'ack', 'bitmap', 'col', 'equ', 'file', 'first', 'keyword', 'lic', 'match', 'multiple', "n't ", 'not ', 'nvalid', 'ould', 'rang', 'sign', 'specifi', 'valid', ' should be ', '"', "'%s'", '6', '<', 'H', 'HCI ', 'PWM', 'USB', 'V', 'alarm', 'already', 'avail', 'aximum ', 'channel', 'default', 'from ', 'given', 'haract', 'ight', 'implemented', 'isplay', 'j', 'lock', 'must b', 'numb', 'oo many ', 'pixel', 'provid', 'q', 'rogram', 'sourc', 'subclass', 'tribut', 'when ', 'xxxx', '!', '#', '5', '65536', '9', ';', 'CIRCUITPY', 'CircuitPyth', 'SD card', 'UUID', 'WatchDogTim', 'Y', '[', ']', '`', 'nknown', '+', ',', 'X', 'ttribut', 'xpect', '7', 'J', 'K', '{', '}', '~'] bytearray(b'\x00\x00\x01\x01\x07\x0c\x14\x191#$\x10\x05\x06\x00')
// This file was automatically generated by makeqstrdata.py

QDEF(MP_QSTRnull, 0, 0, "")
QDEF(MP_QSTR_, 5, 0, "")
QDEF(MP_QSTR___dir__, 122, 7, "__dir__")
QDEF(MP_QSTR__0x0a_, 175, 1, "\x0a")
QDEF(MP_QSTR__space_, 133, 1, " ")
QDEF(MP_QSTR__star_, 143, 1, "*")
QDEF(MP_QSTR__slash_, 138, 1, "/")
QDEF(MP_QSTR__lt_module_gt_, 189, 8, "<module>")
QDEF(MP_QSTR__, 250, 1, "_")
QDEF(MP_QSTR___call__, 167, 8, "__call__")
QDEF(MP_QSTR___class__, 43, 9, "__class__")
QDEF(MP_QSTR___delitem__, 253, 11, "__delitem__")
QDEF(MP_QSTR___enter__, 109, 9, "__enter__")
QDEF(MP_QSTR___exit__, 69, 8, "__exit__")
QDEF(MP_QSTR___getattr__, 64, 11, "__getattr__")
QDEF(MP_QSTR___getitem__, 38, 11, "__getitem__")
QDEF(MP_QSTR___hash__, 247, 8, "__hash__")
QDEF(MP_QSTR___init__, 95, 8, "__init__")
QDEF(MP_QSTR___int__, 22, 7, "__int__")
QDEF(MP_QSTR___iter__, 207, 8, "__iter__")
QDEF(MP_QSTR___len__, 226, 7, "__len__")
QDEF(MP_QSTR___main__, 142, 8, "__main__")
QDEF(MP_QSTR___module__, 255, 10, "__module__")
QDEF(MP_QSTR___name__, 226, 8, "__name__")
QDEF(MP_QSTR___new__, 121, 7, "__new__")
QDEF(MP_QSTR___next__, 2, 8, "__next__")
QDEF(MP_QSTR___qualname__, 107, 12, "__qualname__")
QDEF(MP_QSTR___repr__, 16, 8, "__repr__")
QDEF(MP_QSTR___setitem__, 50, 11, "__setitem__")
QDEF(MP_QSTR___str__, 208, 7, "__str__")
QDEF(MP_QSTR_ArithmeticError, 45, 15, "ArithmeticError")
QDEF(MP_QSTR_AssertionError, 151, 14, "AssertionError")
QDEF(MP_QSTR_AttributeError, 33, 14, "AttributeError")
QDEF(MP_QSTR_BaseException, 7, 13, "BaseException")
QDEF(MP_QSTR_EOFError, 145, 8, "EOFError")
QDEF(MP_QSTR_Ellipsis, 240, 8, "Ellipsis")
QDEF(MP_QSTR_Exception, 242, 9, "Exception")
QDEF(MP_QSTR_GeneratorExit, 22, 13, "GeneratorExit")
QDEF(MP_QSTR_ImportError, 32, 11, "ImportError")
QDEF(MP_QSTR_IndentationError, 92, 16, "IndentationError")
QDEF(MP_QSTR_IndexError, 131, 10, "IndexError")
QDEF(MP_QSTR_KeyError, 234, 8, "KeyError")
QDEF(MP_QSTR_KeyboardInterrupt, 175, 17, "KeyboardInterrupt")
QDEF(MP_QSTR_LookupError, 255, 11, "LookupError")
QDEF(MP_QSTR_MemoryError, 220, 11, "MemoryError")
QDEF(MP_QSTR_NameError, 186, 9, "NameError")
QDEF(MP_QSTR_NoneType, 23, 8, "NoneType")
QDEF(MP_QSTR_NotImplementedError, 198, 19, "NotImplementedError")
QDEF(MP_QSTR_OSError, 161, 7, "OSError")
QDEF(MP_QSTR_OverflowError, 129, 13, "OverflowError")
QDEF(MP_QSTR_RuntimeError, 97, 12, "RuntimeError")
QDEF(MP_QSTR_StopIteration, 234, 13, "StopIteration")
QDEF(MP_QSTR_SyntaxError, 148, 11, "SyntaxError")
QDEF(MP_QSTR_SystemExit, 32, 10, "SystemExit")
QDEF(MP_QSTR_TypeError, 37, 9, "TypeError")
QDEF(MP_QSTR_ValueError, 150, 10, "ValueError")
QDEF(MP_QSTR_ZeroDivisionError, 182, 17, "ZeroDivisionError")
QDEF(MP_QSTR_abs, 149, 3, "abs")
QDEF(MP_QSTR_all, 68, 3, "all")
QDEF(MP_QSTR_any, 19, 3, "any")
QDEF(MP_QSTR_append, 107, 6, "append")
QDEF(MP_QSTR_args, 194, 4, "args")
QDEF(MP_QSTR_bool, 235, 4, "bool")
QDEF(MP_QSTR_builtins, 247, 8, "builtins")
QDEF(MP_QSTR_bytearray, 118, 9, "bytearray")
QDEF(MP_QSTR_bytecode, 34, 8, "bytecode")
QDEF(MP_QSTR_bytes, 92, 5, "bytes")
QDEF(MP_QSTR_callable, 13, 8, "callable")
QDEF(MP_QSTR_chr, 220, 3, "chr")
QDEF(MP_QSTR_classmethod, 180, 11, "classmethod")
QDEF(MP_QSTR_clear, 124, 5, "clear")
QDEF(MP_QSTR_close, 51, 5, "close")
QDEF(MP_QSTR_const, 192, 5, "const")
QDEF(MP_QSTR_copy, 224, 4, "copy")
QDEF(MP_QSTR_count, 166, 5, "count")
QDEF(MP_QSTR_dict, 63, 4, "dict")
QDEF(MP_QSTR_dir, 250, 3, "dir")
QDEF(MP_QSTR_divmod, 184, 6, "divmod")
QDEF(MP_QSTR_end, 10, 3, "end")
QDEF(MP_QSTR_endswith, 27, 8, "endswith")
QDEF(MP_QSTR_eval, 155, 4, "eval")
QDEF(MP_QSTR_exec, 30, 4, "exec")
QDEF(MP_QSTR_extend, 99, 6, "extend")
QDEF(MP_QSTR_find, 1, 4, "find")
QDEF(MP_QSTR_format, 38, 6, "format")
QDEF(MP_QSTR_from_bytes, 53, 10, "from_bytes")
QDEF(MP_QSTR_get, 51, 3, "get")
QDEF(MP_QSTR_getattr, 192, 7, "getattr")
QDEF(MP_QSTR_globals, 157, 7, "globals")
QDEF(MP_QSTR_hasattr, 140, 7, "hasattr")
QDEF(MP_QSTR_hash, 183, 4, "hash")
QDEF(MP_QSTR_id, 40, 2, "id")
QDEF(MP_QSTR_index, 123, 5, "index")
QDEF(MP_QSTR_insert, 18, 6, "insert")
QDEF(MP_QSTR_int, 22, 3, "int")
QDEF(MP_QSTR_isalpha, 235, 7, "isalpha")
QDEF(MP_QSTR_isdigit, 168, 7, "isdigit")
QDEF(MP_QSTR_isinstance, 182, 10, "isinstance")
QDEF(MP_QSTR_islower, 252, 7, "islower")
QDEF(MP_QSTR_isspace, 91, 7, "isspace")
QDEF(MP_QSTR_issubclass, 181, 10, "issubclass")
QDEF(MP_QSTR_isupper, 221, 7, "isupper")
QDEF(MP_QSTR_items, 227, 5, "items")
QDEF(MP_QSTR_iter, 143, 4, "iter")
QDEF(MP_QSTR_join, 167, 4, "join")
QDEF(MP_QSTR_key, 50, 3, "key")
QDEF(MP_QSTR_keys, 1, 4, "keys")
QDEF(MP_QSTR_len, 98, 3, "len")
QDEF(MP_QSTR_list, 39, 4, "list")
QDEF(MP_QSTR_little, 137, 6, "little")
QDEF(MP_QSTR_locals, 59, 6, "locals")
QDEF(MP_QSTR_lower, 198, 5, "lower")
QDEF(MP_QSTR_lstrip, 229, 6, "lstrip")
QDEF(MP_QSTR_main, 206, 4, "main")
QDEF(MP_QSTR_map, 185, 3, "map")
QDEF(MP_QSTR_micropython, 11, 11, "micropython")
QDEF(MP_QSTR_next, 66, 4, "next")
QDEF(MP_QSTR_object, 144, 6, "object")
QDEF(MP_QSTR_open, 209, 4, "open")
QDEF(MP_QSTR_ord, 28, 3, "ord")
QDEF(MP_QSTR_pop, 42, 3, "pop")
QDEF(MP_QSTR_popitem, 191, 7, "popitem")
QDEF(MP_QSTR_pow, 45, 3, "pow")
QDEF(MP_QSTR_print, 84, 5, "print")
QDEF(MP_QSTR_range, 26, 5, "range")
QDEF(MP_QSTR_read, 183, 4, "read")
QDEF(MP_QSTR_readinto, 75, 8, "readinto")
QDEF(MP_QSTR_readline, 249, 8, "readline")
QDEF(MP_QSTR_remove, 99, 6, "remove")
QDEF(MP_QSTR_replace, 73, 7, "replace")
QDEF(MP_QSTR_repr, 208, 4, "repr")
QDEF(MP_QSTR_reverse, 37, 7, "reverse")
QDEF(MP_QSTR_rfind, 210, 5, "rfind")
QDEF(MP_QSTR_rindex, 233, 6, "rindex")
QDEF(MP_QSTR_round, 231, 5, "round")
QDEF(MP_QSTR_rsplit, 165, 6, "rsplit")
QDEF(MP_QSTR_rstrip, 59, 6, "rstrip")
QDEF(MP_QSTR_self, 121, 4, "self")
QDEF(MP_QSTR_send, 185, 4, "send")
QDEF(MP_QSTR_sep, 35, 3, "sep")
QDEF(MP_QSTR_set, 39, 3, "set")
QDEF(MP_QSTR_setattr, 212, 7, "setattr")
QDEF(MP_QSTR_setdefault, 108, 10, "setdefault")
QDEF(MP_QSTR_sort, 191, 4, "sort")
QDEF(MP_QSTR_sorted, 94, 6, "sorted")
QDEF(MP_QSTR_split, 183, 5, "split")
QDEF(MP_QSTR_start, 133, 5, "start")
QDEF(MP_QSTR_startswith, 116, 10, "startswith")
QDEF(MP_QSTR_staticmethod, 98, 12, "staticmethod")
QDEF(MP_QSTR_step, 87, 4, "step")
QDEF(MP_QSTR_stop, 157, 4, "stop")
QDEF(MP_QSTR_str, 80, 3, "str")
QDEF(MP_QSTR_strip, 41, 5, "strip")
QDEF(MP_QSTR_sum, 46, 3, "sum")
QDEF(MP_QSTR_super, 196, 5, "super")
QDEF(MP_QSTR_throw, 179, 5, "throw")
QDEF(MP_QSTR_to_bytes, 216, 8, "to_bytes")
QDEF(MP_QSTR_tuple, 253, 5, "tuple")
QDEF(MP_QSTR_type, 157, 4, "type")
QDEF(MP_QSTR_update, 180, 6, "update")
QDEF(MP_QSTR_upper, 39, 5, "upper")
QDEF(MP_QSTR_utf_hyphen_8, 183, 5, "utf-8")
QDEF(MP_QSTR_value, 78, 5, "value")
QDEF(MP_QSTR_values, 125, 6, "values")
QDEF(MP_QSTR_write, 152, 5, "write")
QDEF(MP_QSTR_zip, 230, 3, "zip")
QDEF(MP_QSTR___abs__, 149, 7, "__abs__")
QDEF(MP_QSTR___add__, 196, 7, "__add__")
QDEF(MP_QSTR___aenter__, 76, 10, "__aenter__")
QDEF(MP_QSTR___aexit__, 196, 9, "__aexit__")
QDEF(MP_QSTR___aiter__, 78, 9, "__aiter__")
QDEF(MP_QSTR___and__, 14, 7, "__and__")
QDEF(MP_QSTR___anext__, 131, 9, "__anext__")
QDEF(MP_QSTR___await__, 79, 9, "__await__")
QDEF(MP_QSTR___bases__, 3, 9, "__bases__")
QDEF(MP_QSTR___bool__, 43, 8, "__bool__")
QDEF(MP_QSTR___build_class__, 66, 15, "__build_class__")
QDEF(MP_QSTR___bytes__, 220, 9, "__bytes__")
QDEF(MP_QSTR___contains__, 198, 12, "__contains__")
QDEF(MP_QSTR___del__, 104, 7, "__del__")
QDEF(MP_QSTR___delete__, 220, 10, "__delete__")
QDEF(MP_QSTR___dict__, 127, 8, "__dict__")
QDEF(MP_QSTR___divmod__, 120, 10, "__divmod__")
QDEF(MP_QSTR___eq__, 113, 6, "__eq__")
QDEF(MP_QSTR___file__, 3, 8, "__file__")
QDEF(MP_QSTR___floordiv__, 70, 12, "__floordiv__")
QDEF(MP_QSTR___future__, 64, 10, "__future__")
QDEF(MP_QSTR___ge__, 167, 6, "__ge__")
QDEF(MP_QSTR___get__, 179, 7, "__get__")
QDEF(MP_QSTR___gt__, 182, 6, "__gt__")
QDEF(MP_QSTR___iadd__, 109, 8, "__iadd__")
QDEF(MP_QSTR___import__, 56, 10, "__import__")
QDEF(MP_QSTR___invert__, 247, 10, "__invert__")
QDEF(MP_QSTR___isub__, 8, 8, "__isub__")
QDEF(MP_QSTR___le__, 204, 6, "__le__")
QDEF(MP_QSTR___lshift__, 9, 10, "__lshift__")
QDEF(MP_QSTR___lt__, 93, 6, "__lt__")
QDEF(MP_QSTR___matmul__, 73, 10, "__matmul__")
QDEF(MP_QSTR___mod__, 99, 7, "__mod__")
QDEF(MP_QSTR___mul__, 49, 7, "__mul__")
QDEF(MP_QSTR___ne__, 14, 6, "__ne__")
QDEF(MP_QSTR___neg__, 105, 7, "__neg__")
QDEF(MP_QSTR___or__, 56, 6, "__or__")
QDEF(MP_QSTR___path__, 200, 8, "__path__")
QDEF(MP_QSTR___pos__, 41, 7, "__pos__")
QDEF(MP_QSTR___pow__, 45, 7, "__pow__")
QDEF(MP_QSTR___radd__, 22, 8, "__radd__")
QDEF(MP_QSTR___rand__, 220, 8, "__rand__")
QDEF(MP_QSTR___repl_print__, 1, 14, "__repl_print__")
QDEF(MP_QSTR___reversed__, 97, 12, "__reversed__")
QDEF(MP_QSTR___rfloordiv__, 84, 13, "__rfloordiv__")
QDEF(MP_QSTR___rlshift__, 27, 11, "__rlshift__")
QDEF(MP_QSTR___rmatmul__, 219, 11, "__rmatmul__")
QDEF(MP_QSTR___rmod__, 49, 8, "__rmod__")
QDEF(MP_QSTR___rmul__, 99, 8, "__rmul__")
QDEF(MP_QSTR___ror__, 42, 7, "__ror__")
QDEF(MP_QSTR___rpow__, 255, 8, "__rpow__")
QDEF(MP_QSTR___rrshift__, 197, 11, "__rrshift__")
QDEF(MP_QSTR___rshift__, 87, 10, "__rshift__")
QDEF(MP_QSTR___rsub__, 115, 8, "__rsub__")
QDEF(MP_QSTR___rtruediv__, 90, 12, "__rtruediv__")
QDEF(MP_QSTR___rxor__, 242, 8, "__rxor__")
QDEF(MP_QSTR___set__, 167, 7, "__set__")
QDEF(MP_QSTR___sub__, 33, 7, "__sub__")
QDEF(MP_QSTR___traceback__, 79, 13, "__traceback__")
QDEF(MP_QSTR___truediv__, 136, 11, "__truediv__")
QDEF(MP_QSTR___version__, 63, 11, "__version__")
QDEF(MP_QSTR___xor__, 32, 7, "__xor__")
QDEF(MP_QSTR__percent__hash_o, 108, 3, "%#o")
QDEF(MP_QSTR__percent__hash_x, 123, 3, "%#x")
QDEF(MP_QSTR__brace_open__colon__hash_b_brace_close_, 88, 5, "{:#b}")
QDEF(MP_QSTR_maximum_space_recursion_space_depth_space_exceeded, 115, 32, "maximum recursion depth exceeded")
QDEF(MP_QSTR__lt_lambda_gt_, 128, 8, "<lambda>")
QDEF(MP_QSTR__lt_listcomp_gt_, 212, 10, "<listcomp>")
QDEF(MP_QSTR__lt_dictcomp_gt_, 204, 10, "<dictcomp>")
QDEF(MP_QSTR__lt_setcomp_gt_, 84, 9, "<setcomp>")
QDEF(MP_QSTR__lt_genexpr_gt_, 52, 9, "<genexpr>")
QDEF(MP_QSTR__lt_string_gt_, 82, 8, "<string>")
QDEF(MP_QSTR__lt_stdin_gt_, 227, 7, "<stdin>")
QDEF(MP_QSTR_pystack_space_exhausted, 37, 17, "pystack exhausted")
QDEF(MP_QSTR__slash_lib, 141, 4, "/lib")
QDEF(MP_QSTR_AES, 18, 3, "AES")
QDEF(MP_QSTR_AUTO_RELOAD, 4, 11, "AUTO_RELOAD")
QDEF(MP_QSTR_Adapter, 18, 7, "Adapter")
QDEF(MP_QSTR_Address, 147, 7, "Address")
QDEF(MP_QSTR_AnalogIn, 200, 8, "AnalogIn")
QDEF(MP_QSTR_AnalogOut, 65, 9, "AnalogOut")
QDEF(MP_QSTR_Atkinson, 78, 8, "Atkinson")
QDEF(MP_QSTR_Attribute, 249, 9, "Attribute")
QDEF(MP_QSTR_BGR, 210, 3, "BGR")
QDEF(MP_QSTR_BGR555, 71, 6, "BGR555")
QDEF(MP_QSTR_BGR555_SWAPPED, 124, 14, "BGR555_SWAPPED")
QDEF(MP_QSTR_BGR565, 100, 6, "BGR565")
QDEF(MP_QSTR_BGR565_SWAPPED, 223, 14, "BGR565_SWAPPED")
QDEF(MP_QSTR_BOOTLOADER, 226, 10, "BOOTLOADER")
QDEF(MP_QSTR_BROADCAST, 90, 9, "BROADCAST")
QDEF(MP_QSTR_BROWNOUT, 141, 8, "BROWNOUT")
QDEF(MP_QSTR_BUTTON, 243, 6, "BUTTON")
QDEF(MP_QSTR_Bitmap, 70, 6, "Bitmap")
QDEF(MP_QSTR_BluetoothError, 171, 14, "BluetoothError")
QDEF(MP_QSTR_BrokenPipeError, 46, 15, "BrokenPipeError")
QDEF(MP_QSTR_BuiltinFont, 151, 11, "BuiltinFont")
QDEF(MP_QSTR_ByteArray, 118, 9, "ByteArray")
QDEF(MP_QSTR_BytesIO, 26, 7, "BytesIO")
QDEF(MP_QSTR_C, 230, 1, "C")
QDEF(MP_QSTR_CONSUMER_CONTROL, 67, 16, "CONSUMER_CONTROL")
QDEF(MP_QSTR_CancelledError, 246, 14, "CancelledError")
QDEF(MP_QSTR_Characteristic, 88, 14, "Characteristic")
QDEF(MP_QSTR_CharacteristicBuffer, 152, 20, "CharacteristicBuffer")
QDEF(MP_QSTR_Circle, 151, 6, "Circle")
QDEF(MP_QSTR_ColorConverter, 184, 14, "ColorConverter")
QDEF(MP_QSTR_ColorSpace, 220, 10, "ColorSpace")
QDEF(MP_QSTR_Colorspace, 188, 10, "Colorspace")
QDEF(MP_QSTR_Connection, 211, 10, "Connection")
QDEF(MP_QSTR_ConnectionError, 75, 15, "ConnectionError")
QDEF(MP_QSTR_Counter, 49, 7, "Counter")
QDEF(MP_QSTR_DEEP_SLEEP_ALARM, 13, 16, "DEEP_SLEEP_ALARM")
QDEF(MP_QSTR_DISPLAY, 255, 7, "DISPLAY")
QDEF(MP_QSTR_DOWN, 55, 4, "DOWN")
QDEF(MP_QSTR_DeepSleepRequest, 47, 16, "DeepSleepRequest")
QDEF(MP_QSTR_Descriptor, 182, 10, "Descriptor")
QDEF(MP_QSTR_Device, 29, 6, "Device")
QDEF(MP_QSTR_DigitalInOut, 246, 12, "DigitalInOut")
QDEF(MP_QSTR_Direction, 64, 9, "Direction")
QDEF(MP_QSTR_Display, 63, 7, "Display")
QDEF(MP_QSTR_DitherAlgorithm, 172, 15, "DitherAlgorithm")
QDEF(MP_QSTR_DriveMode, 170, 9, "DriveMode")
QDEF(MP_QSTR_EACCES, 55, 6, "EACCES")
QDEF(MP_QSTR_EADDRINUSE, 23, 10, "EADDRINUSE")
QDEF(MP_QSTR_EAGAIN, 32, 6, "EAGAIN")
QDEF(MP_QSTR_EALREADY, 70, 8, "EALREADY")
QDEF(MP_QSTR_EBADF, 97, 5, "EBADF")
QDEF(MP_QSTR_ECONNABORTED, 39, 12, "ECONNABORTED")
QDEF(MP_QSTR_ECONNREFUSED, 58, 12, "ECONNREFUSED")
QDEF(MP_QSTR_ECONNRESET, 25, 10, "ECONNRESET")
QDEF(MP_QSTR_EEXIST, 83, 6, "EEXIST")
QDEF(MP_QSTR_EHOSTUNREACH, 134, 12, "EHOSTUNREACH")
QDEF(MP_QSTR_EINPROGRESS, 154, 11, "EINPROGRESS")
QDEF(MP_QSTR_EINVAL, 92, 6, "EINVAL")
QDEF(MP_QSTR_EIO, 134, 3, "EIO")
QDEF(MP_QSTR_EISDIR, 165, 6, "EISDIR")
QDEF(MP_QSTR_ENCODER_A, 143, 9, "ENCODER_A")
QDEF(MP_QSTR_ENCODER_B, 140, 9, "ENCODER_B")
QDEF(MP_QSTR_ENCODER_SWITCH, 124, 14, "ENCODER_SWITCH")
QDEF(MP_QSTR_ENCRYPT_NO_MITM, 94, 15, "ENCRYPT_NO_MITM")
QDEF(MP_QSTR_ENCRYPT_WITH_MITM, 157, 17, "ENCRYPT_WITH_MITM")
QDEF(MP_QSTR_ENOBUFS, 227, 7, "ENOBUFS")
QDEF(MP_QSTR_ENODEV, 182, 6, "ENODEV")
QDEF(MP_QSTR_ENOENT, 94, 6, "ENOENT")
QDEF(MP_QSTR_ENOMEM, 164, 6, "ENOMEM")
QDEF(MP_QSTR_ENOTCONN, 121, 8, "ENOTCONN")
QDEF(MP_QSTR_EOPNOTSUPP, 172, 10, "EOPNOTSUPP")
QDEF(MP_QSTR_EPERM, 234, 5, "EPERM")
QDEF(MP_QSTR_EPaperDisplay, 108, 13, "EPaperDisplay")
QDEF(MP_QSTR_ETIMEDOUT, 255, 9, "ETIMEDOUT")
QDEF(MP_QSTR_EVEN, 221, 4, "EVEN")
QDEF(MP_QSTR_EVEN_BYTES, 123, 10, "EVEN_BYTES")
QDEF(MP_QSTR_EVERY_BYTE, 237, 10, "EVERY_BYTE")
QDEF(MP_QSTR_Edge, 166, 4, "Edge")
QDEF(MP_QSTR_Event, 233, 5, "Event")
QDEF(MP_QSTR_EventQueue, 24, 10, "EventQueue")
QDEF(MP_QSTR_ExtType, 84, 7, "ExtType")
QDEF(MP_QSTR_FALL, 130, 4, "FALL")
QDEF(MP_QSTR_FONT, 86, 4, "FONT")
QDEF(MP_QSTR_FileIO, 197, 6, "FileIO")
QDEF(MP_QSTR_Flash, 149, 5, "Flash")
QDEF(MP_QSTR_FloydStenberg, 99, 13, "FloydStenberg")
QDEF(MP_QSTR_FourWire, 2, 8, "FourWire")
QDEF(MP_QSTR_FramebufferDisplay, 162, 18, "FramebufferDisplay")
QDEF(MP_QSTR_GPIO0, 164, 5, "GPIO0")
QDEF(MP_QSTR_GPIO1, 165, 5, "GPIO1")
QDEF(MP_QSTR_GPIO10, 117, 6, "GPIO10")
QDEF(MP_QSTR_GPIO11, 116, 6, "GPIO11")
QDEF(MP_QSTR_GPIO12, 119, 6, "GPIO12")
QDEF(MP_QSTR_GPIO13, 118, 6, "GPIO13")
QDEF(MP_QSTR_GPIO14, 113, 6, "GPIO14")
QDEF(MP_QSTR_GPIO15, 112, 6, "GPIO15")
QDEF(MP_QSTR_GPIO16, 115, 6, "GPIO16")
QDEF(MP_QSTR_GPIO17, 114, 6, "GPIO17")
QDEF(MP_QSTR_GPIO18, 125, 6, "GPIO18")
QDEF(MP_QSTR_GPIO19, 124, 6, "GPIO19")
QDEF(MP_QSTR_GPIO2, 166, 5, "GPIO2")
QDEF(MP_QSTR_GPIO20, 86, 6, "GPIO20")
QDEF(MP_QSTR_GPIO21, 87, 6, "GPIO21")
QDEF(MP_QSTR_GPIO22, 84, 6, "GPIO22")
QDEF(MP_QSTR_GPIO23, 85, 6, "GPIO23")
QDEF(MP_QSTR_GPIO24, 82, 6, "GPIO24")
QDEF(MP_QSTR_GPIO25, 83, 6, "GPIO25")
QDEF(MP_QSTR_GPIO26, 80, 6, "GPIO26")
QDEF(MP_QSTR_GPIO27, 81, 6, "GPIO27")
QDEF(MP_QSTR_GPIO28, 94, 6, "GPIO28")
QDEF(MP_QSTR_GPIO29, 95, 6, "GPIO29")
QDEF(MP_QSTR_GPIO3, 167, 5, "GPIO3")
QDEF(MP_QSTR_GPIO4, 160, 5, "GPIO4")
QDEF(MP_QSTR_GPIO5, 161, 5, "GPIO5")
QDEF(MP_QSTR_GPIO6, 162, 5, "GPIO6")
QDEF(MP_QSTR_GPIO7, 163, 5, "GPIO7")
QDEF(MP_QSTR_GPIO8, 172, 5, "GPIO8")
QDEF(MP_QSTR_GPIO9, 173, 5, "GPIO9")
QDEF(MP_QSTR_GifWriter, 130, 9, "GifWriter")
QDEF(MP_QSTR_Glyph, 111, 5, "Glyph")
QDEF(MP_QSTR_Group, 218, 5, "Group")
QDEF(MP_QSTR_I2C, 93, 3, "I2C")
QDEF(MP_QSTR_I2CDevice, 69, 9, "I2CDevice")
QDEF(MP_QSTR_I2CDisplay, 231, 10, "I2CDisplay")
QDEF(MP_QSTR_I2SOut, 3, 6, "I2SOut")
QDEF(MP_QSTR_INDICATE, 92, 8, "INDICATE")
QDEF(MP_QSTR_INPUT, 83, 5, "INPUT")
QDEF(MP_QSTR_IV, 58, 2, "IV")
QDEF(MP_QSTR_IncrementalEncoder, 93, 18, "IncrementalEncoder")
QDEF(MP_QSTR_KEY1, 99, 4, "KEY1")
QDEF(MP_QSTR_KEY10, 243, 5, "KEY10")
QDEF(MP_QSTR_KEY11, 242, 5, "KEY11")
QDEF(MP_QSTR_KEY12, 241, 5, "KEY12")
QDEF(MP_QSTR_KEY2, 96, 4, "KEY2")
QDEF(MP_QSTR_KEY3, 97, 4, "KEY3")
QDEF(MP_QSTR_KEY4, 102, 4, "KEY4")
QDEF(MP_QSTR_KEY5, 103, 4, "KEY5")
QDEF(MP_QSTR_KEY6, 100, 4, "KEY6")
QDEF(MP_QSTR_KEY7, 101, 4, "KEY7")
QDEF(MP_QSTR_KEY8, 106, 4, "KEY8")
QDEF(MP_QSTR_KEY9, 107, 4, "KEY9")
QDEF(MP_QSTR_KEYBOARD, 168, 8, "KEYBOARD")
QDEF(MP_QSTR_KeyMatrix, 41, 9, "KeyMatrix")
QDEF(MP_QSTR_Keys, 225, 4, "Keys")
QDEF(MP_QSTR_L8, 49, 2, "L8")
QDEF(MP_QSTR_LED, 136, 3, "LED")
QDEF(MP_QSTR_LESC_ENCRYPT_WITH_MITM, 187, 22, "LESC_ENCRYPT_WITH_MITM")
QDEF(MP_QSTR_M, 232, 1, "M")
QDEF(MP_QSTR_MISO, 157, 4, "MISO")
QDEF(MP_QSTR_MODE_CBC, 27, 8, "MODE_CBC")
QDEF(MP_QSTR_MODE_CTR, 92, 8, "MODE_CTR")
QDEF(MP_QSTR_MODE_ECB, 189, 8, "MODE_ECB")
QDEF(MP_QSTR_MOSI, 29, 4, "MOSI")
QDEF(MP_QSTR_MOUSE, 36, 5, "MOUSE")
QDEF(MP_QSTR_MP3Decoder, 21, 10, "MP3Decoder")
QDEF(MP_QSTR_MidiTrack, 227, 9, "MidiTrack")
QDEF(MP_QSTR_Mixer, 110, 5, "Mixer")
QDEF(MP_QSTR_MixerVoice, 184, 10, "MixerVoice")
QDEF(MP_QSTR_MpyError, 57, 8, "MpyError")
QDEF(MP_QSTR_NEOPIXEL, 169, 8, "NEOPIXEL")
QDEF(MP_QSTR_NORMAL, 246, 6, "NORMAL")
QDEF(MP_QSTR_NOTIFY, 134, 6, "NOTIFY")
QDEF(MP_QSTR_NO_ACCESS, 63, 9, "NO_ACCESS")
QDEF(MP_QSTR_NaN, 36, 3, "NaN")
QDEF(MP_QSTR_None, 111, 4, "None")
QDEF(MP_QSTR_ODD, 106, 3, "ODD")
QDEF(MP_QSTR_ODD_BYTES, 12, 9, "ODD_BYTES")
QDEF(MP_QSTR_OLED_CS, 136, 7, "OLED_CS")
QDEF(MP_QSTR_OLED_DC, 191, 7, "OLED_DC")
QDEF(MP_QSTR_OLED_RESET, 45, 10, "OLED_RESET")
QDEF(MP_QSTR_OPEN, 145, 4, "OPEN")
QDEF(MP_QSTR_OPEN_DRAIN, 94, 10, "OPEN_DRAIN")
QDEF(MP_QSTR_OUTPUT, 218, 6, "OUTPUT")
QDEF(MP_QSTR_OnDiskBitmap, 18, 12, "OnDiskBitmap")
QDEF(MP_QSTR_OneWire, 104, 7, "OneWire")
QDEF(MP_QSTR_OrderedDict, 240, 11, "OrderedDict")
QDEF(MP_QSTR_PDMIn, 123, 5, "PDMIn")
QDEF(MP_QSTR_POLLERR, 223, 7, "POLLERR")
QDEF(MP_QSTR_POLLHUP, 119, 7, "POLLHUP")
QDEF(MP_QSTR_POLLIN, 125, 6, "POLLIN")
QDEF(MP_QSTR_POLLOUT, 116, 7, "POLLOUT")
QDEF(MP_QSTR_POWER_ON, 196, 8, "POWER_ON")
QDEF(MP_QSTR_PUBLIC, 164, 6, "PUBLIC")
QDEF(MP_QSTR_PUSH_PULL, 129, 9, "PUSH_PULL")
QDEF(MP_QSTR_PWMAudioOut, 183, 11, "PWMAudioOut")
QDEF(MP_QSTR_PWMOut, 193, 6, "PWMOut")
QDEF(MP_QSTR_PacketBuffer, 237, 12, "PacketBuffer")
QDEF(MP_QSTR_Palette, 248, 7, "Palette")
QDEF(MP_QSTR_ParallelBus, 42, 11, "ParallelBus")
QDEF(MP_QSTR_ParallelImageCapture, 205, 20, "ParallelImageCapture")
QDEF(MP_QSTR_Parity, 34, 6, "Parity")
QDEF(MP_QSTR_Pin, 18, 3, "Pin")
QDEF(MP_QSTR_PinAlarm, 193, 8, "PinAlarm")
QDEF(MP_QSTR_PixelBuf, 252, 8, "PixelBuf")
QDEF(MP_QSTR_PixelPolicy, 109, 11, "PixelPolicy")
QDEF(MP_QSTR_Polygon, 73, 7, "Polygon")
QDEF(MP_QSTR_PortIn, 251, 6, "PortIn")
QDEF(MP_QSTR_PortOut, 146, 7, "PortOut")
QDEF(MP_QSTR_Processor, 19, 9, "Processor")
QDEF(MP_QSTR_Pull, 96, 4, "Pull")
QDEF(MP_QSTR_PulseIn, 253, 7, "PulseIn")
QDEF(MP_QSTR_PulseOut, 212, 8, "PulseOut")
QDEF(MP_QSTR_QRDecoder, 216, 9, "QRDecoder")
QDEF(MP_QSTR_QRInfo, 40, 6, "QRInfo")
QDEF(MP_QSTR_RAISE, 105, 5, "RAISE")
QDEF(MP_QSTR_RANDOM_PRIVATE_NON_RESOLVABLE, 216, 29, "RANDOM_PRIVATE_NON_RESOLVABLE")
QDEF(MP_QSTR_RANDOM_PRIVATE_RESOLVABLE, 136, 25, "RANDOM_PRIVATE_RESOLVABLE")
QDEF(MP_QSTR_RANDOM_STATIC, 89, 13, "RANDOM_STATIC")
QDEF(MP_QSTR_READ, 183, 4, "READ")
QDEF(MP_QSTR_REPL_RELOAD, 32, 11, "REPL_RELOAD")
QDEF(MP_QSTR_RESCUE_DEBUG, 60, 12, "RESCUE_DEBUG")
QDEF(MP_QSTR_RESET, 48, 5, "RESET")
QDEF(MP_QSTR_RESET_PIN, 56, 9, "RESET_PIN")
QDEF(MP_QSTR_RGB555, 71, 6, "RGB555")
QDEF(MP_QSTR_RGB555_SWAPPED, 124, 14, "RGB555_SWAPPED")
QDEF(MP_QSTR_RGB565, 100, 6, "RGB565")
QDEF(MP_QSTR_RGB565_SWAPPED, 223, 14, "RGB565_SWAPPED")
QDEF(MP_QSTR_RGB888, 170, 6, "RGB888")
QDEF(MP_QSTR_RGBMatrix, 169, 9, "RGBMatrix")
QDEF(MP_QSTR_RISE, 232, 4, "RISE")
QDEF(MP_QSTR_RISE_AND_FALL, 68, 13, "RISE_AND_FALL")
QDEF(MP_QSTR_ROTA, 13, 4, "ROTA")
QDEF(MP_QSTR_ROTB, 14, 4, "ROTB")
QDEF(MP_QSTR_RTC, 160, 3, "RTC")
QDEF(MP_QSTR_RawSample, 231, 9, "RawSample")
QDEF(MP_QSTR_Rectangle, 196, 9, "Rectangle")
QDEF(MP_QSTR_ReloadException, 3, 15, "ReloadException")
QDEF(MP_QSTR_ResetReason, 84, 11, "ResetReason")
QDEF(MP_QSTR_RoleError, 233, 9, "RoleError")
QDEF(MP_QSTR_RunMode, 143, 7, "RunMode")
QDEF(MP_QSTR_RunReason, 232, 9, "RunReason")
QDEF(MP_QSTR_Runtime, 185, 7, "Runtime")
QDEF(MP_QSTR_SAFE_MODE, 8, 9, "SAFE_MODE")
QDEF(MP_QSTR_SCK, 222, 3, "SCK")
QDEF(MP_QSTR_SCL, 217, 3, "SCL")
QDEF(MP_QSTR_SDA, 115, 3, "SDA")
QDEF(MP_QSTR_SDCard, 166, 6, "SDCard")
QDEF(MP_QSTR_SH1107_addressing, 80, 17, "SH1107_addressing")
QDEF(MP_QSTR_SIGNED_NO_MITM, 203, 14, "SIGNED_NO_MITM")
QDEF(MP_QSTR_SIGNED_WITH_MITM, 72, 16, "SIGNED_WITH_MITM")
QDEF(MP_QSTR_SOFTWARE, 202, 8, "SOFTWARE")
QDEF(MP_QSTR_SPEAKER, 190, 7, "SPEAKER")
QDEF(MP_QSTR_SPEAKER_ENABLE, 160, 14, "SPEAKER_ENABLE")
QDEF(MP_QSTR_SPI, 239, 3, "SPI")
QDEF(MP_QSTR_SPIDevice, 55, 9, "SPIDevice")
QDEF(MP_QSTR_STARTUP, 128, 7, "STARTUP")
QDEF(MP_QSTR_STEMMA_I2C, 33, 10, "STEMMA_I2C")
QDEF(MP_QSTR_SUPERVISOR_RELOAD, 251, 17, "SUPERVISOR_RELOAD")
QDEF(MP_QSTR_ScanEntry, 238, 9, "ScanEntry")
QDEF(MP_QSTR_ScanResults, 160, 11, "ScanResults")
QDEF(MP_QSTR_SecurityError, 107, 13, "SecurityError")
QDEF(MP_QSTR_Serial, 229, 6, "Serial")
QDEF(MP_QSTR_Service, 184, 7, "Service")
QDEF(MP_QSTR_Shape, 234, 5, "Shape")
QDEF(MP_QSTR_SharpMemoryFramebuffer, 193, 22, "SharpMemoryFramebuffer")
QDEF(MP_QSTR_ShiftRegisterKeys, 200, 17, "ShiftRegisterKeys")
QDEF(MP_QSTR_SleepMemory, 171, 11, "SleepMemory")
QDEF(MP_QSTR_StateMachine, 215, 12, "StateMachine")
QDEF(MP_QSTR_StopAsyncIteration, 236, 18, "StopAsyncIteration")
QDEF(MP_QSTR_StringIO, 118, 8, "StringIO")
QDEF(MP_QSTR_Task, 8, 4, "Task")
QDEF(MP_QSTR_TaskQueue, 153, 9, "TaskQueue")
QDEF(MP_QSTR_Terminal, 33, 8, "Terminal")
QDEF(MP_QSTR_TextIOWrapper, 173, 13, "TextIOWrapper")
QDEF(MP_QSTR_TileGrid, 73, 8, "TileGrid")
QDEF(MP_QSTR_TimeAlarm, 195, 9, "TimeAlarm")
QDEF(MP_QSTR_TimeoutError, 102, 12, "TimeoutError")
QDEF(MP_QSTR_TouchAlarm, 51, 10, "TouchAlarm")
QDEF(MP_QSTR_TouchIn, 103, 7, "TouchIn")
QDEF(MP_QSTR_UART, 183, 4, "UART")
QDEF(MP_QSTR_UF2, 68, 3, "UF2")
QDEF(MP_QSTR_UNKNOWN, 141, 7, "UNKNOWN")
QDEF(MP_QSTR_UP, 160, 2, "UP")
QDEF(MP_QSTR_UUID, 200, 4, "UUID")
QDEF(MP_QSTR_UnicodeError, 34, 12, "UnicodeError")
QDEF(MP_QSTR_VectorShape, 115, 11, "VectorShape")
QDEF(MP_QSTR_VfsFat, 21, 6, "VfsFat")
QDEF(MP_QSTR_WATCHDOG, 1, 8, "WATCHDOG")
QDEF(MP_QSTR_WRITE, 248, 5, "WRITE")
QDEF(MP_QSTR_WRITE_NO_RESPONSE, 218, 17, "WRITE_NO_RESPONSE")
QDEF(MP_QSTR_WatchDogMode, 3, 12, "WatchDogMode")
QDEF(MP_QSTR_WatchDogTimeout, 251, 15, "WatchDogTimeout")
QDEF(MP_QSTR_WatchDogTimer, 135, 13, "WatchDogTimer")
QDEF(MP_QSTR_WaveFile, 230, 8, "WaveFile")
QDEF(MP_QSTR__asyncio, 218, 8, "_asyncio")
QDEF(MP_QSTR__bleio, 247, 6, "_bleio")
QDEF(MP_QSTR__task_queue, 217, 11, "_task_queue")
QDEF(MP_QSTR__transmit, 208, 9, "_transmit")
QDEF(MP_QSTR_a, 196, 1, "a")
QDEF(MP_QSTR_a2b_base64, 60, 10, "a2b_base64")
QDEF(MP_QSTR_acos, 27, 4, "acos")
QDEF(MP_QSTR_acosh, 19, 5, "acosh")
QDEF(MP_QSTR_active, 105, 6, "active")
QDEF(MP_QSTR_adafruit_bus_device, 161, 19, "adafruit_bus_device")
QDEF(MP_QSTR_adafruit_bus_device_dot_i2c_device, 176, 30, "adafruit_bus_device.i2c_device")
QDEF(MP_QSTR_adafruit_bus_device_dot_spi_device, 226, 30, "adafruit_bus_device.spi_device")
QDEF(MP_QSTR_adafruit_pixelbuf, 123, 17, "adafruit_pixelbuf")
QDEF(MP_QSTR_adapter, 242, 7, "adapter")
QDEF(MP_QSTR_add, 68, 3, "add")
QDEF(MP_QSTR_add_frame, 166, 9, "add_frame")
QDEF(MP_QSTR_add_to_characteristic, 34, 21, "add_to_characteristic")
QDEF(MP_QSTR_add_to_service, 2, 14, "add_to_service")
QDEF(MP_QSTR_addr_pins, 109, 9, "addr_pins")
QDEF(MP_QSTR_address, 115, 7, "address")
QDEF(MP_QSTR_address_bytes, 245, 13, "address_bytes")
QDEF(MP_QSTR_address_type, 20, 12, "address_type")
QDEF(MP_QSTR_advertisement_bytes, 126, 19, "advertisement_bytes")
QDEF(MP_QSTR_advertising, 143, 11, "advertising")
QDEF(MP_QSTR_aesio, 20, 5, "aesio")
QDEF(MP_QSTR_alarm, 22, 5, "alarm")
QDEF(MP_QSTR_algorithm, 10, 9, "algorithm")
QDEF(MP_QSTR_alphablend, 80, 10, "alphablend")
QDEF(MP_QSTR_always_toggle_chip_select, 227, 25, "always_toggle_chip_select")
QDEF(MP_QSTR_analogio, 9, 8, "analogio")
QDEF(MP_QSTR_angle, 132, 5, "angle")
QDEF(MP_QSTR_annotations, 113, 11, "annotations")
QDEF(MP_QSTR_anonymous, 22, 9, "anonymous")
QDEF(MP_QSTR_arange, 123, 6, "arange")
QDEF(MP_QSTR_arctan2, 28, 7, "arctan2")
QDEF(MP_QSTR_argmax, 165, 6, "argmax")
QDEF(MP_QSTR_argmin, 187, 6, "argmin")
QDEF(MP_QSTR_argsort, 43, 7, "argsort")
QDEF(MP_QSTR_argv, 199, 4, "argv")
QDEF(MP_QSTR_around, 6, 6, "around")
QDEF(MP_QSTR_array, 124, 5, "array")
QDEF(MP_QSTR_arrayblit, 15, 9, "arrayblit")
QDEF(MP_QSTR_asin, 80, 4, "asin")
QDEF(MP_QSTR_asinh, 56, 5, "asinh")
QDEF(MP_QSTR_atan, 31, 4, "atan")
QDEF(MP_QSTR_atan2, 205, 5, "atan2")
QDEF(MP_QSTR_atanh, 151, 5, "atanh")
QDEF(MP_QSTR_atexit, 176, 6, "atexit")
QDEF(MP_QSTR_audiobusio, 145, 10, "audiobusio")
QDEF(MP_QSTR_audiocore, 232, 9, "audiocore")
QDEF(MP_QSTR_audiomixer, 88, 10, "audiomixer")
QDEF(MP_QSTR_audiomp3, 157, 8, "audiomp3")
QDEF(MP_QSTR_audiopwmio, 223, 10, "audiopwmio")
QDEF(MP_QSTR_auto_brightness, 252, 15, "auto_brightness")
QDEF(MP_QSTR_auto_pull, 48, 9, "auto_pull")
QDEF(MP_QSTR_auto_push, 75, 9, "auto_push")
QDEF(MP_QSTR_auto_refresh, 232, 12, "auto_refresh")
QDEF(MP_QSTR_auto_write, 232, 10, "auto_write")
QDEF(MP_QSTR_axis, 6, 4, "axis")
QDEF(MP_QSTR_b2a_base64, 60, 10, "b2a_base64")
QDEF(MP_QSTR_background_write, 105, 16, "background_write")
QDEF(MP_QSTR_backlight_on_high, 255, 17, "backlight_on_high")
QDEF(MP_QSTR_backlight_pin, 216, 13, "backlight_pin")
QDEF(MP_QSTR_base, 240, 4, "base")
QDEF(MP_QSTR_baudrate, 245, 8, "baudrate")
QDEF(MP_QSTR_bin, 224, 3, "bin")
QDEF(MP_QSTR_binascii, 145, 8, "binascii")
QDEF(MP_QSTR_bisect, 143, 6, "bisect")
QDEF(MP_QSTR_bit_clock, 205, 9, "bit_clock")
QDEF(MP_QSTR_bit_depth, 136, 9, "bit_depth")
QDEF(MP_QSTR_bit_length, 185, 10, "bit_length")
QDEF(MP_QSTR_bit_transpose, 150, 13, "bit_transpose")
QDEF(MP_QSTR_bitbangio, 86, 9, "bitbangio")
QDEF(MP_QSTR_bitmap, 102, 6, "bitmap")
QDEF(MP_QSTR_bitmaptools, 109, 11, "bitmaptools")
QDEF(MP_QSTR_bitops, 86, 6, "bitops")
QDEF(MP_QSTR_bits, 73, 4, "bits")
QDEF(MP_QSTR_bits_per_pixel, 230, 14, "bits_per_pixel")
QDEF(MP_QSTR_bits_per_sample, 72, 15, "bits_per_sample")
QDEF(MP_QSTR_black_bits_inverted, 221, 19, "black_bits_inverted")
QDEF(MP_QSTR_blit, 246, 4, "blit")
QDEF(MP_QSTR_block_size, 86, 10, "block_size")
QDEF(MP_QSTR_board, 127, 5, "board")
QDEF(MP_QSTR_board_id, 237, 8, "board_id")
QDEF(MP_QSTR_bond, 2, 4, "bond")
QDEF(MP_QSTR_boot_device, 244, 11, "boot_device")
QDEF(MP_QSTR_bound_method, 151, 12, "bound_method")
QDEF(MP_QSTR_boundary_fill, 13, 13, "boundary_fill")
QDEF(MP_QSTR_bpp, 199, 3, "bpp")
QDEF(MP_QSTR_brightness, 76, 10, "brightness")
QDEF(MP_QSTR_brightness_command, 212, 18, "brightness_command")
QDEF(MP_QSTR_buffer, 229, 6, "buffer")
QDEF(MP_QSTR_buffer_in, 189, 9, "buffer_in")
QDEF(MP_QSTR_buffer_out, 20, 10, "buffer_out")
QDEF(MP_QSTR_buffer_size, 191, 11, "buffer_size")
QDEF(MP_QSTR_buffering, 37, 9, "buffering")
QDEF(MP_QSTR_bus, 97, 3, "bus")
QDEF(MP_QSTR_busio, 135, 5, "busio")
QDEF(MP_QSTR_busy, 248, 4, "busy")
QDEF(MP_QSTR_busy_pin, 16, 8, "busy_pin")
QDEF(MP_QSTR_busy_state, 240, 10, "busy_state")
QDEF(MP_QSTR_byteorder, 97, 9, "byteorder")
QDEF(MP_QSTR_bytes_per_cell, 221, 14, "bytes_per_cell")
QDEF(MP_QSTR_byteswap, 218, 8, "byteswap")
QDEF(MP_QSTR_calcsize, 77, 8, "calcsize")
QDEF(MP_QSTR_calibration, 175, 11, "calibration")
QDEF(MP_QSTR_cancel, 3, 6, "cancel")
QDEF(MP_QSTR_capture, 97, 7, "capture")
QDEF(MP_QSTR_cast, 64, 4, "cast")
QDEF(MP_QSTR_ceil, 6, 4, "ceil")
QDEF(MP_QSTR_center, 78, 6, "center")
QDEF(MP_QSTR_chain, 232, 5, "chain")
QDEF(MP_QSTR_channel_count, 154, 13, "channel_count")
QDEF(MP_QSTR_characteristic, 120, 14, "characteristic")
QDEF(MP_QSTR_characteristics, 11, 15, "characteristics")
QDEF(MP_QSTR_chdir, 177, 5, "chdir")
QDEF(MP_QSTR_chip_select, 96, 11, "chip_select")
QDEF(MP_QSTR_cho_solve, 61, 9, "cho_solve")
QDEF(MP_QSTR_choice, 46, 6, "choice")
QDEF(MP_QSTR_cholesky, 137, 8, "cholesky")
QDEF(MP_QSTR_circuitpython, 2, 13, "circuitpython")
QDEF(MP_QSTR_clear_rxfifo, 239, 12, "clear_rxfifo")
QDEF(MP_QSTR_clear_txstall, 105, 13, "clear_txstall")
QDEF(MP_QSTR_clip, 211, 4, "clip")
QDEF(MP_QSTR_clock, 45, 5, "clock")
QDEF(MP_QSTR_clock_pin, 133, 9, "clock_pin")
QDEF(MP_QSTR_closure, 116, 7, "closure")
QDEF(MP_QSTR_code, 104, 4, "code")
QDEF(MP_QSTR_codepoint, 228, 9, "codepoint")
QDEF(MP_QSTR_collect, 155, 7, "collect")
QDEF(MP_QSTR_collections, 224, 11, "collections")
QDEF(MP_QSTR_color, 216, 5, "color")
QDEF(MP_QSTR_color_bits_inverted, 167, 19, "color_bits_inverted")
QDEF(MP_QSTR_color_count, 228, 11, "color_count")
QDEF(MP_QSTR_color_depth, 42, 11, "color_depth")
QDEF(MP_QSTR_color_index, 57, 11, "color_index")
QDEF(MP_QSTR_colorspace, 220, 10, "colorspace")
QDEF(MP_QSTR_colorwheel, 11, 10, "colorwheel")
QDEF(MP_QSTR_colstart, 37, 8, "colstart")
QDEF(MP_QSTR_column, 211, 6, "column")
QDEF(MP_QSTR_column_pins, 168, 11, "column_pins")
QDEF(MP_QSTR_columns_to_anodes, 41, 17, "columns_to_anodes")
QDEF(MP_QSTR_command, 2, 7, "command")
QDEF(MP_QSTR_compile, 244, 7, "compile")
QDEF(MP_QSTR_complex, 197, 7, "complex")
QDEF(MP_QSTR_compress, 163, 8, "compress")
QDEF(MP_QSTR_concatenate, 10, 11, "concatenate")
QDEF(MP_QSTR_configure, 141, 9, "configure")
QDEF(MP_QSTR_connect, 219, 7, "connect")
QDEF(MP_QSTR_connectable, 113, 11, "connectable")
QDEF(MP_QSTR_connected, 122, 9, "connected")
QDEF(MP_QSTR_connection_interval, 147, 19, "connection_interval")
QDEF(MP_QSTR_connections, 32, 11, "connections")
QDEF(MP_QSTR_console, 82, 7, "console")
QDEF(MP_QSTR_contains, 6, 8, "contains")
QDEF(MP_QSTR_continuous_capture_get_frame, 120, 28, "continuous_capture_get_frame")
QDEF(MP_QSTR_continuous_capture_start, 44, 24, "continuous_capture_start")
QDEF(MP_QSTR_continuous_capture_stop, 20, 23, "continuous_capture_stop")
QDEF(MP_QSTR_convert, 242, 7, "convert")
QDEF(MP_QSTR_convolve, 65, 8, "convolve")
QDEF(MP_QSTR_copysign, 51, 8, "copysign")
QDEF(MP_QSTR_coro, 180, 4, "coro")
QDEF(MP_QSTR_coroutine, 23, 9, "coroutine")
QDEF(MP_QSTR_cos, 122, 3, "cos")
QDEF(MP_QSTR_cosh, 210, 4, "cosh")
QDEF(MP_QSTR_counter, 17, 7, "counter")
QDEF(MP_QSTR_countio, 128, 7, "countio")
QDEF(MP_QSTR_cp437, 38, 5, "cp437")
QDEF(MP_QSTR_cp874, 173, 5, "cp874")
QDEF(MP_QSTR_cpu, 195, 3, "cpu")
QDEF(MP_QSTR_cpus, 80, 4, "cpus")
QDEF(MP_QSTR_crc32, 118, 5, "crc32")
QDEF(MP_QSTR_cross, 123, 5, "cross")
QDEF(MP_QSTR_cs, 245, 2, "cs")
QDEF(MP_QSTR_cs_active_value, 114, 15, "cs_active_value")
QDEF(MP_QSTR_cts, 65, 3, "cts")
QDEF(MP_QSTR_cur_task, 243, 8, "cur_task")
QDEF(MP_QSTR_customio, 80, 8, "customio")
QDEF(MP_QSTR_data, 21, 4, "data")
QDEF(MP_QSTR_data0, 133, 5, "data0")
QDEF(MP_QSTR_data_as_commands, 51, 16, "data_as_commands")
QDEF(MP_QSTR_data_pin, 61, 8, "data_pin")
QDEF(MP_QSTR_data_pins, 174, 9, "data_pins")
QDEF(MP_QSTR_data_type, 114, 9, "data_type")
QDEF(MP_QSTR_datetime, 228, 8, "datetime")
QDEF(MP_QSTR_ddof, 236, 4, "ddof")
QDEF(MP_QSTR_decimals, 29, 8, "decimals")
QDEF(MP_QSTR_decode, 169, 6, "decode")
QDEF(MP_QSTR_decompress, 98, 10, "decompress")
QDEF(MP_QSTR_decrypt_into, 139, 12, "decrypt_into")
QDEF(MP_QSTR_default, 206, 7, "default")
QDEF(MP_QSTR_default_tile, 197, 12, "default_tile")
QDEF(MP_QSTR_degrees, 2, 7, "degrees")
QDEF(MP_QSTR_deinit, 158, 6, "deinit")
QDEF(MP_QSTR_delattr, 219, 7, "delattr")
QDEF(MP_QSTR_delay, 80, 5, "delay")
QDEF(MP_QSTR_delay_us, 169, 8, "delay_us")
QDEF(MP_QSTR_deleter, 110, 7, "deleter")
QDEF(MP_QSTR_dest_bitmap, 255, 11, "dest_bitmap")
QDEF(MP_QSTR_dest_clip0, 250, 10, "dest_clip0")
QDEF(MP_QSTR_dest_clip1, 251, 10, "dest_clip1")
QDEF(MP_QSTR_det, 112, 3, "det")
QDEF(MP_QSTR_device_address, 20, 14, "device_address")
QDEF(MP_QSTR_devices, 174, 7, "devices")
QDEF(MP_QSTR_diag, 110, 4, "diag")
QDEF(MP_QSTR_dict_view, 45, 9, "dict_view")
QDEF(MP_QSTR_diff, 200, 4, "diff")
QDEF(MP_QSTR_difference, 114, 10, "difference")
QDEF(MP_QSTR_difference_update, 156, 17, "difference_update")
QDEF(MP_QSTR_digitalio, 25, 9, "digitalio")
QDEF(MP_QSTR_directed_to, 237, 11, "directed_to")
QDEF(MP_QSTR_direction, 32, 9, "direction")
QDEF(MP_QSTR_dirty, 119, 5, "dirty")
QDEF(MP_QSTR_disable, 145, 7, "disable")
QDEF(MP_QSTR_disable_autoreload, 176, 18, "disable_autoreload")
QDEF(MP_QSTR_disable_ble_workflow, 169, 20, "disable_ble_workflow")
QDEF(MP_QSTR_disable_concurrent_write_protection, 59, 35, "disable_concurrent_write_protection")
QDEF(MP_QSTR_disable_interrupts, 250, 18, "disable_interrupts")
QDEF(MP_QSTR_disable_usb_drive, 57, 17, "disable_usb_drive")
QDEF(MP_QSTR_discard, 15, 7, "discard")
QDEF(MP_QSTR_disconnect, 165, 10, "disconnect")
QDEF(MP_QSTR_discover_remote_services, 156, 24, "discover_remote_services")
QDEF(MP_QSTR_display_bus, 36, 11, "display_bus")
QDEF(MP_QSTR_displayio, 57, 9, "displayio")
QDEF(MP_QSTR_dither, 99, 6, "dither")
QDEF(MP_QSTR_divisor, 249, 7, "divisor")
QDEF(MP_QSTR_doc, 45, 3, "doc")
QDEF(MP_QSTR_done, 69, 4, "done")
QDEF(MP_QSTR_dot, 58, 3, "dot")
QDEF(MP_QSTR_dotenv, 199, 6, "dotenv")
QDEF(MP_QSTR_doublebuffer, 144, 12, "doublebuffer")
QDEF(MP_QSTR_draw_line, 84, 9, "draw_line")
QDEF(MP_QSTR_drive_mode, 21, 10, "drive_mode")
QDEF(MP_QSTR_dtype, 89, 5, "dtype")
QDEF(MP_QSTR_dump, 233, 4, "dump")
QDEF(MP_QSTR_dumps, 122, 5, "dumps")
QDEF(MP_QSTR_duty_cycle, 246, 10, "duty_cycle")
QDEF(MP_QSTR_dx, 153, 2, "dx")
QDEF(MP_QSTR_dy, 152, 2, "dy")
QDEF(MP_QSTR_e, 192, 1, "e")
QDEF(MP_QSTR_edge, 198, 4, "edge")
QDEF(MP_QSTR_edgeitems, 192, 9, "edgeitems")
QDEF(MP_QSTR_eig, 174, 3, "eig")
QDEF(MP_QSTR_element_size, 161, 12, "element_size")
QDEF(MP_QSTR_empty, 176, 5, "empty")
QDEF(MP_QSTR_enable, 4, 6, "enable")
QDEF(MP_QSTR_enable_autoreload, 133, 17, "enable_autoreload")
QDEF(MP_QSTR_enable_interrupts, 79, 17, "enable_interrupts")
QDEF(MP_QSTR_enable_usb_drive, 236, 16, "enable_usb_drive")
QDEF(MP_QSTR_enabled, 224, 7, "enabled")
QDEF(MP_QSTR_encode, 67, 6, "encode")
QDEF(MP_QSTR_encoding, 6, 8, "encoding")
QDEF(MP_QSTR_encrypt_into, 225, 12, "encrypt_into")
QDEF(MP_QSTR_endpoint, 6, 8, "endpoint")
QDEF(MP_QSTR_enumerate, 113, 9, "enumerate")
QDEF(MP_QSTR_epoch_time, 222, 10, "epoch_time")
QDEF(MP_QSTR_equal, 137, 5, "equal")
QDEF(MP_QSTR_erase_bonding, 93, 13, "erase_bonding")
QDEF(MP_QSTR_erase_filesystem, 121, 16, "erase_filesystem")
QDEF(MP_QSTR_erf, 148, 3, "erf")
QDEF(MP_QSTR_erfc, 119, 4, "erfc")
QDEF(MP_QSTR_errno, 193, 5, "errno")
QDEF(MP_QSTR_errorcode, 16, 9, "errorcode")
QDEF(MP_QSTR_etype, 88, 5, "etype")
QDEF(MP_QSTR_event, 201, 5, "event")
QDEF(MP_QSTR_events, 154, 6, "events")
QDEF(MP_QSTR_exclusive_pin_use, 63, 17, "exclusive_pin_use")
QDEF(MP_QSTR_exit, 133, 4, "exit")
QDEF(MP_QSTR_exit_and_deep_sleep_until_alarms, 128, 32, "exit_and_deep_sleep_until_alarms")
QDEF(MP_QSTR_exp, 200, 3, "exp")
QDEF(MP_QSTR_expm1, 116, 5, "expm1")
QDEF(MP_QSTR_ext_hook, 48, 8, "ext_hook")
QDEF(MP_QSTR_extended, 2, 8, "extended")
QDEF(MP_QSTR_extra_clocks, 27, 12, "extra_clocks")
QDEF(MP_QSTR_eye, 188, 3, "eye")
QDEF(MP_QSTR_fabs, 147, 4, "fabs")
QDEF(MP_QSTR_factor_1, 70, 8, "factor_1")
QDEF(MP_QSTR_factor_2, 69, 8, "factor_2")
QDEF(MP_QSTR_fatol, 149, 5, "fatol")
QDEF(MP_QSTR_feed, 167, 4, "feed")
QDEF(MP_QSTR_fft, 145, 3, "fft")
QDEF(MP_QSTR_file, 195, 4, "file")
QDEF(MP_QSTR_filename, 228, 8, "filename")
QDEF(MP_QSTR_filename2, 86, 9, "filename2")
QDEF(MP_QSTR_filesystem, 102, 10, "filesystem")
QDEF(MP_QSTR_fill, 202, 4, "fill")
QDEF(MP_QSTR_fill_color_value, 92, 16, "fill_color_value")
QDEF(MP_QSTR_fill_region, 205, 11, "fill_region")
QDEF(MP_QSTR_fill_row, 127, 8, "fill_row")
QDEF(MP_QSTR_filter, 37, 6, "filter")
QDEF(MP_QSTR_first_in_pin, 175, 12, "first_in_pin")
QDEF(MP_QSTR_first_out_pin, 134, 13, "first_out_pin")
QDEF(MP_QSTR_first_set_pin, 138, 13, "first_set_pin")
QDEF(MP_QSTR_first_sideset_pin, 145, 17, "first_sideset_pin")
QDEF(MP_QSTR_fixed_length, 48, 12, "fixed_length")
QDEF(MP_QSTR_flat, 122, 4, "flat")
QDEF(MP_QSTR_flatiter, 240, 8, "flatiter")
QDEF(MP_QSTR_flatten, 37, 7, "flatten")
QDEF(MP_QSTR_flip, 118, 4, "flip")
QDEF(MP_QSTR_flip_x, 241, 6, "flip_x")
QDEF(MP_QSTR_flip_y, 240, 6, "flip_y")
QDEF(MP_QSTR_float, 53, 5, "float")
QDEF(MP_QSTR_floor, 125, 5, "floor")
QDEF(MP_QSTR_floppyio, 95, 8, "floppyio")
QDEF(MP_QSTR_flush, 97, 5, "flush")
QDEF(MP_QSTR_flux_readinto, 179, 13, "flux_readinto")
QDEF(MP_QSTR_fmin, 41, 4, "fmin")
QDEF(MP_QSTR_fmod, 229, 4, "fmod")
QDEF(MP_QSTR_font, 150, 4, "font")
QDEF(MP_QSTR_fontio, 112, 6, "fontio")
QDEF(MP_QSTR_format_exception, 174, 16, "format_exception")
QDEF(MP_QSTR_framebuffer, 152, 11, "framebuffer")
QDEF(MP_QSTR_framebufferio, 126, 13, "framebufferio")
QDEF(MP_QSTR_frequency, 161, 9, "frequency")
QDEF(MP_QSTR_frexp, 28, 5, "frexp")
QDEF(MP_QSTR_from_file, 10, 9, "from_file")
QDEF(MP_QSTR_from_int16_buffer, 167, 17, "from_int16_buffer")
QDEF(MP_QSTR_from_int32_buffer, 33, 17, "from_int32_buffer")
QDEF(MP_QSTR_from_uint16_buffer, 210, 18, "from_uint16_buffer")
QDEF(MP_QSTR_from_uint32_buffer, 84, 18, "from_uint32_buffer")
QDEF(MP_QSTR_frombuffer, 147, 10, "frombuffer")
QDEF(MP_QSTR_fromkeys, 55, 8, "fromkeys")
QDEF(MP_QSTR_frozenset, 237, 9, "frozenset")
QDEF(MP_QSTR_full, 214, 4, "full")
QDEF(MP_QSTR_function, 39, 8, "function")
QDEF(MP_QSTR_gamma, 2, 5, "gamma")
QDEF(MP_QSTR_gammaln, 128, 7, "gammaln")
QDEF(MP_QSTR_gc, 97, 2, "gc")
QDEF(MP_QSTR_generator, 150, 9, "generator")
QDEF(MP_QSTR_get_answer, 176, 10, "get_answer")
QDEF(MP_QSTR_get_boot_device, 157, 15, "get_boot_device")
QDEF(MP_QSTR_get_bounding_box, 212, 16, "get_bounding_box")
QDEF(MP_QSTR_get_glyph, 166, 9, "get_glyph")
QDEF(MP_QSTR_get_into, 48, 8, "get_into")
QDEF(MP_QSTR_get_key, 219, 7, "get_key")
QDEF(MP_QSTR_get_last_received_report, 7, 24, "get_last_received_report")
QDEF(MP_QSTR_get_previous_traceback, 104, 22, "get_previous_traceback")
QDEF(MP_QSTR_get_printoptions, 77, 16, "get_printoptions")
QDEF(MP_QSTR_get_question, 98, 12, "get_question")
QDEF(MP_QSTR_getcwd, 3, 6, "getcwd")
QDEF(MP_QSTR_getenv, 174, 6, "getenv")
QDEF(MP_QSTR_getmount, 222, 8, "getmount")
QDEF(MP_QSTR_getpass, 66, 7, "getpass")
QDEF(MP_QSTR_getrandbits, 102, 11, "getrandbits")
QDEF(MP_QSTR_getter, 144, 6, "getter")
QDEF(MP_QSTR_getvalue, 120, 8, "getvalue")
QDEF(MP_QSTR_gifio, 203, 5, "gifio")
QDEF(MP_QSTR_grayscale, 16, 9, "grayscale")
QDEF(MP_QSTR_group, 186, 5, "group")
QDEF(MP_QSTR_groups, 137, 6, "groups")
QDEF(MP_QSTR_half_duplex, 233, 11, "half_duplex")
QDEF(MP_QSTR_header, 154, 6, "header")
QDEF(MP_QSTR_heap_lock, 173, 9, "heap_lock")
QDEF(MP_QSTR_heap_unlock, 86, 11, "heap_unlock")
QDEF(MP_QSTR_height, 250, 6, "height")
QDEF(MP_QSTR_help, 148, 4, "help")
QDEF(MP_QSTR_hex, 112, 3, "hex")
QDEF(MP_QSTR_hexlify, 42, 7, "hexlify")
QDEF(MP_QSTR_hidden, 239, 6, "hidden")
QDEF(MP_QSTR_highlight_color, 87, 15, "highlight_color")
QDEF(MP_QSTR_href, 188, 4, "href")
QDEF(MP_QSTR_i, 204, 1, "i")
QDEF(MP_QSTR_i2c, 93, 3, "i2c")
QDEF(MP_QSTR_i2c_bus, 230, 7, "i2c_bus")
QDEF(MP_QSTR_i2c_device, 154, 10, "i2c_device")
QDEF(MP_QSTR_idle_state, 41, 10, "idle_state")
QDEF(MP_QSTR_ifft, 248, 4, "ifft")
QDEF(MP_QSTR_ilistdir, 113, 8, "ilistdir")
QDEF(MP_QSTR_imag, 71, 4, "imag")
QDEF(MP_QSTR_imagecapture, 70, 12, "imagecapture")
QDEF(MP_QSTR_implementation, 23, 14, "implementation")
QDEF(MP_QSTR_in_buffer, 29, 9, "in_buffer")
QDEF(MP_QSTR_in_end, 242, 6, "in_end")
QDEF(MP_QSTR_in_pin_count, 118, 12, "in_pin_count")
QDEF(MP_QSTR_in_report_lengths, 227, 17, "in_report_lengths")
QDEF(MP_QSTR_in_shift_right, 194, 14, "in_shift_right")
QDEF(MP_QSTR_in_start, 125, 8, "in_start")
QDEF(MP_QSTR_in_waiting, 214, 10, "in_waiting")
QDEF(MP_QSTR_incoming_packet_length, 151, 22, "incoming_packet_length")
QDEF(MP_QSTR_indicate, 156, 8, "indicate")
QDEF(MP_QSTR_indices, 90, 7, "indices")
QDEF(MP_QSTR_inf, 4, 3, "inf")
QDEF(MP_QSTR_init, 31, 4, "init")
QDEF(MP_QSTR_init_sequence, 127, 13, "init_sequence")
QDEF(MP_QSTR_initial_out_pin_direction, 216, 25, "initial_out_pin_direction")
QDEF(MP_QSTR_initial_out_pin_state, 106, 21, "initial_out_pin_state")
QDEF(MP_QSTR_initial_set_pin_direction, 212, 25, "initial_set_pin_direction")
QDEF(MP_QSTR_initial_set_pin_state, 102, 21, "initial_set_pin_state")
QDEF(MP_QSTR_initial_sideset_pin_direction, 143, 29, "initial_sideset_pin_direction")
QDEF(MP_QSTR_initial_sideset_pin_state, 253, 25, "initial_sideset_pin_state")
QDEF(MP_QSTR_initial_value, 239, 13, "initial_value")
QDEF(MP_QSTR_inplace, 249, 7, "inplace")
QDEF(MP_QSTR_input, 115, 5, "input")
QDEF(MP_QSTR_input_colorspace, 85, 16, "input_colorspace")
QDEF(MP_QSTR_int16, 241, 5, "int16")
QDEF(MP_QSTR_int8, 238, 4, "int8")
QDEF(MP_QSTR_interp, 241, 6, "interp")
QDEF(MP_QSTR_intersection, 40, 12, "intersection")
QDEF(MP_QSTR_intersection_update, 6, 19, "intersection_update")
QDEF(MP_QSTR_interval, 26, 8, "interval")
QDEF(MP_QSTR_inv, 20, 3, "inv")
QDEF(MP_QSTR_io, 35, 2, "io")
QDEF(MP_QSTR_ioctl, 120, 5, "ioctl")
QDEF(MP_QSTR_ipoll, 83, 5, "ipoll")
QDEF(MP_QSTR_is_transparent, 38, 14, "is_transparent")
QDEF(MP_QSTR_isdisjoint, 247, 10, "isdisjoint")
QDEF(MP_QSTR_isenabled, 154, 9, "isenabled")
QDEF(MP_QSTR_isfinite, 166, 8, "isfinite")
QDEF(MP_QSTR_isinf, 62, 5, "isinf")
QDEF(MP_QSTR_isnan, 158, 5, "isnan")
QDEF(MP_QSTR_iso_8859_hyphen_1, 127, 10, "iso_8859-1")
QDEF(MP_QSTR_iso_8859_hyphen_13, 108, 11, "iso_8859-13")
QDEF(MP_QSTR_iso_8859_hyphen_15, 106, 11, "iso_8859-15")
QDEF(MP_QSTR_iso_8859_hyphen_2, 124, 10, "iso_8859-2")
QDEF(MP_QSTR_iso_8859_hyphen_3, 125, 10, "iso_8859-3")
QDEF(MP_QSTR_iso_8859_hyphen_4, 122, 10, "iso_8859-4")
QDEF(MP_QSTR_iso_8859_hyphen_5, 123, 10, "iso_8859-5")
QDEF(MP_QSTR_iso_8859_hyphen_6, 120, 10, "iso_8859-6")
QDEF(MP_QSTR_iso_8859_hyphen_7, 121, 10, "iso_8859-7")
QDEF(MP_QSTR_iso_8859_hyphen_8, 118, 10, "iso_8859-8")
QDEF(MP_QSTR_iso_8859_hyphen_9, 119, 10, "iso_8859-9")
QDEF(MP_QSTR_issubset, 185, 8, "issubset")
QDEF(MP_QSTR_issuperset, 252, 10, "issuperset")
QDEF(MP_QSTR_itemsize, 117, 8, "itemsize")
QDEF(MP_QSTR_iterable, 37, 8, "iterable")
QDEF(MP_QSTR_iterator, 71, 8, "iterator")
QDEF(MP_QSTR_jmp_pin, 26, 7, "jmp_pin")
QDEF(MP_QSTR_jmp_pin_pull, 128, 12, "jmp_pin_pull")
QDEF(MP_QSTR_jmp_pull, 104, 8, "jmp_pull")
QDEF(MP_QSTR_json, 253, 4, "json")
QDEF(MP_QSTR_k, 206, 1, "k")
QDEF(MP_QSTR_kbd_intr, 246, 8, "kbd_intr")
QDEF(MP_QSTR_keepends, 98, 8, "keepends")
QDEF(MP_QSTR_key_count, 142, 9, "key_count")
QDEF(MP_QSTR_key_number, 110, 10, "key_number")
QDEF(MP_QSTR_key_number_to_row_column, 54, 24, "key_number_to_row_column")
QDEF(MP_QSTR_key_size, 72, 8, "key_size")
QDEF(MP_QSTR_keypad, 231, 6, "keypad")
QDEF(MP_QSTR_label, 67, 5, "label")
QDEF(MP_QSTR_last_received_report, 14, 20, "last_received_report")
QDEF(MP_QSTR_latch, 151, 5, "latch")
QDEF(MP_QSTR_latch_pin, 63, 9, "latch_pin")
QDEF(MP_QSTR_ldexp, 64, 5, "ldexp")
QDEF(MP_QSTR_left, 222, 4, "left")
QDEF(MP_QSTR_left_channel, 226, 12, "left_channel")
QDEF(MP_QSTR_left_justified, 158, 14, "left_justified")
QDEF(MP_QSTR_length, 89, 6, "length")
QDEF(MP_QSTR_level, 211, 5, "level")
QDEF(MP_QSTR_light_sleep_until_alarms, 129, 24, "light_sleep_until_alarms")
QDEF(MP_QSTR_limit, 16, 5, "limit")
QDEF(MP_QSTR_linalg, 68, 6, "linalg")
QDEF(MP_QSTR_linspace, 106, 8, "linspace")
QDEF(MP_QSTR_listdir, 152, 7, "listdir")
QDEF(MP_QSTR_load, 99, 4, "load")
QDEF(MP_QSTR_load_dotenv, 94, 11, "load_dotenv")
QDEF(MP_QSTR_loads, 176, 5, "loads")
QDEF(MP_QSTR_localtime, 125, 9, "localtime")
QDEF(MP_QSTR_location, 152, 8, "location")
QDEF(MP_QSTR_log, 33, 3, "log")
QDEF(MP_QSTR_log10, 64, 5, "log10")
QDEF(MP_QSTR_log2, 115, 4, "log2")
QDEF(MP_QSTR_logspace, 133, 8, "logspace")
QDEF(MP_QSTR_loop, 57, 4, "loop")
QDEF(MP_QSTR_machine, 96, 7, "machine")
QDEF(MP_QSTR_make_opaque, 7, 11, "make_opaque")
QDEF(MP_QSTR_make_transparent, 94, 16, "make_transparent")
QDEF(MP_QSTR_match, 150, 5, "match")
QDEF(MP_QSTR_match_all, 200, 9, "match_all")
QDEF(MP_QSTR_matches, 224, 7, "matches")
QDEF(MP_QSTR_math, 53, 4, "math")
QDEF(MP_QSTR_max, 177, 3, "max")
QDEF(MP_QSTR_max_events, 17, 10, "max_events")
QDEF(MP_QSTR_max_length, 82, 10, "max_length")
QDEF(MP_QSTR_max_packet_length, 69, 17, "max_packet_length")
QDEF(MP_QSTR_max_packet_size, 60, 15, "max_packet_size")
QDEF(MP_QSTR_maximum, 109, 7, "maximum")
QDEF(MP_QSTR_maxiter, 59, 7, "maxiter")
QDEF(MP_QSTR_maxlen, 86, 6, "maxlen")
QDEF(MP_QSTR_maxsize, 212, 7, "maxsize")
QDEF(MP_QSTR_mean, 194, 4, "mean")
QDEF(MP_QSTR_median, 15, 6, "median")
QDEF(MP_QSTR_mem_alloc, 82, 9, "mem_alloc")
QDEF(MP_QSTR_mem_free, 203, 8, "mem_free")
QDEF(MP_QSTR_memoryview, 105, 10, "memoryview")
QDEF(MP_QSTR_mfm_readinto, 114, 12, "mfm_readinto")
QDEF(MP_QSTR_microcontroller, 163, 15, "microcontroller")
QDEF(MP_QSTR_min, 175, 3, "min")
QDEF(MP_QSTR_minimum, 115, 7, "minimum")
QDEF(MP_QSTR_minimum_frames_per_second, 245, 25, "minimum_frames_per_second")
QDEF(MP_QSTR_minimum_rssi, 55, 12, "minimum_rssi")
QDEF(MP_QSTR_mirror_x, 27, 8, "mirror_x")
QDEF(MP_QSTR_mirror_y, 26, 8, "mirror_y")
QDEF(MP_QSTR_miso, 157, 4, "miso")
QDEF(MP_QSTR_mkdir, 156, 5, "mkdir")
QDEF(MP_QSTR_mkfs, 118, 4, "mkfs")
QDEF(MP_QSTR_mktime, 150, 6, "mktime")
QDEF(MP_QSTR_mode, 38, 4, "mode")
QDEF(MP_QSTR_modf, 37, 4, "modf")
QDEF(MP_QSTR_modify, 245, 6, "modify")
QDEF(MP_QSTR_module, 191, 6, "module")
QDEF(MP_QSTR_modules, 236, 7, "modules")
QDEF(MP_QSTR_mono, 102, 4, "mono")
QDEF(MP_QSTR_monotonic, 25, 9, "monotonic")
QDEF(MP_QSTR_monotonic_ns, 59, 12, "monotonic_ns")
QDEF(MP_QSTR_monotonic_time, 147, 14, "monotonic_time")
QDEF(MP_QSTR_mosi, 29, 4, "mosi")
QDEF(MP_QSTR_mount, 168, 5, "mount")
QDEF(MP_QSTR_mount_path, 122, 10, "mount_path")
QDEF(MP_QSTR_mpy, 193, 3, "mpy")
QDEF(MP_QSTR_msgpack, 69, 7, "msgpack")
QDEF(MP_QSTR_n, 203, 1, "n")
QDEF(MP_QSTR_name, 162, 4, "name")
QDEF(MP_QSTR_namedtuple, 30, 10, "namedtuple")
QDEF(MP_QSTR_nan, 228, 3, "nan")
QDEF(MP_QSTR_native, 132, 6, "native")
QDEF(MP_QSTR_native_frames_per_second, 66, 24, "native_frames_per_second")
QDEF(MP_QSTR_ndarray, 118, 7, "ndarray")
QDEF(MP_QSTR_ndinfo, 161, 6, "ndinfo")
QDEF(MP_QSTR_neopixel_write, 43, 14, "neopixel_write")
QDEF(MP_QSTR_newton, 76, 6, "newton")
QDEF(MP_QSTR_nodename, 98, 8, "nodename")
QDEF(MP_QSTR_norm, 27, 4, "norm")
QDEF(MP_QSTR_not_equal, 99, 9, "not_equal")
QDEF(MP_QSTR_notify, 6, 6, "notify")
QDEF(MP_QSTR_num, 115, 3, "num")
QDEF(MP_QSTR_numpy, 122, 5, "numpy")
QDEF(MP_QSTR_nvm, 144, 3, "nvm")
QDEF(MP_QSTR_obj, 2, 3, "obj")
QDEF(MP_QSTR_oct, 253, 3, "oct")
QDEF(MP_QSTR_offset, 72, 6, "offset")
QDEF(MP_QSTR_on_next_reset, 182, 13, "on_next_reset")
QDEF(MP_QSTR_once, 2, 4, "once")
QDEF(MP_QSTR_ones, 210, 4, "ones")
QDEF(MP_QSTR_onewireio, 14, 9, "onewireio")
QDEF(MP_QSTR_opt_level, 135, 9, "opt_level")
QDEF(MP_QSTR_optimize, 220, 8, "optimize")
QDEF(MP_QSTR_order, 107, 5, "order")
QDEF(MP_QSTR_os, 121, 2, "os")
QDEF(MP_QSTR_otypes, 225, 6, "otypes")
QDEF(MP_QSTR_out, 43, 3, "out")
QDEF(MP_QSTR_out_buffer, 244, 10, "out_buffer")
QDEF(MP_QSTR_out_end, 123, 7, "out_end")
QDEF(MP_QSTR_out_pin_count, 255, 13, "out_pin_count")
QDEF(MP_QSTR_out_report_lengths, 74, 18, "out_report_lengths")
QDEF(MP_QSTR_out_shift_right, 11, 15, "out_shift_right")
QDEF(MP_QSTR_out_start, 244, 9, "out_start")
QDEF(MP_QSTR_out_waiting, 159, 11, "out_waiting")
QDEF(MP_QSTR_outgoing_packet_length, 247, 22, "outgoing_packet_length")
QDEF(MP_QSTR_output, 154, 6, "output")
QDEF(MP_QSTR_output_enable_pin, 236, 17, "output_enable_pin")
QDEF(MP_QSTR_overflowed, 152, 10, "overflowed")
QDEF(MP_QSTR_oversample, 77, 10, "oversample")
QDEF(MP_QSTR_ox, 114, 2, "ox")
QDEF(MP_QSTR_oy, 115, 2, "oy")
QDEF(MP_QSTR_pack, 188, 4, "pack")
QDEF(MP_QSTR_pack_into, 31, 9, "pack_into")
QDEF(MP_QSTR_pair, 239, 4, "pair")
QDEF(MP_QSTR_paired, 142, 6, "paired")
QDEF(MP_QSTR_paralleldisplay, 148, 15, "paralleldisplay")
QDEF(MP_QSTR_parity, 66, 6, "parity")
QDEF(MP_QSTR_partition, 135, 9, "partition")
QDEF(MP_QSTR_path, 136, 4, "path")
QDEF(MP_QSTR_pause, 215, 5, "pause")
QDEF(MP_QSTR_paused, 211, 6, "paused")
QDEF(MP_QSTR_payload, 75, 7, "payload")
QDEF(MP_QSTR_peek, 126, 4, "peek")
QDEF(MP_QSTR_pend_throw, 243, 10, "pend_throw")
QDEF(MP_QSTR_pending, 186, 7, "pending")
QDEF(MP_QSTR_ph_key, 245, 6, "ph_key")
QDEF(MP_QSTR_phase, 106, 5, "phase")
QDEF(MP_QSTR_pi, 28, 2, "pi")
QDEF(MP_QSTR_pin, 242, 3, "pin")
QDEF(MP_QSTR_pin_a, 108, 5, "pin_a")
QDEF(MP_QSTR_pin_b, 111, 5, "pin_b")
QDEF(MP_QSTR_pins, 65, 4, "pins")
QDEF(MP_QSTR_pins_are_sequential, 94, 19, "pins_are_sequential")
QDEF(MP_QSTR_pixel_policy, 210, 12, "pixel_policy")
QDEF(MP_QSTR_pixel_shader, 91, 12, "pixel_shader")
QDEF(MP_QSTR_pixels_in_byte_share_row, 212, 24, "pixels_in_byte_share_row")
QDEF(MP_QSTR_platform, 58, 8, "platform")
QDEF(MP_QSTR_play, 33, 4, "play")
QDEF(MP_QSTR_playing, 97, 7, "playing")
QDEF(MP_QSTR_point, 233, 5, "point")
QDEF(MP_QSTR_points, 122, 6, "points")
QDEF(MP_QSTR_polarity, 65, 8, "polarity")
QDEF(MP_QSTR_poll, 154, 4, "poll")
QDEF(MP_QSTR_polyfit, 52, 7, "polyfit")
QDEF(MP_QSTR_polyval, 52, 7, "polyval")
QDEF(MP_QSTR_pop_head, 29, 8, "pop_head")
QDEF(MP_QSTR_popleft, 113, 7, "popleft")
QDEF(MP_QSTR_ports, 175, 5, "ports")
QDEF(MP_QSTR_position, 28, 8, "position")
QDEF(MP_QSTR_prefixes, 35, 8, "prefixes")
QDEF(MP_QSTR_pressed, 3, 7, "pressed")
QDEF(MP_QSTR_print_exception, 28, 15, "print_exception")
QDEF(MP_QSTR_probe, 79, 5, "probe")
QDEF(MP_QSTR_program, 209, 7, "program")
QDEF(MP_QSTR_prompt, 225, 6, "prompt")
QDEF(MP_QSTR_properties, 36, 10, "properties")
QDEF(MP_QSTR_property, 194, 8, "property")
QDEF(MP_QSTR_protocol_audiosample, 188, 20, "protocol_audiosample")
QDEF(MP_QSTR_protocol_draw, 44, 13, "protocol_draw")
QDEF(MP_QSTR_protocol_framebuffer, 241, 20, "protocol_framebuffer")
QDEF(MP_QSTR_protocol_stream, 144, 15, "protocol_stream")
QDEF(MP_QSTR_protocol_vfs, 239, 12, "protocol_vfs")
QDEF(MP_QSTR_pull, 128, 4, "pull")
QDEF(MP_QSTR_pull_in_pin_down, 253, 16, "pull_in_pin_down")
QDEF(MP_QSTR_pull_in_pin_up, 234, 14, "pull_in_pin_up")
QDEF(MP_QSTR_pull_threshold, 232, 14, "pull_threshold")
QDEF(MP_QSTR_pulseio, 252, 7, "pulseio")
QDEF(MP_QSTR_push_head, 108, 9, "push_head")
QDEF(MP_QSTR_push_sorted, 31, 11, "push_sorted")
QDEF(MP_QSTR_push_threshold, 147, 14, "push_threshold")
QDEF(MP_QSTR_pwmio, 73, 5, "pwmio")
QDEF(MP_QSTR_px, 13, 2, "px")
QDEF(MP_QSTR_py, 12, 2, "py")
QDEF(MP_QSTR_pystack_use, 254, 11, "pystack_use")
QDEF(MP_QSTR_qr, 38, 2, "qr")
QDEF(MP_QSTR_qrio, 1, 4, "qrio")
QDEF(MP_QSTR_quiescent_value, 246, 15, "quiescent_value")
QDEF(MP_QSTR_r, 215, 1, "r")
QDEF(MP_QSTR_radians, 135, 7, "radians")
QDEF(MP_QSTR_radius, 253, 6, "radius")
QDEF(MP_QSTR_rainbowio, 173, 9, "rainbowio")
QDEF(MP_QSTR_ram_height, 59, 10, "ram_height")
QDEF(MP_QSTR_ram_width, 130, 9, "ram_width")
QDEF(MP_QSTR_randint, 175, 7, "randint")
QDEF(MP_QSTR_random, 190, 6, "random")
QDEF(MP_QSTR_randrange, 163, 9, "randrange")
QDEF(MP_QSTR_raw_value, 245, 9, "raw_value")
QDEF(MP_QSTR_rb, 213, 2, "rb")
QDEF(MP_QSTR_re, 210, 2, "re")
QDEF(MP_QSTR_read_bit, 151, 8, "read_bit")
QDEF(MP_QSTR_read_perm, 130, 9, "read_perm")
QDEF(MP_QSTR_read_register, 161, 13, "read_register")
QDEF(MP_QSTR_readblocks, 45, 10, "readblocks")
QDEF(MP_QSTR_readfrom_into, 130, 13, "readfrom_into")
QDEF(MP_QSTR_readlines, 106, 9, "readlines")
QDEF(MP_QSTR_readonly, 3, 8, "readonly")
QDEF(MP_QSTR_real, 191, 4, "real")
QDEF(MP_QSTR_receiver_buffer_size, 153, 20, "receiver_buffer_size")
QDEF(MP_QSTR_record, 40, 6, "record")
QDEF(MP_QSTR_reduced, 33, 7, "reduced")
QDEF(MP_QSTR_reference_voltage, 147, 17, "reference_voltage")
QDEF(MP_QSTR_refresh, 152, 7, "refresh")
QDEF(MP_QSTR_refresh_display_command, 5, 23, "refresh_display_command")
QDEF(MP_QSTR_refresh_time, 178, 12, "refresh_time")
QDEF(MP_QSTR_register, 172, 8, "register")
QDEF(MP_QSTR_rekey, 5, 5, "rekey")
QDEF(MP_QSTR_release, 236, 7, "release")
QDEF(MP_QSTR_release_displays, 58, 16, "release_displays")
QDEF(MP_QSTR_released, 8, 8, "released")
QDEF(MP_QSTR_reload, 116, 6, "reload")
QDEF(MP_QSTR_reload_on_error, 45, 15, "reload_on_error")
QDEF(MP_QSTR_reload_on_success, 118, 17, "reload_on_success")
QDEF(MP_QSTR_remote, 161, 6, "remote")
QDEF(MP_QSTR_remount, 159, 7, "remount")
QDEF(MP_QSTR_rename, 53, 6, "rename")
QDEF(MP_QSTR_replaced_color_value, 155, 20, "replaced_color_value")
QDEF(MP_QSTR_report, 139, 6, "report")
QDEF(MP_QSTR_report_descriptor, 103, 17, "report_descriptor")
QDEF(MP_QSTR_report_id, 153, 9, "report_id")
QDEF(MP_QSTR_report_ids, 202, 10, "report_ids")
QDEF(MP_QSTR_reset, 16, 5, "reset")
QDEF(MP_QSTR_reset_input_buffer, 230, 18, "reset_input_buffer")
QDEF(MP_QSTR_reset_output_buffer, 239, 19, "reset_output_buffer")
QDEF(MP_QSTR_reset_reason, 11, 12, "reset_reason")
QDEF(MP_QSTR_reset_terminal, 11, 14, "reset_terminal")
QDEF(MP_QSTR_reshape, 125, 7, "reshape")
QDEF(MP_QSTR_restart, 178, 7, "restart")
QDEF(MP_QSTR_resume, 92, 6, "resume")
QDEF(MP_QSTR_retstep, 52, 7, "retstep")
QDEF(MP_QSTR_reverse_bytes_in_word, 42, 21, "reverse_bytes_in_word")
QDEF(MP_QSTR_reverse_pixels_in_byte, 236, 22, "reverse_pixels_in_byte")
QDEF(MP_QSTR_reverse_pixels_in_element, 56, 25, "reverse_pixels_in_element")
QDEF(MP_QSTR_reverse_rows, 163, 12, "reverse_rows")
QDEF(MP_QSTR_reversed, 161, 8, "reversed")
QDEF(MP_QSTR_rgb_pins, 233, 8, "rgb_pins")
QDEF(MP_QSTR_rgbmatrix, 105, 9, "rgbmatrix")
QDEF(MP_QSTR_right, 229, 5, "right")
QDEF(MP_QSTR_right_channel, 25, 13, "right_channel")
QDEF(MP_QSTR_rmdir, 69, 5, "rmdir")
QDEF(MP_QSTR_rms_level, 224, 9, "rms_level")
QDEF(MP_QSTR_roll, 88, 4, "roll")
QDEF(MP_QSTR_root_group, 131, 10, "root_group")
QDEF(MP_QSTR_rotaryio, 224, 8, "rotaryio")
QDEF(MP_QSTR_rotation, 241, 8, "rotation")
QDEF(MP_QSTR_rotozoom, 52, 8, "rotozoom")
QDEF(MP_QSTR_row, 175, 3, "row")
QDEF(MP_QSTR_row_column_to_key_number, 246, 24, "row_column_to_key_number")
QDEF(MP_QSTR_row_pins, 20, 8, "row_pins")
QDEF(MP_QSTR_rowstart, 47, 8, "rowstart")
QDEF(MP_QSTR_rp2pio, 99, 6, "rp2pio")
QDEF(MP_QSTR_rpartition, 21, 10, "rpartition")
QDEF(MP_QSTR_rs485_dir, 221, 9, "rs485_dir")
QDEF(MP_QSTR_rs485_invert, 176, 12, "rs485_invert")
QDEF(MP_QSTR_rssi, 126, 4, "rssi")
QDEF(MP_QSTR_rtc, 64, 3, "rtc")
QDEF(MP_QSTR_rtol, 160, 4, "rtol")
QDEF(MP_QSTR_rts, 80, 3, "rts")
QDEF(MP_QSTR_run, 108, 3, "run")
QDEF(MP_QSTR_run_mode, 208, 8, "run_mode")
QDEF(MP_QSTR_run_reason, 119, 10, "run_reason")
QDEF(MP_QSTR_runtime, 153, 7, "runtime")
QDEF(MP_QSTR_rx, 207, 2, "rx")
QDEF(MP_QSTR_rxstall, 201, 7, "rxstall")
QDEF(MP_QSTR_sample, 3, 6, "sample")
QDEF(MP_QSTR_sample_rate, 126, 11, "sample_rate")
QDEF(MP_QSTR_samplerate, 193, 10, "samplerate")
QDEF(MP_QSTR_samples_decoded, 167, 15, "samples_decoded")
QDEF(MP_QSTR_samples_signed, 125, 14, "samples_signed")
QDEF(MP_QSTR_scale, 125, 5, "scale")
QDEF(MP_QSTR_scan, 26, 4, "scan")
QDEF(MP_QSTR_scan_response, 230, 13, "scan_response")
QDEF(MP_QSTR_scipy, 245, 5, "scipy")
QDEF(MP_QSTR_scl, 249, 3, "scl")
QDEF(MP_QSTR_sda, 83, 3, "sda")
QDEF(MP_QSTR_sdcardio, 160, 8, "sdcardio")
QDEF(MP_QSTR_search, 171, 6, "search")
QDEF(MP_QSTR_secondary, 159, 9, "secondary")
QDEF(MP_QSTR_seconds_per_frame, 92, 17, "seconds_per_frame")
QDEF(MP_QSTR_security_mode, 143, 13, "security_mode")
QDEF(MP_QSTR_seed, 146, 4, "seed")
QDEF(MP_QSTR_seek, 157, 4, "seek")
QDEF(MP_QSTR_segment_size, 252, 12, "segment_size")
QDEF(MP_QSTR_select, 141, 6, "select")
QDEF(MP_QSTR_send_report, 8, 11, "send_report")
QDEF(MP_QSTR_separators, 235, 10, "separators")
QDEF(MP_QSTR_serial_bytes_available, 69, 22, "serial_bytes_available")
QDEF(MP_QSTR_serial_connected, 165, 16, "serial_connected")
QDEF(MP_QSTR_serpentine, 12, 10, "serpentine")
QDEF(MP_QSTR_service, 152, 7, "service")
QDEF(MP_QSTR_service_uuids_whitelist, 195, 23, "service_uuids_whitelist")
QDEF(MP_QSTR_set_adapter, 15, 11, "set_adapter")
QDEF(MP_QSTR_set_boundary, 96, 12, "set_boundary")
QDEF(MP_QSTR_set_cccd, 159, 8, "set_cccd")
QDEF(MP_QSTR_set_column_command, 22, 18, "set_column_command")
QDEF(MP_QSTR_set_column_window_command, 5, 25, "set_column_window_command")
QDEF(MP_QSTR_set_current_column_command, 160, 26, "set_current_column_command")
QDEF(MP_QSTR_set_current_row_command, 252, 23, "set_current_row_command")
QDEF(MP_QSTR_set_next_code_file, 244, 18, "set_next_code_file")
QDEF(MP_QSTR_set_next_stack_limit, 164, 20, "set_next_stack_limit")
QDEF(MP_QSTR_set_pin_count, 243, 13, "set_pin_count")
QDEF(MP_QSTR_set_printoptions, 217, 16, "set_printoptions")
QDEF(MP_QSTR_set_rgb_status_brightness, 146, 25, "set_rgb_status_brightness")
QDEF(MP_QSTR_set_row_command, 202, 15, "set_row_command")
QDEF(MP_QSTR_set_row_window_command, 217, 22, "set_row_window_command")
QDEF(MP_QSTR_set_time_source, 175, 15, "set_time_source")
QDEF(MP_QSTR_set_vertical_scroll, 56, 19, "set_vertical_scroll")
QDEF(MP_QSTR_setter, 4, 6, "setter")
QDEF(MP_QSTR_shape, 202, 5, "shape")
QDEF(MP_QSTR_sharpdisplay, 7, 12, "sharpdisplay")
QDEF(MP_QSTR_shift_underscore_jis, 85, 20, "shift_underscore_jis")
QDEF(MP_QSTR_shift_x, 194, 7, "shift_x")
QDEF(MP_QSTR_shift_y, 195, 7, "shift_y")
QDEF(MP_QSTR_show, 134, 4, "show")
QDEF(MP_QSTR_sideset_enable, 34, 14, "sideset_enable")
QDEF(MP_QSTR_sideset_pin_count, 40, 17, "sideset_pin_count")
QDEF(MP_QSTR_signal, 187, 6, "signal")
QDEF(MP_QSTR_signed, 55, 6, "signed")
QDEF(MP_QSTR_sin, 177, 3, "sin")
QDEF(MP_QSTR_single_byte_bounds, 52, 18, "single_byte_bounds")
QDEF(MP_QSTR_sinh, 185, 4, "sinh")
QDEF(MP_QSTR_size, 32, 4, "size")
QDEF(MP_QSTR_skip_index, 101, 10, "skip_index")
QDEF(MP_QSTR_sleep, 234, 5, "sleep")
QDEF(MP_QSTR_sleep_memory, 244, 12, "sleep_memory")
QDEF(MP_QSTR_slice, 181, 5, "slice")
QDEF(MP_QSTR_solve_triangular, 20, 16, "solve_triangular")
QDEF(MP_QSTR_sos, 106, 3, "sos")
QDEF(MP_QSTR_sosfilt, 189, 7, "sosfilt")
QDEF(MP_QSTR_source_bitmap, 196, 13, "source_bitmap")
QDEF(MP_QSTR_source_bitmap_1, 74, 15, "source_bitmap_1")
QDEF(MP_QSTR_source_bitmap_2, 73, 15, "source_bitmap_2")
QDEF(MP_QSTR_source_clip0, 97, 12, "source_clip0")
QDEF(MP_QSTR_source_clip1, 96, 12, "source_clip1")
QDEF(MP_QSTR_source_colorspace, 62, 17, "source_colorspace")
QDEF(MP_QSTR_span, 201, 4, "span")
QDEF(MP_QSTR_special, 68, 7, "special")
QDEF(MP_QSTR_spectrogram, 48, 11, "spectrogram")
QDEF(MP_QSTR_spi, 207, 3, "spi")
QDEF(MP_QSTR_spi_bus, 244, 7, "spi_bus")
QDEF(MP_QSTR_spi_device, 200, 10, "spi_device")
QDEF(MP_QSTR_splitlines, 106, 10, "splitlines")
QDEF(MP_QSTR_sqrt, 33, 4, "sqrt")
QDEF(MP_QSTR_start_advertising, 16, 17, "start_advertising")
QDEF(MP_QSTR_start_scan, 101, 10, "start_scan")
QDEF(MP_QSTR_start_sequence, 37, 14, "start_sequence")
QDEF(MP_QSTR_startup_delay, 170, 13, "startup_delay")
QDEF(MP_QSTR_stat, 215, 4, "stat")
QDEF(MP_QSTR_state, 210, 5, "state")
QDEF(MP_QSTR_statvfs, 20, 7, "statvfs")
QDEF(MP_QSTR_std, 70, 3, "std")
QDEF(MP_QSTR_stderr, 163, 6, "stderr")
QDEF(MP_QSTR_stdin, 33, 5, "stdin")
QDEF(MP_QSTR_stdout, 8, 6, "stdout")
QDEF(MP_QSTR_sticky_on_error, 99, 15, "sticky_on_error")
QDEF(MP_QSTR_sticky_on_reload, 106, 16, "sticky_on_reload")
QDEF(MP_QSTR_sticky_on_success, 184, 17, "sticky_on_success")
QDEF(MP_QSTR_stop_advertising, 8, 16, "stop_advertising")
QDEF(MP_QSTR_stop_background_write, 78, 21, "stop_background_write")
QDEF(MP_QSTR_stop_scan, 125, 9, "stop_scan")
QDEF(MP_QSTR_stop_sequence, 61, 13, "stop_sequence")
QDEF(MP_QSTR_stop_voice, 20, 10, "stop_voice")
QDEF(MP_QSTR_storage, 188, 7, "storage")
QDEF(MP_QSTR_stream, 89, 6, "stream")
QDEF(MP_QSTR_strerror, 72, 8, "strerror")
QDEF(MP_QSTR_strides, 203, 7, "strides")
QDEF(MP_QSTR_struct, 18, 6, "struct")
QDEF(MP_QSTR_struct_time, 248, 11, "struct_time")
QDEF(MP_QSTR_sub, 33, 3, "sub")
QDEF(MP_QSTR_supervisor, 53, 10, "supervisor")
QDEF(MP_QSTR_swap, 16, 4, "swap")
QDEF(MP_QSTR_swap_bytes_in_element, 207, 21, "swap_bytes_in_element")
QDEF(MP_QSTR_swap_in, 104, 7, "swap_in")
QDEF(MP_QSTR_swap_out, 161, 8, "swap_out")
QDEF(MP_QSTR_switch_to_input, 250, 15, "switch_to_input")
QDEF(MP_QSTR_switch_to_output, 243, 16, "switch_to_output")
QDEF(MP_QSTR_symmetric_difference, 206, 20, "symmetric_difference")
QDEF(MP_QSTR_symmetric_difference_update, 96, 27, "symmetric_difference_update")
QDEF(MP_QSTR_sync, 162, 4, "sync")
QDEF(MP_QSTR_synthio, 91, 7, "synthio")
QDEF(MP_QSTR_sys, 188, 3, "sys")
QDEF(MP_QSTR_sysname, 155, 7, "sysname")
QDEF(MP_QSTR_tan, 254, 3, "tan")
QDEF(MP_QSTR_tanh, 214, 4, "tanh")
QDEF(MP_QSTR_target_frames_per_second, 114, 24, "target_frames_per_second")
QDEF(MP_QSTR_tb, 147, 2, "tb")
QDEF(MP_QSTR_tell, 20, 4, "tell")
QDEF(MP_QSTR_temperature, 233, 11, "temperature")
QDEF(MP_QSTR_tempo, 102, 5, "tempo")
QDEF(MP_QSTR_terminalio, 103, 10, "terminalio")
QDEF(MP_QSTR_threshold, 242, 9, "threshold")
QDEF(MP_QSTR_ticks_ms, 66, 8, "ticks_ms")
QDEF(MP_QSTR_tile, 17, 4, "tile")
QDEF(MP_QSTR_tile_height, 145, 11, "tile_height")
QDEF(MP_QSTR_tile_index, 176, 10, "tile_index")
QDEF(MP_QSTR_tile_width, 232, 10, "tile_width")
QDEF(MP_QSTR_tilegrid, 73, 8, "tilegrid")
QDEF(MP_QSTR_time, 240, 4, "time")
QDEF(MP_QSTR_time_to_refresh, 246, 15, "time_to_refresh")
QDEF(MP_QSTR_timeout, 62, 7, "timeout")
QDEF(MP_QSTR_timestamp, 107, 9, "timestamp")
QDEF(MP_QSTR_tm_hour, 163, 7, "tm_hour")
QDEF(MP_QSTR_tm_isdst, 218, 8, "tm_isdst")
QDEF(MP_QSTR_tm_mday, 210, 7, "tm_mday")
QDEF(MP_QSTR_tm_min, 169, 6, "tm_min")
QDEF(MP_QSTR_tm_mon, 111, 6, "tm_mon")
QDEF(MP_QSTR_tm_sec, 54, 6, "tm_sec")
QDEF(MP_QSTR_tm_wday, 8, 7, "tm_wday")
QDEF(MP_QSTR_tm_yday, 70, 7, "tm_yday")
QDEF(MP_QSTR_tm_year, 140, 7, "tm_year")
QDEF(MP_QSTR_tobytes, 167, 7, "tobytes")
QDEF(MP_QSTR_toggle_every_byte, 64, 17, "toggle_every_byte")
QDEF(MP_QSTR_tol, 50, 3, "tol")
QDEF(MP_QSTR_tolist, 124, 6, "tolist")
QDEF(MP_QSTR_touch, 128, 5, "touch")
QDEF(MP_QSTR_touchio, 102, 7, "touchio")
QDEF(MP_QSTR_trace, 164, 5, "trace")
QDEF(MP_QSTR_traceback, 207, 9, "traceback")
QDEF(MP_QSTR_trailer, 16, 7, "trailer")
QDEF(MP_QSTR_transpose, 246, 9, "transpose")
QDEF(MP_QSTR_transpose_xy, 232, 12, "transpose_xy")
QDEF(MP_QSTR_trapz, 136, 5, "trapz")
QDEF(MP_QSTR_trigger_duration, 28, 16, "trigger_duration")
QDEF(MP_QSTR_trunc, 91, 5, "trunc")
QDEF(MP_QSTR_try_lock, 46, 8, "try_lock")
QDEF(MP_QSTR_two_byte_sequence_length, 95, 24, "two_byte_sequence_length")
QDEF(MP_QSTR_tx, 137, 2, "tx")
QDEF(MP_QSTR_tx_power, 201, 8, "tx_power")
QDEF(MP_QSTR_txstall, 207, 7, "txstall")
QDEF(MP_QSTR_uart, 119, 4, "uart")
QDEF(MP_QSTR_uid, 189, 3, "uid")
QDEF(MP_QSTR_uint16, 132, 6, "uint16")
QDEF(MP_QSTR_uint8, 123, 5, "uint8")
QDEF(MP_QSTR_ulab, 159, 4, "ulab")
QDEF(MP_QSTR_ulab_dot_fft, 197, 8, "ulab.fft")
QDEF(MP_QSTR_ulab_dot_linalg, 144, 11, "ulab.linalg")
QDEF(MP_QSTR_ulab_dot_numpy, 174, 10, "ulab.numpy")
QDEF(MP_QSTR_ulab_dot_scipy, 33, 10, "ulab.scipy")
QDEF(MP_QSTR_ulab_dot_scipy_dot_linalg, 46, 17, "ulab.scipy.linalg")
QDEF(MP_QSTR_ulab_dot_scipy_dot_optimize, 54, 19, "ulab.scipy.optimize")
QDEF(MP_QSTR_ulab_dot_scipy_dot_signal, 17, 17, "ulab.scipy.signal")
QDEF(MP_QSTR_ulab_dot_scipy_dot_special, 46, 18, "ulab.scipy.special")
QDEF(MP_QSTR_ulab_dot_utils, 6, 10, "ulab.utils")
QDEF(MP_QSTR_umount, 221, 6, "umount")
QDEF(MP_QSTR_uname, 183, 5, "uname")
QDEF(MP_QSTR_unhexlify, 177, 9, "unhexlify")
QDEF(MP_QSTR_uniform, 1, 7, "uniform")
QDEF(MP_QSTR_union, 246, 5, "union")
QDEF(MP_QSTR_unlink, 254, 6, "unlink")
QDEF(MP_QSTR_unlock, 21, 6, "unlock")
QDEF(MP_QSTR_unpack, 7, 6, "unpack")
QDEF(MP_QSTR_unpack_from, 14, 11, "unpack_from")
QDEF(MP_QSTR_unregister, 23, 10, "unregister")
QDEF(MP_QSTR_update_refresh_mode, 138, 19, "update_refresh_mode")
QDEF(MP_QSTR_urandom, 171, 7, "urandom")
QDEF(MP_QSTR_usage, 1, 5, "usage")
QDEF(MP_QSTR_usage_page, 236, 10, "usage_page")
QDEF(MP_QSTR_usb_cdc, 122, 7, "usb_cdc")
QDEF(MP_QSTR_usb_connected, 65, 13, "usb_connected")
QDEF(MP_QSTR_usb_hid, 219, 7, "usb_hid")
QDEF(MP_QSTR_usb_midi, 183, 8, "usb_midi")
QDEF(MP_QSTR_use_list, 155, 8, "use_list")
QDEF(MP_QSTR_uselect, 88, 7, "uselect")
QDEF(MP_QSTR_user_description, 141, 16, "user_description")
QDEF(MP_QSTR_user_interruptible, 78, 18, "user_interruptible")
QDEF(MP_QSTR_utils, 210, 5, "utils")
QDEF(MP_QSTR_uuid, 200, 4, "uuid")
QDEF(MP_QSTR_uuid128, 179, 7, "uuid128")
QDEF(MP_QSTR_uuid16, 47, 6, "uuid16")
QDEF(MP_QSTR_v, 211, 1, "v")
QDEF(MP_QSTR_value_to_latch, 71, 14, "value_to_latch")
QDEF(MP_QSTR_value_when_pressed, 28, 18, "value_when_pressed")
QDEF(MP_QSTR_variable_frequency, 88, 18, "variable_frequency")
QDEF(MP_QSTR_vectorio, 186, 8, "vectorio")
QDEF(MP_QSTR_vectorize, 234, 9, "vectorize")
QDEF(MP_QSTR_version, 191, 7, "version")
QDEF(MP_QSTR_version_info, 110, 12, "version_info")
QDEF(MP_QSTR_voice, 147, 5, "voice")
QDEF(MP_QSTR_voice_count, 111, 11, "voice_count")
QDEF(MP_QSTR_voltage, 135, 7, "voltage")
QDEF(MP_QSTR_vsync, 116, 5, "vsync")
QDEF(MP_QSTR_wait_for_txstall, 191, 16, "wait_for_txstall")
QDEF(MP_QSTR_wake_alarm, 209, 10, "wake_alarm")
QDEF(MP_QSTR_watchdog, 1, 8, "watchdog")
QDEF(MP_QSTR_wb, 112, 2, "wb")
QDEF(MP_QSTR_where, 8, 5, "where")
QDEF(MP_QSTR_width, 35, 5, "width")
QDEF(MP_QSTR_window, 137, 6, "window")
QDEF(MP_QSTR_word_select, 92, 11, "word_select")
QDEF(MP_QSTR_wrap, 81, 4, "wrap")
QDEF(MP_QSTR_wrap_target, 95, 11, "wrap_target")
QDEF(MP_QSTR_write_bit, 248, 9, "write_bit")
QDEF(MP_QSTR_write_black_ram_command, 25, 23, "write_black_ram_command")
QDEF(MP_QSTR_write_color_ram_command, 99, 23, "write_color_ram_command")
QDEF(MP_QSTR_write_perm, 13, 10, "write_perm")
QDEF(MP_QSTR_write_ram_command, 33, 17, "write_ram_command")
QDEF(MP_QSTR_write_readinto, 137, 14, "write_readinto")
QDEF(MP_QSTR_write_register, 238, 14, "write_register")
QDEF(MP_QSTR_write_then_readinto, 97, 19, "write_then_readinto")
QDEF(MP_QSTR_write_timeout, 60, 13, "write_timeout")
QDEF(MP_QSTR_write_value, 76, 11, "write_value")
QDEF(MP_QSTR_writeblocks, 2, 11, "writeblocks")
QDEF(MP_QSTR_writeto, 3, 7, "writeto")
QDEF(MP_QSTR_writeto_then_readfrom, 112, 21, "writeto_then_readfrom")
QDEF(MP_QSTR_writing, 221, 7, "writing")
QDEF(MP_QSTR_x, 221, 1, "x")
QDEF(MP_QSTR_x1, 76, 2, "x1")
QDEF(MP_QSTR_x2, 79, 2, "x2")
QDEF(MP_QSTR_xatol, 11, 5, "xatol")
QDEF(MP_QSTR_xtol, 106, 4, "xtol")
QDEF(MP_QSTR_y, 220, 1, "y")
QDEF(MP_QSTR_y1, 109, 2, "y1")
QDEF(MP_QSTR_y2, 110, 2, "y2")
QDEF(MP_QSTR_zeros, 148, 5, "zeros")
QDEF(MP_QSTR_zi, 214, 2, "zi")
QDEF(MP_QSTR_zlib, 248, 4, "zlib")
TRANSLATION("  File \"%q\", line %d", 20, 3, 130, 171, 3, 233, 206, 250, 120, 207, 188, 222, 216) //   File \"%q\", line %d
TRANSLATION(" is of type %q\n", 16, 194, 195, 239, 9, 219, 32) //  is of type %q\r\n
TRANSLATION(" not found.\n", 13, 154, 239, 101, 20, 54, 64) //  not found.\r\n
TRANSLATION(" output:\n", 10, 26, 221, 173, 230, 200) //  output:\r\n
TRANSLATION("%%c requires int or char", 24, 242, 252, 179, 249, 4, 30, 96, 180, 125, 57, 0) // %%c requires int or char
TRANSLATION("%d address pins, %d rgb pins and %d tiles indicate a height of %d, not %d", 73, 219, 3, 33, 22, 200, 132, 111, 22, 54, 216, 73, 81, 161, 27, 196, 57, 187, 96, 197, 88, 32, 242, 20, 122, 77, 152, 85, 79, 229, 195, 219, 99, 124, 91, 96) // %d address pins, %d rgb pins and %d tiles indicate a height of %d, not %d
TRANSLATION("%q", 2, 156) // %q
TRANSLATION("%q and %q contain duplicate pins", 32, 156, 57, 179, 129, 226, 97, 158, 8, 240, 123, 212, 155, 141, 226) // %q and %q contain duplicate pins
TRANSLATION("%q contains duplicate pins", 26, 156, 15, 19, 12, 241, 4, 120, 61, 234, 77, 198, 241, 0) // %q contains duplicate pins
TRANSLATION("%q in use", 9, 156, 30, 218, 0) // %q in use
TRANSLATION("%q index out of range", 21, 156, 30, 70, 144, 214, 195, 249, 82) // %q index out of range
TRANSLATION("%q indices must be integers, not %s", 35, 156, 30, 66, 142, 146, 152, 243, 19, 81, 194, 198, 248, 188, 178) // %q indices must be integers, not %s
TRANSLATION("%q init failed", 14, 156, 30, 174, 29, 50, 172, 32) // %q init failed
TRANSLATION("%q length must be %d", 20, 156, 53, 38, 109, 128) // %q length must be %d
TRANSLATION("%q length must be %d-%d", 23, 156, 53, 38, 109, 177, 246, 192) // %q length must be %d-%d
TRANSLATION("%q length must be <= %d", 23, 156, 53, 38, 125, 109, 238, 0) // %q length must be <= %d
TRANSLATION("%q length must be >= %d", 23, 156, 53, 38, 122, 91, 220, 0) // %q length must be >= %d
TRANSLATION("%q length must be >= 1", 22, 156, 53, 38, 122, 91, 209, 186) // %q length must be >= 1
TRANSLATION("%q must be %d", 13, 157, 51, 108) // %q must be %d
TRANSLATION("%q must be %d-%d", 16, 157, 51, 109, 143, 182) // %q must be %d-%d
TRANSLATION("%q must be 1 when %q is True", 28, 157, 51, 116, 63, 164, 236, 33, 153, 36, 169) // %q must be 1 when %q is True
TRANSLATION("%q must be <= %d", 16, 157, 51, 235, 111, 112, 0) // %q must be <= %d
TRANSLATION("%q must be >= %d", 16, 157, 51, 210, 222, 224, 0) // %q must be >= %d
TRANSLATION("%q must be >= 0", 15, 157, 51, 210, 222, 140, 128) // %q must be >= 0
TRANSLATION("%q must be >= 1", 15, 157, 51, 210, 222, 141, 208) // %q must be >= 1
TRANSLATION("%q must be a string", 19, 157, 48, 194, 228, 149, 128) // %q must be a string
TRANSLATION("%q must be an int", 17, 157, 51, 53, 230, 0) // %q must be an int
TRANSLATION("%q must be of type %q", 21, 157, 49, 110, 142, 240, 156) // %q must be of type %q
TRANSLATION("%q must be of type %q or None", 29, 157, 49, 110, 142, 240, 156, 45, 112, 226, 72) // %q must be of type %q or None
TRANSLATION("%q out of range", 15, 156, 53, 176, 254, 84, 128) // %q out of range
TRANSLATION("%q with a report ID of 0 must be of length 1", 44, 157, 181, 6, 22, 227, 178, 193, 151, 191, 195, 200, 152, 183, 70, 160, 221, 0) // %q with a report ID of 0 must be of length 1
TRANSLATION("%q, %q, and %q must all be the same length", 42, 157, 141, 59, 27, 155, 59, 103, 204, 13, 54, 202, 173, 145, 160, 111, 80) // %q, %q, and %q must all be the same length
TRANSLATION("'%q' argument required", 22, 159, 58, 120, 206, 242, 16) // \'%q\' argument required
TRANSLATION("'%q' object is not an iterator", 30, 159, 58, 120, 236, 97, 77, 205, 174, 229, 43, 32) // \'%q\' object is not an iterator
TRANSLATION("'%q' object is not callable", 27, 159, 58, 120, 236, 97, 77, 63, 51, 148) // \'%q\' object is not callable
TRANSLATION("'%q' object is not iterable", 27, 159, 58, 120, 236, 97, 77, 174, 231, 40) // \'%q\' object is not iterable
TRANSLATION("'%s' object doesn't support item assignment", 43, 250, 131, 177, 227, 252, 37, 224, 142, 203, 5, 116, 192, 12, 95, 52, 26, 32) // \'%s\' object doesn\'t support item assignment
TRANSLATION("'%s' object doesn't support item deletion", 41, 250, 131, 177, 227, 252, 37, 224, 142, 203, 5, 116, 192, 16, 155, 26, 224) // \'%s\' object doesn\'t support item deletion
TRANSLATION("'%s' object has no attribute '%q'", 33, 250, 131, 176, 52, 200, 66, 177, 75, 249, 183, 62, 116, 240) // \'%s\' object has no attribute \'%q\'
TRANSLATION("'%s' object isn't subscriptable", 31, 250, 131, 177, 133, 240, 148, 173, 17, 228, 84, 108, 229, 0) // \'%s\' object isn\'t subscriptable
TRANSLATION("'=' alignment not allowed in string format specifier", 52, 159, 189, 158, 12, 250, 170, 67, 6, 140, 222, 98, 239, 83, 120, 92, 146, 182, 15, 88, 124, 238, 0) // \'=\' alignment not allowed in string format specifier
TRANSLATION("'await' outside function", 24, 158, 107, 198, 175, 60, 107, 18, 144, 223, 79, 92) // \'await\' outside function
TRANSLATION("'await', 'async for' or 'async with' outside async function", 59, 158, 107, 198, 175, 63, 26, 121, 138, 252, 39, 193, 158, 45, 79, 49, 95, 132, 251, 89, 227, 88, 148, 134, 204, 87, 225, 56, 233, 235, 128) // \'await\', \'async for\' or \'async with\' outside async function
TRANSLATION("'break' outside loop", 20, 158, 213, 179, 117, 39, 141, 98, 82, 27, 125, 107, 140) // \'break\' outside loop
TRANSLATION("'continue' outside loop", 23, 158, 120, 152, 244, 169, 158, 53, 137, 72, 109, 245, 174, 48) // \'continue\' outside loop
TRANSLATION("'coroutine' object is not an iterator", 37, 158, 123, 58, 207, 38, 120, 236, 97, 77, 205, 174, 229, 43, 32) // \'coroutine\' object is not an iterator
TRANSLATION("'return' outside function", 25, 159, 109, 146, 201, 12, 241, 172, 74, 67, 125, 61, 112) // \'return\' outside function
TRANSLATION("'yield from' inside async function", 34, 159, 125, 73, 125, 1, 217, 23, 4, 240, 241, 41, 13, 152, 175, 194, 113, 211, 215) // \'yield from\' inside async function
TRANSLATION("'yield' outside function", 24, 159, 125, 73, 125, 19, 198, 177, 41, 13, 244, 245, 192) // \'yield\' outside function
TRANSLATION("*x must be assignment target", 28, 243, 118, 38, 24, 190, 104, 52, 67, 57, 233, 96) // *x must be assignment target
TRANSLATION(", in %q\n", 9, 198, 120, 78, 217, 0) // , in %q\r\n
TRANSLATION("0.0 to a complex power", 22, 200, 161, 145, 138, 96, 117, 234, 216, 216, 17, 174, 243, 128) // 0.0 to a complex power
TRANSLATION("64 bit types", 12, 250, 190, 128, 106, 184, 239, 16) // 64 bit types
TRANSLATION("Adapter not enabled", 19, 223, 32, 209, 177, 201, 186, 28, 164, 0) // Adapter not enabled
TRANSLATION("Address must be %d bytes long", 29, 223, 33, 22, 200, 166, 109, 135, 64, 131, 241, 84) // Address must be %d bytes long
TRANSLATION("All UART peripherals are in use", 31, 223, 62, 248, 228, 239, 184, 249, 130, 55, 21, 29, 87, 12, 249, 3, 91, 15, 109, 0) // All UART peripherals are in use
TRANSLATION("All channels in use", 19, 223, 62, 248, 252, 4, 30, 218, 0) // All channels in use
TRANSLATION("All state machines in use", 25, 223, 62, 248, 185, 73, 184, 12, 122, 175, 36, 131, 219, 64) // All state machines in use
TRANSLATION("All timers for this pin are in use", 34, 223, 62, 248, 238, 184, 88, 56, 138, 33, 27, 192, 214, 195, 219, 64) // All timers for this pin are in use
TRANSLATION("All timers in use", 17, 223, 62, 248, 238, 184, 65, 237, 160) // All timers in use
TRANSLATION("Already advertising", 19, 223, 63, 108, 200, 190, 12, 139, 174, 49, 69, 88) // Already advertising
TRANSLATION("Array must contain halfwords (type 'H')", 39, 223, 73, 33, 175, 236, 207, 19, 12, 240, 211, 125, 219, 214, 80, 67, 111, 222, 19, 254, 188, 253, 192) // Array must contain halfwords (type \'H\')
TRANSLATION("Array values should be single bytes.", 36, 223, 73, 33, 175, 143, 9, 125, 34, 173, 96, 116, 10, 128) // Array values should be single bytes.
TRANSLATION("At most %d %q may be specified (not %d)", 39, 223, 48, 64, 187, 152, 2, 112, 128, 215, 195, 77, 252, 244, 246, 255, 22, 219, 112) // At most %d %q may be specified (not %d)
TRANSLATION("Attempted heap allocation when VM not running.", 46, 223, 49, 137, 213, 101, 58, 169, 52, 99, 152, 179, 210, 84, 67, 250, 125, 190, 20, 217, 37, 134, 26, 212, 0) // Attempted heap allocation when VM not running.
TRANSLATION("Attribute not found", 19, 223, 127, 237, 191, 137, 222, 202, 0) // Attribute not found
TRANSLATION("Attribute not long", 18, 223, 127, 237, 191, 137, 248, 170, 0) // Attribute not long
TRANSLATION("Audio conversion not implemented", 32, 223, 74, 133, 44, 30, 43, 174, 18, 162, 155, 249, 128) // Audio conversion not implemented
TRANSLATION("Auto-reload is off.\n", 21, 223, 74, 197, 227, 219, 125, 102, 70, 16, 91, 174, 208, 217, 0) // Auto-reload is off.\r\n
TRANSLATION("Auto-reload is on. Simply save files over USB to run them or enter REPL to disable.\n", 85, 223, 74, 197, 227, 219, 125, 102, 70, 16, 138, 128, 228, 43, 87, 170, 70, 186, 223, 182, 65, 119, 92, 31, 107, 22, 73, 97, 196, 76, 2, 214, 139, 131, 143, 192, 227, 122, 184, 168, 81, 114, 168, 108, 128) // Auto-reload is on. Simply save files over USB to run them or enter REPL to disable.\r\n
TRANSLATION("Below minimum frame rate", 24, 201, 75, 235, 188, 32, 121, 80, 75, 0, 118, 67, 64, 220, 148, 146) // Below minimum frame rate
TRANSLATION("Bit clock and word select must be sequential pins", 49, 201, 174, 15, 250, 71, 54, 245, 148, 2, 77, 131, 178, 97, 123, 90, 42, 229, 198, 241, 0) // Bit clock and word select must be sequential pins
TRANSLATION("Bit depth must be multiple of 8.", 32, 201, 174, 16, 152, 217, 86, 103, 193, 135, 232, 208) // Bit depth must be multiple of 8.
TRANSLATION("Bitmap size and bits per value must match", 41, 201, 175, 1, 163, 242, 91, 230, 181, 92, 132, 110, 15, 14, 207, 223) // Bitmap size and bits per value must match
TRANSLATION("Boot device must be first device (interface #0).", 48, 201, 90, 217, 227, 55, 250, 155, 247, 60, 102, 246, 239, 49, 199, 76, 118, 255, 183, 35, 113, 64) // Boot device must be first device (interface #0).
TRANSLATION("Brightness must be 0-1.0", 24, 201, 147, 242, 194, 146, 41, 153, 24, 251, 170, 25, 0) // Brightness must be 0-1.0
TRANSLATION("Brightness not adjustable", 25, 201, 147, 242, 194, 146, 41, 166, 71, 232, 150, 231, 40) // Brightness not adjustable
TRANSLATION("Buffer + offset too small %d %d %d", 34, 201, 239, 143, 252, 5, 186, 239, 111, 202, 40, 57, 152, 24, 24, 0) // Buffer + offset too small %d %d %d
TRANSLATION("Buffer elements must be 4 bytes long or less", 44, 201, 239, 132, 216, 131, 68, 166, 122, 3, 160, 65, 248, 170, 11, 86, 8, 128) // Buffer elements must be 4 bytes long or less
TRANSLATION("Buffer is not a bytearray.", 26, 201, 239, 225, 77, 48, 232, 103, 208) // Buffer is not a bytearray.
TRANSLATION("Buffer is too small", 19, 201, 239, 225, 121, 69, 7, 48) // Buffer is too small
TRANSLATION("Buffer length must be a multiple of 512", 39, 201, 239, 141, 73, 134, 31, 6, 31, 247, 110, 183, 96) // Buffer length must be a multiple of 512
TRANSLATION("Buffer must be a multiple of 512 bytes", 38, 201, 239, 204, 48, 248, 48, 255, 187, 117, 187, 29, 2) // Buffer must be a multiple of 512 bytes
TRANSLATION("Buffer too large and unable to allocate", 39, 201, 239, 249, 79, 243, 219, 230, 203, 15, 43, 23, 152, 179, 210, 72) // Buffer too large and unable to allocate
TRANSLATION("Buffer too short by %d bytes", 28, 201, 239, 249, 69, 86, 203, 3, 87, 240, 7, 64, 128) // Buffer too short by %d bytes
TRANSLATION("Bus pin %d is already in use", 28, 201, 148, 132, 111, 96, 97, 15, 186, 30, 218, 0) // Bus pin %d is already in use
TRANSLATION("Byte buffer must be 16 bytes.", 29, 201, 190, 198, 218, 239, 204, 243, 135, 64, 168, 0) // Byte buffer must be 16 bytes.
TRANSLATION("CBC blocks must be multiples of 16 bytes", 40, 202, 201, 202, 13, 126, 146, 153, 240, 22, 31, 156, 58, 4) // CBC blocks must be multiples of 16 bytes
TRANSLATION("CIRCUITPY drive could not be found or created.", 46, 255, 32, 137, 21, 117, 179, 252, 147, 90, 109, 222, 202, 5, 163, 219, 164, 148, 80) // CIRCUITPY drive could not be found or created.
TRANSLATION("Call super().__init__() before accessing native object.", 55, 202, 230, 2, 240, 57, 230, 80, 163, 69, 234, 244, 104, 249, 129, 164, 187, 101, 179, 28, 233, 34, 172, 33, 164, 171, 173, 246, 40, 0) // Call super().__init__() before accessing native object.
TRANSLATION("Can't set CCCD on local Characteristic", 38, 202, 55, 195, 219, 25, 89, 89, 91, 241, 16, 125, 103, 229, 229, 126, 71, 21, 113, 71) // Can\'t set CCCD on local Characteristic
TRANSLATION("Cannot change USB devices now", 29, 202, 231, 31, 78, 26, 141, 253, 175, 25, 36, 33, 93, 224) // Cannot change USB devices now
TRANSLATION("Cannot delete values", 20, 202, 231, 33, 54, 24, 223, 132, 128) // Cannot delete values
TRANSLATION("Cannot get pull while in output mode", 36, 202, 231, 84, 75, 4, 114, 190, 248, 189, 85, 86, 3, 195, 91, 180, 58, 233) // Cannot get pull while in output mode
TRANSLATION("Cannot have scan responses for extended, connectable advertisements.", 68, 202, 231, 105, 221, 108, 143, 155, 108, 163, 136, 146, 88, 35, 73, 154, 8, 74, 49, 143, 20, 61, 46, 80, 50, 46, 184, 197, 18, 96, 209, 42, 0) // Cannot have scan responses for extended, connectable advertisements.
TRANSLATION("Cannot record to a file", 23, 202, 231, 91, 61, 148, 98, 152, 123, 96) // Cannot record to a file
TRANSLATION("Cannot remount '/' when visible via USB.", 40, 202, 231, 91, 131, 178, 193, 63, 115, 60, 127, 75, 170, 37, 53, 96, 93, 81, 135, 218, 160) // Cannot remount \'/\' when visible via USB.
TRANSLATION("Cannot set value when direction is input.", 41, 202, 231, 118, 199, 132, 127, 68, 42, 217, 245, 240, 131, 221, 170, 0) // Cannot set value when direction is input.
TRANSLATION("Cannot subclass slice", 21, 202, 231, 127, 32, 94, 242, 64) // Cannot subclass slice
TRANSLATION("Cannot transfer without MOSI and MISO pins", 42, 202, 231, 50, 67, 66, 78, 185, 181, 214, 28, 46, 47, 35, 44, 115, 120, 89, 124, 142, 40, 141, 226) // Cannot transfer without MOSI and MISO pins
TRANSLATION("Cannot vary frequency on a timer that is already in use", 55, 202, 231, 93, 52, 151, 195, 182, 255, 124, 186, 7, 190, 34, 6, 29, 215, 49, 41, 97, 15, 186, 30, 218, 0) // Cannot vary frequency on a timer that is already in use
TRANSLATION("Characteristic can only be added to most recently added service", 63, 202, 252, 142, 42, 226, 142, 15, 155, 23, 85, 166, 204, 132, 83, 98, 196, 11, 184, 45, 159, 71, 170, 100, 34, 153, 57, 117, 71, 72) // Characteristic can only be added to most recently added service
TRANSLATION("Characteristic not writable", 27, 202, 252, 142, 42, 226, 143, 54, 244, 149, 249, 64) // Characteristic not writable
TRANSLATION("CharacteristicBuffer writing not provided", 41, 202, 252, 142, 42, 226, 143, 147, 223, 23, 164, 175, 90, 111, 238, 74, 0) // CharacteristicBuffer writing not provided
TRANSLATION("CircuitPython core code crashed hard. Whoops!\n", 47, 255, 56, 129, 236, 182, 117, 161, 179, 200, 98, 171, 79, 78, 68, 80, 30, 181, 85, 174, 50, 254, 205, 144) // CircuitPython core code crashed hard. Whoops!\r\n
TRANSLATION("CircuitPython was unable to allocate the heap.", 46, 255, 56, 133, 227, 16, 150, 30, 86, 47, 49, 103, 164, 219, 42, 183, 85, 38, 142, 128) // CircuitPython was unable to allocate the heap.
TRANSLATION("Clock stretch too long", 22, 202, 253, 34, 229, 182, 30, 175, 148, 252, 85, 0) // Clock stretch too long
TRANSLATION("Connection has been disconnected and can no longer be used. Create a new connection.", 84, 202, 138, 30, 146, 162, 26, 100, 26, 78, 128, 66, 136, 241, 67, 210, 167, 205, 62, 108, 43, 15, 197, 81, 192, 211, 114, 146, 81, 64, 101, 91, 164, 217, 132, 41, 188, 15, 20, 61, 37, 69, 64) // Connection has been disconnected and can no longer be used. Create a new connection.
TRANSLATION("Corrupt .mpy file", 17, 202, 179, 39, 129, 130, 134, 173, 241, 237, 128) // Corrupt .mpy file
TRANSLATION("Could not get max advertising length", 36, 202, 249, 38, 212, 75, 4, 6, 216, 6, 69, 215, 24, 162, 172, 53, 0) // Could not get max advertising length
TRANSLATION("Could not read BLE buffer info", 30, 202, 249, 38, 219, 50, 6, 79, 171, 192, 13, 119, 195, 206, 172) // Could not read BLE buffer info
TRANSLATION("Could not read BLE features", 27, 202, 249, 38, 219, 50, 6, 79, 171, 192, 14, 166, 148, 182, 200) // Could not read BLE features
TRANSLATION("Could not read HCI version", 26, 202, 249, 38, 219, 50, 7, 216, 186, 225, 42, 32) // Could not read HCI version
TRANSLATION("Could not set address", 21, 202, 249, 38, 246, 193, 144, 139, 100, 64) // Could not set address
TRANSLATION("Could not set event mask", 24, 202, 249, 38, 246, 194, 110, 232, 136, 12, 93, 64) // Could not set event mask
TRANSLATION("Could not start PWM", 19, 202, 249, 38, 220, 52, 140, 31, 100) // Could not start PWM
TRANSLATION("Couldn't allocate decoder", 25, 202, 249, 62, 30, 98, 207, 73, 180, 36, 235, 67, 128) // Couldn\'t allocate decoder
TRANSLATION("Crash into the HardFault_Handler.", 33, 202, 144, 197, 84, 60, 197, 226, 55, 245, 205, 34, 56, 38, 149, 246, 81, 250, 230, 133, 22, 36, 160) // Crash into the HardFault_Handler.
TRANSLATION("DB out of sync", 14, 223, 228, 141, 108, 50, 191, 9, 192) // DB out of sync
TRANSLATION("Data chunk must follow fmt chunk", 32, 223, 210, 48, 61, 89, 97, 234, 108, 221, 91, 239, 174, 240, 118, 6, 3, 213, 150, 30, 160) // Data chunk must follow fmt chunk
TRANSLATION("Data length needs extended advertising, but this adapter does not support it", 76, 223, 210, 48, 212, 16, 165, 40, 33, 164, 205, 4, 83, 50, 46, 184, 197, 21, 108, 102, 165, 102, 34, 136, 25, 6, 141, 142, 120, 243, 75, 193, 29, 150, 10, 224) // Data length needs extended advertising, but this adapter does not support it
TRANSLATION("Data too large for advertisement packet", 39, 223, 210, 55, 148, 255, 61, 183, 109, 25, 23, 92, 98, 137, 48, 104, 136, 253, 116, 176) // Data too large for advertisement packet
TRANSLATION("Descriptor can only be added to most recently added characteristic", 66, 223, 164, 143, 34, 163, 101, 163, 230, 197, 213, 105, 179, 33, 20, 216, 177, 2, 238, 11, 103, 209, 234, 153, 8, 166, 127, 200, 226, 174, 40, 224) // Descriptor can only be added to most recently added characteristic
TRANSLATION("Destination capacity is smaller than destination_length.", 56, 223, 166, 227, 212, 149, 16, 57, 163, 49, 235, 223, 194, 5, 7, 49, 204, 76, 212, 38, 227, 212, 149, 21, 29, 74, 0) // Destination capacity is smaller than destination_length.
TRANSLATION("Display must have a 16 bit colorspace.", 38, 223, 254, 125, 158, 157, 214, 204, 60, 224, 213, 113, 236, 217, 40, 204, 116, 208) // Display must have a 16 bit colorspace.
TRANSLATION("Display rotation must be in 90 degree increments", 48, 223, 254, 113, 34, 217, 73, 81, 76, 120, 127, 134, 64, 66, 106, 91, 109, 227, 219, 131, 68, 128) // Display rotation must be in 90 degree increments
TRANSLATION("Drive mode not used when direction is input.", 44, 223, 200, 171, 173, 245, 219, 248, 165, 42, 127, 209, 10, 182, 125, 124, 32, 247, 106, 128) // Drive mode not used when direction is input.
TRANSLATION("ECB only operates on 16 bytes at a time", 39, 224, 101, 100, 136, 186, 171, 141, 202, 73, 33, 16, 243, 135, 64, 133, 32, 97, 221, 72) // ECB only operates on 16 bytes at a time
TRANSLATION("Encryption key size", 19, 224, 66, 121, 47, 199, 174, 58, 137, 191, 228, 164) // Encryption key size
TRANSLATION("Error in ATT protocol code", 26, 224, 73, 37, 167, 134, 251, 51, 48, 71, 34, 216, 191, 100, 29, 104, 72) // Error in ATT protocol code
TRANSLATION("Error in MIDI stream at position %d", 35, 224, 73, 37, 167, 135, 11, 47, 127, 150, 46, 91, 52, 2, 144, 141, 101, 93, 81, 96, 0) // Error in MIDI stream at position %d
TRANSLATION("Error in regex", 14, 224, 73, 37, 167, 133, 186, 154, 64) // Error in regex
TRANSLATION("Error reading from HCI adapter", 30, 224, 73, 37, 171, 102, 69, 97, 248, 190, 193, 144, 104, 216, 224) // Error reading from HCI adapter
TRANSLATION("Error writing to HCI adapter", 28, 224, 73, 37, 171, 210, 87, 173, 139, 246, 12, 131, 70, 199, 0) // Error writing to HCI adapter
TRANSLATION("Expected a %q", 13, 224, 127, 242, 153, 132, 224) // Expected a %q
TRANSLATION("Expected an alarm", 17, 224, 127, 242, 158, 111, 220) // Expected an alarm
TRANSLATION("Extended advertisements with scan response not supported.", 57, 224, 108, 51, 65, 20, 204, 139, 174, 49, 68, 152, 52, 75, 106, 8, 249, 182, 202, 56, 137, 191, 139, 185, 64) // Extended advertisements with scan response not supported.
TRANSLATION("FFT is defined for ndarrays only", 32, 224, 240, 115, 48, 130, 18, 235, 212, 221, 181, 10, 51, 200, 68, 253, 240) // FFT is defined for ndarrays only
TRANSLATION("FFT is implemented for linear arrays only", 41, 224, 240, 115, 48, 135, 230, 193, 15, 188, 147, 72, 51, 200, 68, 253, 240) // FFT is implemented for linear arrays only
TRANSLATION("Failed to add service", 21, 224, 153, 86, 17, 138, 100, 32, 19, 151, 84, 116, 128) // Failed to add service
TRANSLATION("Failed to allocate %q buffer", 28, 224, 153, 86, 17, 139, 204, 89, 233, 55, 56, 53, 223) // Failed to allocate %q buffer
TRANSLATION("Failed to connect: internal error", 33, 224, 153, 86, 17, 138, 120, 161, 233, 111, 3, 204, 114, 30, 91, 146, 89) // Failed to connect: internal error
TRANSLATION("Failed to parse MP3 file", 24, 224, 153, 86, 17, 139, 25, 164, 38, 248, 92, 111, 60, 123, 96) // Failed to parse MP3 file
TRANSLATION("Failed to write internal flash.", 31, 224, 153, 86, 17, 139, 122, 74, 237, 188, 199, 33, 229, 186, 249, 138, 173, 0) // Failed to write internal flash.
TRANSLATION("Fatal error.", 12, 224, 210, 229, 185, 37, 154, 0) // Fatal error.
TRANSLATION("File exists", 11, 224, 170, 192, 210, 85, 194) // File exists
TRANSLATION("For L8 colorspace, input bitmap must have 8 bits per pixel", 58, 224, 218, 245, 125, 17, 236, 217, 40, 204, 116, 227, 61, 218, 30, 198, 207, 78, 235, 126, 136, 106, 185, 8, 220, 31, 180) // For L8 colorspace, input bitmap must have 8 bits per pixel
TRANSLATION("For RGB colorspaces, input bitmap must have 16 bits per pixel", 61, 224, 218, 227, 250, 121, 35, 217, 178, 81, 152, 233, 44, 103, 187, 67, 216, 217, 233, 221, 111, 206, 13, 87, 33, 27, 131, 246, 128) // For RGB colorspaces, input bitmap must have 16 bits per pixel
TRANSLATION("Frequency must match existing PWMOut using this timer", 53, 224, 219, 253, 242, 232, 30, 254, 207, 223, 26, 74, 185, 88, 125, 158, 44, 172, 18, 149, 108, 69, 16, 238, 184) // Frequency must match existing PWMOut using this timer
TRANSLATION("Function requires lock", 22, 224, 203, 9, 245, 252, 130, 31, 164) // Function requires lock
TRANSLATION("Group already used", 18, 244, 228, 95, 128, 125, 221, 162, 0) // Group already used
TRANSLATION("HCI packet size mismatch", 24, 251, 17, 250, 233, 103, 146, 220, 10, 47, 124) // HCI packet size mismatch
TRANSLATION("HCI status error: %02x", 22, 251, 23, 41, 74, 65, 201, 44, 239, 7, 151, 145, 187, 216) // HCI status error: %02x
TRANSLATION("Half duplex SPI is not implemented", 34, 250, 230, 125, 208, 143, 5, 141, 129, 200, 227, 101, 225, 77, 252, 192) // Half duplex SPI is not implemented
TRANSLATION("I/O operation on closed file", 28, 203, 220, 241, 66, 227, 114, 146, 162, 17, 3, 190, 178, 167, 237, 128) // I/O operation on closed file
TRANSLATION("I2C peripheral in use", 21, 203, 221, 229, 8, 220, 84, 117, 92, 229, 189, 180) // I2C peripheral in use
TRANSLATION("IV must be %d bytes long", 24, 203, 251, 115, 54, 195, 160, 65, 248, 170, 0) // IV must be %d bytes long
TRANSLATION("In-buffer elements must be <= 4 bytes long", 42, 203, 135, 29, 174, 248, 77, 136, 52, 74, 103, 214, 222, 143, 64, 116, 8, 63, 21, 64) // In-buffer elements must be <= 4 bytes long
TRANSLATION("Incompatible .mpy file. Please update all .mpy files. See http://adafru.it/mpy-update for more info.", 100, 203, 132, 235, 213, 164, 166, 172, 10, 26, 183, 199, 183, 64, 113, 172, 24, 155, 240, 34, 147, 124, 193, 67, 86, 248, 246, 202, 128, 228, 37, 186, 172, 100, 123, 205, 206, 228, 200, 51, 178, 75, 66, 190, 231, 86, 254, 63, 129, 20, 155, 118, 212, 22, 91, 121, 213, 208) // Incompatible .mpy file. Please update all .mpy files. See http://adafru.it/mpy-update for more info.
TRANSLATION("Init program size invalid", 25, 203, 134, 184, 143, 248, 121, 45, 189, 244, 0) // Init program size invalid
TRANSLATION("Initial set pin direction conflicts with initial out pin direction", 66, 203, 134, 186, 185, 125, 177, 27, 193, 10, 182, 125, 112, 120, 157, 247, 152, 91, 80, 245, 117, 114, 245, 132, 111, 4, 42, 217, 245, 192) // Initial set pin direction conflicts with initial out pin direction
TRANSLATION("Initial set pin state conflicts with initial out pin state", 58, 203, 134, 186, 185, 125, 177, 27, 194, 229, 38, 207, 19, 190, 243, 11, 106, 30, 174, 174, 94, 176, 141, 225, 114, 146, 64) // Initial set pin state conflicts with initial out pin state
TRANSLATION("Input buffer length (%d) must be a multiple of the strand count (%d)", 68, 203, 135, 180, 26, 239, 141, 65, 183, 219, 110, 38, 24, 124, 24, 108, 170, 221, 201, 57, 167, 236, 176, 109, 246, 219, 128) // Input buffer length (%d) must be a multiple of the strand count (%d)
TRANSLATION("Input/output error", 18, 203, 135, 181, 185, 214, 237, 7, 36, 178) // Input/output error
TRANSLATION("Instruction %d shifts in more bits than pin count", 49, 245, 53, 240, 1, 85, 83, 172, 32, 240, 130, 203, 109, 87, 44, 76, 216, 222, 7, 236, 176) // Instruction %d shifts in more bits than pin count
TRANSLATION("Instruction %d shifts out more bits than pin count", 50, 245, 53, 240, 1, 85, 83, 172, 33, 172, 32, 178, 219, 85, 203, 19, 54, 55, 129, 251, 44) // Instruction %d shifts out more bits than pin count
TRANSLATION("Instruction %d uses extra pin", 29, 245, 53, 240, 54, 132, 52, 153, 33, 132, 111, 0) // Instruction %d uses extra pin
TRANSLATION("Instruction %d waits on input outside of count", 46, 245, 53, 240, 5, 227, 87, 33, 16, 123, 180, 53, 137, 72, 109, 110, 131, 246, 88) // Instruction %d waits on input outside of count
TRANSLATION("Insufficient authentication", 27, 203, 132, 165, 117, 213, 29, 90, 32, 210, 178, 174, 138, 143, 73, 81, 0) // Insufficient authentication
TRANSLATION("Insufficient encryption", 23, 203, 132, 165, 117, 213, 29, 90, 35, 64, 242, 95, 143, 92) // Insufficient encryption
TRANSLATION("Insufficient resources", 22, 203, 132, 165, 117, 213, 29, 90, 34, 223, 241, 73, 0) // Insufficient resources
TRANSLATION("Internal audio buffer too small", 31, 203, 133, 142, 67, 203, 52, 168, 82, 195, 93, 255, 40, 160, 230, 0) // Internal audio buffer too small
TRANSLATION("Internal error #%d", 18, 203, 133, 142, 67, 203, 114, 75, 95, 219, 182) // Internal error #%d
TRANSLATION("Invalid %q", 10, 203, 248, 196, 224) // Invalid %q
TRANSLATION("Invalid %q pin", 14, 203, 248, 196, 225, 27, 192) // Invalid %q pin
TRANSLATION("Invalid BLE attribute", 21, 203, 248, 198, 79, 171, 192, 20, 191, 154, 64) // Invalid BLE attribute
TRANSLATION("Invalid PDU", 11, 203, 248, 199, 27, 127, 201) // Invalid PDU
TRANSLATION("Invalid argument", 16, 203, 248, 198, 112) // Invalid argument
TRANSLATION("Invalid attribute length", 24, 203, 248, 197, 47, 230, 222, 160) // Invalid attribute length
TRANSLATION("Invalid bits per value", 22, 203, 248, 195, 85, 200, 70, 224, 240, 128) // Invalid bits per value
TRANSLATION("Invalid format chunk size", 25, 203, 248, 240, 122, 192, 245, 101, 135, 169, 228, 164) // Invalid format chunk size
TRANSLATION("Invalid handle", 14, 203, 248, 198, 156, 40, 176) // Invalid handle
TRANSLATION("Invalid memory access.", 22, 203, 248, 196, 9, 130, 205, 240, 99, 157, 36, 84, 0) // Invalid memory access.
TRANSLATION("Invalid offset", 14, 203, 248, 194, 221, 119, 182) // Invalid offset
TRANSLATION("Key must be 16, 24, or 32 bytes long", 36, 255, 241, 55, 230, 121, 216, 219, 191, 67, 26, 215, 159, 187, 29, 2, 15, 197, 80) // Key must be 16, 24, or 32 bytes long
TRANSLATION("LHS of keyword arg must be an id", 32, 245, 126, 191, 35, 15, 221, 28, 249, 153, 170, 64) // LHS of keyword arg must be an id
TRANSLATION("Layer already in a group", 24, 245, 77, 125, 193, 247, 67, 192, 194, 164, 139, 240, 0) // Layer already in a group
TRANSLATION("Layer must be a Group or TileGrid subclass", 42, 245, 77, 125, 201, 134, 30, 156, 139, 240, 11, 89, 138, 177, 233, 200, 164, 15, 228) // Layer must be a Group or TileGrid subclass
TRANSLATION("Maximum x value when mirrored is %d", 35, 225, 125, 253, 129, 225, 31, 210, 5, 73, 37, 154, 106, 44, 0) // Maximum x value when mirrored is %d
TRANSLATION("Microphone startup delay must be in range 0.0 to 1.0", 52, 225, 40, 242, 46, 58, 177, 55, 112, 210, 51, 192, 16, 151, 205, 126, 99, 195, 229, 111, 34, 134, 70, 46, 234, 134, 64) // Microphone startup delay must be in range 0.0 to 1.0
TRANSLATION("Mismatched data size", 20, 225, 40, 189, 250, 104, 164, 111, 37, 32) // Mismatched data size
TRANSLATION("Mismatched swap flag", 20, 225, 40, 189, 250, 101, 120, 209, 135, 95, 53, 64) // Mismatched swap flag
TRANSLATION("Missing first_in_pin. Instruction %d reads pin(s)", 49, 225, 40, 138, 176, 247, 40, 189, 70, 55, 168, 15, 83, 95, 0, 91, 50, 8, 70, 246, 220, 183, 0) // Missing first_in_pin. Instruction %d reads pin(s)
TRANSLATION("Missing first_in_pin. Instruction %d shifts in from pin(s)", 58, 225, 40, 138, 176, 247, 40, 189, 70, 55, 168, 15, 83, 95, 0, 21, 85, 58, 194, 15, 15, 197, 27, 219, 114, 220, 0) // Missing first_in_pin. Instruction %d shifts in from pin(s)
TRANSLATION("Missing first_in_pin. Instruction %d waits based on pin", 55, 225, 40, 138, 176, 247, 40, 189, 70, 55, 168, 15, 83, 95, 0, 94, 53, 114, 13, 24, 169, 196, 35, 120) // Missing first_in_pin. Instruction %d waits based on pin
TRANSLATION("Missing first_out_pin. Instruction %d shifts out to pin(s)", 58, 225, 40, 138, 176, 247, 40, 235, 81, 141, 234, 3, 212, 215, 192, 5, 85, 78, 176, 134, 182, 44, 111, 109, 203, 112) // Missing first_out_pin. Instruction %d shifts out to pin(s)
TRANSLATION("Missing first_out_pin. Instruction %d writes pin(s)", 51, 225, 40, 138, 176, 247, 40, 235, 81, 141, 234, 3, 212, 215, 192, 23, 164, 174, 146, 17, 189, 183, 45, 192) // Missing first_out_pin. Instruction %d writes pin(s)
TRANSLATION("Missing first_set_pin. Instruction %d sets pin(s)", 49, 225, 40, 138, 176, 247, 40, 246, 232, 198, 245, 1, 234, 107, 224, 14, 217, 8, 222, 219, 150, 224) // Missing first_set_pin. Instruction %d sets pin(s)
TRANSLATION("Missing jmp_pin. Instruction %d jumps on pin", 44, 225, 40, 138, 176, 253, 26, 180, 99, 122, 128, 245, 53, 240, 7, 232, 151, 84, 132, 66, 55, 128) // Missing jmp_pin. Instruction %d jumps on pin
TRANSLATION("Must be a %q subclass.", 22, 225, 75, 112, 52, 217, 132, 225, 252, 168, 0) // Must be a %q subclass.
TRANSLATION("Must provide MISO or MOSI pin", 29, 225, 75, 112, 126, 230, 248, 89, 124, 142, 40, 181, 194, 226, 242, 50, 196, 111, 0) // Must provide MISO or MOSI pin
TRANSLATION("Must use a multiple of 6 rgb pins, not %d", 41, 225, 75, 115, 104, 12, 62, 12, 63, 170, 36, 168, 208, 141, 226, 198, 248, 182, 192) // Must use a multiple of 6 rgb pins, not %d
TRANSLATION("NLR jump failed. Likely memory corruption.", 42, 225, 250, 188, 113, 250, 37, 213, 14, 153, 86, 17, 64, 122, 170, 234, 39, 171, 2, 96, 179, 124, 30, 204, 158, 13, 122, 0) // NLR jump failed. Likely memory corruption.
TRANSLATION("Name too long", 13, 225, 154, 6, 216, 181, 135, 226, 168) // Name too long
TRANSLATION("New bitmap must be same size as old bitmap", 42, 225, 166, 240, 246, 38, 17, 160, 108, 149, 226, 108, 196, 22, 250, 7, 176) // New bitmap must be same size as old bitmap
TRANSLATION("No CCCD for this Characteristic", 31, 226, 101, 101, 101, 111, 240, 113, 20, 67, 43, 242, 56, 171, 138, 56) // No CCCD for this Characteristic
TRANSLATION("No DMA channel found", 20, 226, 111, 248, 91, 225, 248, 3, 189, 148, 0) // No DMA channel found
TRANSLATION("No DMA pacing timer found", 25, 226, 111, 248, 91, 225, 25, 143, 88, 119, 92, 14, 246, 80) // No DMA pacing timer found
TRANSLATION("No I2C device at address: 0x%x", 30, 226, 101, 238, 242, 188, 102, 233, 3, 33, 22, 200, 183, 131, 35, 99, 203, 216) // No I2C device at address: 0x%x
TRANSLATION("No MISO pin", 11, 226, 112, 178, 249, 28, 81, 27, 192) // No MISO pin
TRANSLATION("No MOSI pin", 11, 226, 112, 184, 188, 140, 177, 27, 192) // No MOSI pin
TRANSLATION("No RX pin", 9, 226, 113, 255, 244, 35, 120) // No RX pin
TRANSLATION("No TX pin", 9, 226, 102, 127, 232, 70, 240) // No TX pin
TRANSLATION("No connection: length cannot be determined", 42, 226, 30, 40, 122, 74, 139, 120, 53, 1, 249, 205, 54, 132, 177, 200, 30, 74, 0) // No connection: length cannot be determined
TRANSLATION("No default %q bus", 17, 226, 126, 17, 56, 53, 41, 0) // No default %q bus
TRANSLATION("No hardware random available", 28, 226, 105, 200, 139, 198, 182, 36, 52, 40, 92, 3, 239, 114, 128) // No hardware random available
TRANSLATION("No in in program", 16, 226, 60, 30, 17, 255, 0) // No in in program
TRANSLATION("No in or out in program", 23, 226, 60, 45, 107, 7, 132, 127, 192) // No in or out in program
TRANSLATION("No key was specified", 20, 226, 117, 19, 124, 94, 49, 15, 157, 40) // No key was specified
TRANSLATION("No more than %d HID devices allowed", 35, 226, 65, 101, 182, 105, 195, 128, 62, 190, 94, 255, 198, 73, 14, 98, 239, 37, 0) // No more than %d HID devices allowed
TRANSLATION("No out in program", 17, 226, 107, 7, 132, 127, 192) // No out in program
TRANSLATION("No pull up found on SDA or SCL; check your wiring", 49, 226, 71, 43, 239, 143, 0, 119, 178, 129, 16, 228, 111, 247, 194, 215, 35, 43, 213, 255, 16, 122, 169, 63, 80, 95, 92, 178, 11, 202, 146, 176) // No pull up found on SDA or SCL; check your wiring
TRANSLATION("No pulldown on pin; 1Mohm recommended", 37, 226, 71, 43, 239, 161, 119, 161, 17, 8, 222, 255, 17, 186, 225, 46, 172, 2, 217, 215, 4, 26, 8, 74, 0) // No pulldown on pin; 1Mohm recommended
TRANSLATION("No space left on device", 23, 226, 20, 102, 59, 118, 29, 96, 139, 198, 72) // No space left on device
TRANSLATION("No such device", 14, 226, 20, 167, 171, 227, 36) // No such device
TRANSLATION("No such file/directory", 22, 226, 20, 167, 170, 61, 189, 202, 21, 108, 236, 179, 124) // No such file/directory
TRANSLATION("No timer available", 18, 226, 119, 92, 31, 123, 148) // No timer available
TRANSLATION("Not connected", 13, 225, 173, 128, 241, 67, 210, 74, 0) // Not connected
TRANSLATION("Not playing", 11, 225, 173, 130, 55, 205, 126, 176) // Not playing
TRANSLATION("Not supported", 13, 225, 173, 131, 184) // Not supported
TRANSLATION("Object has been deinitialized and can no longer be used. Create a new object.", 77, 226, 181, 250, 58, 67, 76, 131, 73, 208, 8, 75, 213, 212, 103, 213, 226, 167, 205, 62, 108, 43, 15, 197, 81, 192, 211, 114, 146, 81, 64, 101, 91, 164, 217, 132, 41, 188, 59, 20, 0) // Object has been deinitialized and can no longer be used. Create a new object.
TRANSLATION("Only 8 or 16 bit mono with " "64" "x oversampling is supported.", 63, 226, 195, 213, 244, 69, 175, 56, 53, 92, 65, 18, 246, 163, 233, 143, 167, 245, 125, 15, 166, 62, 158, 192, 93, 215, 8, 218, 175, 214, 194, 29, 202, 0) // Only 8 or 16 bit mono with \" \"64\" \"x oversampling is supported.
TRANSLATION("Only Windows format, uncompressed BMP supported: given header size is %d", 72, 226, 195, 213, 245, 158, 66, 239, 22, 15, 91, 26, 88, 78, 189, 91, 100, 84, 242, 120, 92, 97, 220, 222, 15, 198, 42, 164, 200, 115, 201, 109, 69, 128) // Only Windows format, uncompressed BMP supported: given header size is %d
TRANSLATION("Only connectable advertisements can be directed", 47, 226, 195, 213, 60, 80, 244, 185, 64, 200, 186, 227, 20, 73, 131, 68, 129, 243, 90, 109, 10, 182, 118, 37, 0) // Only connectable advertisements can be directed
TRANSLATION("Only monochrome, indexed 4bpp or 8bpp, and 16bpp or greater BMPs supported: %d bpp given", 88, 226, 195, 213, 130, 37, 158, 172, 139, 129, 56, 207, 35, 74, 159, 160, 212, 113, 139, 94, 139, 81, 199, 141, 205, 243, 154, 142, 49, 106, 165, 186, 78, 12, 158, 23, 24, 135, 115, 121, 128, 26, 142, 49, 248, 192) // Only monochrome, indexed 4bpp or 8bpp, and 16bpp or greater BMPs supported: %d bpp given
TRANSLATION("Only one alarm.time alarm can be set.", 37, 226, 195, 213, 137, 191, 185, 67, 186, 223, 220, 7, 205, 105, 190, 221, 0) // Only one alarm.time alarm can be set.
TRANSLATION("Only one color can be transparent at a time", 43, 226, 195, 213, 137, 191, 102, 209, 243, 90, 109, 146, 26, 18, 140, 214, 225, 96, 164, 12, 59, 169) // Only one color can be transparent at a time
TRANSLATION("Only tx_power=0 supported", 25, 226, 195, 213, 102, 197, 24, 215, 121, 205, 238, 64, 238, 0) // Only tx_power=0 supported
TRANSLATION("Operation not permitted", 23, 226, 198, 229, 37, 69, 54, 55, 32, 174, 196, 160) // Operation not permitted
TRANSLATION("Out-buffer elements must be <= 4 bytes long", 43, 226, 202, 204, 118, 187, 225, 54, 32, 209, 41, 159, 91, 122, 61, 1, 208, 32, 252, 85, 0) // Out-buffer elements must be <= 4 bytes long
TRANSLATION("Oversample must be multiple of 8.", 33, 226, 221, 112, 141, 171, 98, 103, 193, 135, 232, 208) // Oversample must be multiple of 8.
TRANSLATION("PWM slice already in use", 24, 251, 32, 189, 230, 254, 232, 123, 104) // PWM slice already in use
TRANSLATION("PWM slice channel A already in use", 34, 251, 32, 189, 230, 255, 0, 223, 15, 186, 30, 218, 0) // PWM slice channel A already in use
TRANSLATION("Permission denied", 17, 227, 57, 2, 136, 149, 16, 70, 130, 146, 128) // Permission denied
TRANSLATION("Pin count too large", 19, 227, 60, 15, 217, 103, 148, 255, 61, 32) // Pin count too large
TRANSLATION("Pin is input only", 17, 227, 61, 132, 30, 237, 8, 159, 190) // Pin is input only
TRANSLATION("Pin must be on PWM Channel B", 28, 227, 61, 50, 33, 246, 70, 86, 156, 48, 165, 241, 146) // Pin must be on PWM Channel B
TRANSLATION("Pinout uses %d bytes per element, which consumes more than the ideal %d bytes.  If this cannot be avoided, pass allow_inefficient=True to the constructor", 153, 227, 61, 173, 180, 44, 1, 208, 33, 27, 129, 54, 32, 209, 198, 189, 85, 71, 170, 15, 17, 75, 2, 72, 65, 101, 182, 105, 195, 136, 218, 144, 158, 94, 216, 116, 10, 128, 25, 110, 226, 40, 129, 249, 205, 54, 107, 171, 82, 18, 140, 104, 204, 68, 57, 139, 189, 69, 228, 186, 234, 142, 173, 29, 238, 100, 146, 182, 197, 226, 54, 120, 174, 73, 41, 217, 100) // Pinout uses %d bytes per element, which consumes more than the ideal %d bytes.  If this cannot be avoided, pass allow_inefficient=True to the constructor
TRANSLATION("Pins must be sequential", 23, 227, 60, 83, 11, 218, 209, 81, 159) // Pins must be sequential
TRANSLATION("Pins must be sequential GPIO pins", 33, 227, 60, 83, 11, 218, 209, 87, 47, 211, 227, 101, 241, 68, 111, 16) // Pins must be sequential GPIO pins
TRANSLATION("Pins must share PWM slice", 25, 227, 60, 91, 50, 211, 182, 62, 200, 47, 121, 32) // Pins must share PWM slice
TRANSLATION("Plus any modules on the filesystem\n", 36, 227, 63, 41, 3, 67, 124, 117, 229, 176, 66, 44, 70, 253, 178, 191, 113, 48, 108, 128) // Plus any modules on the filesystem\r\n
TRANSLATION("Polygon needs at least 3 points", 31, 227, 45, 251, 245, 34, 16, 165, 40, 33, 72, 88, 53, 193, 231, 136, 214, 243, 8) // Polygon needs at least 3 points
TRANSLATION("Prefix buffer must be on the heap", 33, 227, 91, 117, 91, 1, 174, 252, 200, 177, 27, 170, 147, 70) // Prefix buffer must be on the heap
TRANSLATION("Prepare queue full", 18, 227, 91, 140, 214, 199, 239, 149, 50, 182, 236, 175, 190) // Prepare queue full
TRANSLATION("Press any key to enter the REPL. Use CTRL-D to reload.\n", 56, 227, 91, 34, 6, 134, 248, 234, 38, 254, 46, 139, 152, 141, 241, 248, 28, 111, 86, 128, 228, 147, 121, 89, 156, 127, 87, 31, 127, 139, 109, 245, 153, 20, 54, 64) // Press any key to enter the REPL. Use CTRL-D to reload.\r\n
TRANSLATION("Pretending to deep sleep until alarm, CTRL-C or file write.\n", 61, 227, 91, 102, 130, 43, 98, 161, 41, 140, 21, 132, 198, 37, 133, 138, 124, 125, 204, 108, 172, 206, 63, 171, 143, 148, 45, 123, 98, 244, 149, 211, 67, 100) // Pretending to deep sleep until alarm, CTRL-C or file write.\r\n
TRANSLATION("Program does IN without loading ISR", 35, 227, 127, 15, 28, 101, 240, 246, 186, 193, 245, 153, 21, 134, 95, 35, 142) // Program does IN without loading ISR
TRANSLATION("Program does OUT without loading OSR", 36, 227, 127, 15, 28, 113, 121, 57, 155, 93, 96, 250, 204, 138, 195, 139, 200, 227, 128) // Program does OUT without loading OSR
TRANSLATION("Program size invalid", 20, 227, 127, 15, 37, 183, 190, 128) // Program size invalid
TRANSLATION("Pull not used when direction is output.", 39, 227, 74, 251, 243, 101, 42, 127, 209, 10, 182, 125, 124, 33, 173, 218, 160) // Pull not used when direction is output.
TRANSLATION("RAISE mode is not implemented", 29, 227, 239, 178, 249, 28, 1, 215, 109, 69, 55, 243, 0) // RAISE mode is not implemented
TRANSLATION("RISE_AND_FALL not available on this chip", 40, 227, 229, 242, 56, 20, 119, 220, 61, 253, 30, 14, 251, 213, 245, 102, 253, 238, 80, 139, 17, 68, 15, 85, 81, 128) // RISE_AND_FALL not available on this chip
TRANSLATION("RTC is not supported on this board", 34, 227, 230, 101, 97, 77, 238, 8, 177, 20, 65, 165, 154, 68, 0) // RTC is not supported on this board
TRANSLATION("Read not permitted", 18, 227, 164, 200, 155, 27, 144, 87, 98, 80) // Read not permitted
TRANSLATION("Read-only", 9, 227, 164, 200, 199, 137, 251, 224) // Read-only
TRANSLATION("Read-only filesystem", 20, 227, 164, 200, 199, 139, 171, 237, 149, 251, 137, 128) // Read-only filesystem
TRANSLATION("Read-only object", 16, 227, 164, 200, 199, 139, 171, 216) // Read-only object
TRANSLATION("Refresh too soon", 16, 227, 165, 219, 101, 87, 202, 37, 196) // Refresh too soon
TRANSLATION("Requested AES mode is unsupported", 33, 227, 251, 73, 185, 79, 125, 192, 228, 14, 187, 106, 33, 44, 61, 192) // Requested AES mode is unsupported
TRANSLATION("Running in safe mode! Not running saved code.\n", 47, 227, 203, 12, 53, 131, 192, 140, 235, 125, 116, 255, 96, 225, 173, 130, 73, 97, 134, 176, 35, 93, 166, 117, 161, 52, 54, 64) // Running in safe mode! Not running saved code.\r\n
TRANSLATION("SD card CSD format not supported", 32, 255, 65, 149, 200, 223, 224, 245, 166, 247, 0) // SD card CSD format not supported
TRANSLATION("SPI peripheral in use", 21, 228, 113, 178, 196, 110, 42, 58, 174, 114, 222, 218, 0) // SPI peripheral in use
TRANSLATION("Scan already in progess. Stop with stop_scan.", 45, 228, 31, 55, 238, 135, 132, 114, 46, 162, 72, 168, 14, 67, 23, 30, 212, 92, 92, 116, 72, 230, 134, 128) // Scan already in progess. Stop with stop_scan.
TRANSLATION("Sleep Memory not available", 26, 228, 88, 76, 99, 132, 152, 44, 223, 155, 247, 185, 64) // Sleep Memory not available
TRANSLATION("Slice and value different lengths.", 34, 228, 123, 205, 243, 124, 33, 10, 117, 215, 52, 70, 161, 80) // Slice and value different lengths.
TRANSLATION("Slices not supported", 20, 228, 123, 201, 41, 189, 192) // Slices not supported
TRANSLATION("Source and destination buffers must be the same length", 54, 228, 46, 89, 14, 223, 53, 9, 184, 245, 37, 68, 26, 239, 148, 198, 85, 108, 141, 3, 122, 128) // Source and destination buffers must be the same length
TRANSLATION("Specify exactly one of data0 or data_pins", 41, 228, 70, 147, 169, 219, 227, 72, 199, 103, 86, 38, 214, 232, 69, 35, 100, 11, 72, 164, 106, 49, 188, 64) // Specify exactly one of data0 or data_pins
TRANSLATION("Splitting with sub-captures", 27, 228, 70, 253, 118, 86, 218, 130, 149, 172, 115, 154, 54, 75, 108, 128) // Splitting with sub-captures
TRANSLATION("Stereo left must be on PWM channel A", 36, 228, 49, 196, 172, 88, 117, 147, 34, 31, 100, 126, 1, 190) // Stereo left must be on PWM channel A
TRANSLATION("Stereo right must be on PWM channel B", 37, 228, 49, 196, 172, 73, 249, 102, 68, 62, 200, 252, 3, 36) // Stereo right must be on PWM channel B
TRANSLATION("Supply one of monotonic_time or epoch_time", 42, 228, 120, 35, 234, 196, 218, 221, 16, 68, 182, 68, 163, 209, 238, 183, 105, 49, 172, 245, 104, 247, 82) // Supply one of monotonic_time or epoch_time
TRANSLATION("The CircuitPython heap was corrupted because the stack was too small.\nIncrease the stack size if you know how. If not:", 119, 204, 170, 223, 249, 196, 42, 164, 209, 139, 198, 32, 123, 50, 120, 25, 77, 164, 156, 210, 147, 108, 170, 221, 207, 92, 94, 49, 121, 69, 7, 50, 134, 203, 46, 19, 219, 49, 54, 202, 173, 220, 245, 252, 150, 212, 232, 190, 185, 71, 82, 21, 222, 21, 87, 122, 128, 203, 116, 66, 182, 111, 0) // The CircuitPython heap was corrupted because the stack was too small.\r\nIncrease the stack size if you know how. If not:
TRANSLATION("The `microcontroller` module was used to boot into safe mode. Press reset to exit safe mode.", 92, 204, 170, 223, 253, 64, 163, 200, 179, 196, 201, 22, 253, 137, 63, 232, 117, 229, 176, 47, 24, 182, 136, 197, 105, 107, 96, 121, 139, 4, 103, 91, 235, 166, 128, 227, 91, 34, 22, 251, 120, 186, 85, 193, 25, 214, 250, 233, 160) // The `microcontroller` module was used to boot into safe mode. Press reset to exit safe mode.
TRANSLATION("The length of rgb_pins must be 6, 12, 18, 24, or 30", 51, 204, 170, 222, 166, 28, 149, 26, 163, 27, 197, 51, 234, 227, 110, 183, 120, 219, 175, 71, 27, 119, 232, 99, 90, 243, 242, 0) // The length of rgb_pins must be 6, 12, 18, 24, or 30
TRANSLATION("The microcontroller's power dipped. Make sure your power supply provides\nenough power for the whole circuit and press reset (after ejecting CIRCUITPY).", 152, 204, 170, 220, 10, 60, 139, 60, 76, 145, 111, 216, 146, 121, 8, 215, 121, 192, 133, 71, 26, 81, 64, 112, 141, 212, 108, 165, 182, 47, 174, 89, 4, 107, 188, 224, 47, 4, 125, 95, 220, 146, 217, 104, 46, 90, 149, 68, 107, 188, 230, 14, 35, 119, 170, 174, 192, 58, 164, 60, 181, 199, 54, 59, 100, 66, 223, 108, 109, 204, 235, 28, 9, 253, 29, 42, 195, 252, 183, 20, 0) // The microcontroller\'s power dipped. Make sure your power supply provides\r\nenough power for the whole circuit and press reset (after ejecting CIRCUITPY).
TRANSLATION("The sample's bits_per_sample does not match the mixer's", 55, 204, 170, 217, 27, 86, 196, 242, 13, 87, 42, 49, 185, 68, 141, 171, 99, 199, 155, 239, 226, 55, 2, 182, 28, 158, 64) // The sample\'s bits_per_sample does not match the mixer\'s
TRANSLATION("The sample's channel count does not match the mixer's", 53, 204, 170, 217, 27, 86, 196, 242, 31, 128, 31, 178, 207, 30, 111, 191, 136, 220, 10, 216, 114, 121, 0) // The sample\'s channel count does not match the mixer\'s
TRANSLATION("The sample's sample rate does not match the mixer's", 51, 204, 170, 217, 27, 86, 196, 242, 4, 109, 91, 2, 74, 77, 161, 105, 41, 190, 254, 35, 112, 43, 97, 201, 228) // The sample\'s sample rate does not match the mixer\'s
TRANSLATION("The sample's signedness does not match the mixer's", 50, 204, 170, 217, 27, 86, 196, 242, 31, 50, 81, 10, 72, 188, 121, 190, 254, 35, 112, 43, 97, 201, 228) // The sample\'s signedness does not match the mixer\'s
TRANSLATION("This microcontroller does not support continuous capture.", 57, 204, 170, 162, 16, 40, 242, 44, 241, 50, 69, 191, 98, 79, 30, 105, 120, 35, 178, 192, 120, 152, 244, 171, 148, 129, 205, 27, 37, 183, 64) // This microcontroller does not support continuous capture.
TRANSLATION("This microcontroller only supports data0=, not data_pins=, because it requires contiguous pins.", 95, 204, 170, 162, 16, 40, 242, 44, 241, 50, 69, 191, 98, 65, 23, 84, 188, 17, 217, 97, 4, 82, 54, 70, 247, 27, 226, 69, 35, 81, 141, 226, 222, 227, 52, 147, 154, 82, 110, 191, 144, 64, 241, 49, 85, 37, 92, 164, 35, 120, 168, 0) // This microcontroller only supports data0=, not data_pins=, because it requires contiguous pins.
TRANSLATION("Tile height must exactly divide bitmap height", 45, 204, 85, 129, 85, 63, 151, 103, 164, 99, 179, 170, 133, 93, 82, 27, 246, 5, 84, 254, 80) // Tile height must exactly divide bitmap height
TRANSLATION("Tile index out of bounds", 24, 204, 85, 128, 242, 52, 134, 182, 27, 93, 148, 16) // Tile index out of bounds
TRANSLATION("Tile width must exactly divide bitmap width", 43, 204, 85, 129, 121, 72, 101, 93, 158, 145, 142, 206, 170, 21, 117, 72, 111, 216, 23, 148, 134, 85) // Tile width must exactly divide bitmap width
TRANSLATION("Time is in the past.", 20, 204, 84, 13, 168, 131, 216, 141, 198, 107, 148, 0) // Time is in the past.
TRANSLATION("Timeout is too long: Maximum timeout length is %d seconds", 57, 204, 84, 9, 214, 194, 242, 159, 138, 166, 240, 112, 190, 255, 117, 58, 195, 83, 11, 0, 18, 79, 18, 8) // Timeout is too long: Maximum timeout length is %d seconds
TRANSLATION("Timeout waiting for HCI response", 32, 204, 84, 9, 214, 23, 141, 94, 182, 8, 251, 22, 202, 56, 137, 32) // Timeout waiting for HCI response
TRANSLATION("Timeout waiting to write HCI request", 36, 204, 84, 9, 214, 23, 141, 94, 182, 45, 233, 43, 183, 246, 45, 254, 249, 83, 112) // Timeout waiting to write HCI request
TRANSLATION("To exit, please reset the board without ", 40, 204, 88, 210, 175, 141, 29, 131, 19, 118, 251, 120, 141, 180, 179, 72, 141, 174, 176) // To exit, please reset the board without 
TRANSLATION("Too many Adapters", 17, 204, 253, 155, 228, 26, 54, 56, 64) // Too many Adapters
TRANSLATION("Too many channels in sample.", 28, 204, 253, 159, 128, 131, 192, 141, 171, 98, 128) // Too many channels in sample.
TRANSLATION("Too many display busses", 23, 204, 253, 136, 252, 225, 169, 72, 146, 64) // Too many display busses
TRANSLATION("Too many displays", 17, 204, 253, 136, 252, 228) // Too many displays
TRANSLATION("Total data to write is larger than outgoing_packet_length", 57, 204, 91, 57, 104, 164, 108, 91, 210, 87, 109, 68, 31, 231, 185, 137, 155, 173, 81, 117, 168, 199, 235, 165, 148, 117, 0) // Total data to write is larger than outgoing_packet_length
TRANSLATION("Touch alarms not available", 26, 204, 92, 167, 170, 62, 225, 77, 251, 220, 160) // Touch alarms not available
TRANSLATION("Traceback (most recent call last):\n", 36, 204, 144, 199, 75, 94, 184, 219, 192, 187, 130, 217, 244, 65, 249, 129, 243, 92, 220, 111, 54, 64) // Traceback (most recent call last):\r\n
TRANSLATION("Tuple or struct_time argument required", 38, 204, 240, 88, 22, 174, 73, 41, 217, 71, 186, 222, 119, 144, 128) // Tuple or struct_time argument required
TRANSLATION("USB busy", 8, 251, 65, 169, 74, 248) // USB busy
TRANSLATION("USB devices need more endpoints than are available.", 51, 251, 94, 50, 72, 66, 154, 112, 89, 111, 65, 17, 173, 230, 22, 38, 105, 173, 143, 189, 202, 160) // USB devices need more endpoints than are available.
TRANSLATION("USB devices specify too many interface names.", 45, 251, 94, 50, 72, 20, 105, 58, 157, 191, 229, 64, 104, 111, 135, 152, 227, 166, 59, 112, 154, 4, 149, 0) // USB devices specify too many interface names.
TRANSLATION("USB error", 9, 251, 65, 201, 44, 128) // USB error
TRANSLATION("UUID integer value must be 0-0xffff", 35, 255, 80, 243, 19, 81, 193, 225, 153, 145, 143, 145, 176, 235, 174, 186) // UUID integer value must be 0-0xffff
TRANSLATION("UUID string not 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'", 54, 255, 81, 114, 74, 211, 103, 255, 95, 235, 143, 253, 113, 255, 174, 63, 245, 199, 254, 191, 215, 250, 207) // UUID string not \'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\'
TRANSLATION("UUID value is not str, int or byte buffer", 41, 255, 81, 225, 194, 155, 114, 76, 103, 152, 45, 116, 3, 93, 240) // UUID value is not str, int or byte buffer
TRANSLATION("Unable to allocate buffers for signed conversion", 48, 228, 195, 202, 197, 230, 44, 244, 155, 107, 190, 88, 35, 230, 166, 120, 174, 184, 74, 136) // Unable to allocate buffers for signed conversion
TRANSLATION("Unable to find I2C Display at %x", 32, 228, 195, 202, 197, 117, 228, 12, 189, 222, 80, 223, 254, 113, 72, 121, 123, 0) // Unable to find I2C Display at %x
TRANSLATION("Unable to init parser", 21, 228, 195, 202, 197, 122, 184, 140, 210, 19, 128) // Unable to init parser
TRANSLATION("Unable to read color palette data", 33, 228, 195, 202, 197, 182, 100, 15, 102, 212, 102, 176, 198, 54, 138, 70) // Unable to read color palette data
TRANSLATION("Unable to write to nvm.", 23, 228, 195, 202, 197, 189, 37, 118, 216, 177, 13, 216, 40, 0) // Unable to write to nvm.
TRANSLATION("Unable to write to sleep_memory.", 32, 228, 195, 202, 197, 189, 37, 118, 216, 176, 86, 19, 29, 24, 19, 5, 155, 244, 0) // Unable to write to sleep_memory.
TRANSLATION("Unknown ATT error: 0x%02x", 25, 228, 255, 216, 223, 102, 102, 7, 36, 179, 188, 25, 27, 30, 94, 70, 239, 96) // Unknown ATT error: 0x%02x
TRANSLATION("Unknown hci_result_t: %d", 24, 228, 255, 216, 170, 117, 81, 182, 82, 190, 202, 44, 222, 96, 0) // Unknown hci_result_t: %d
TRANSLATION("Unknown reason.", 15, 228, 255, 216, 182, 98, 138, 128) // Unknown reason.
TRANSLATION("Unlikely", 8, 228, 194, 250, 186, 137, 126, 248) // Unlikely
TRANSLATION("Unmatched number of items on RHS (expected %d, got %d).", 55, 228, 195, 239, 211, 253, 110, 97, 215, 76, 4, 34, 28, 127, 175, 200, 27, 125, 40, 250, 84, 246, 216, 213, 22, 204, 13, 197, 0) // Unmatched number of items on RHS (expected %d, got %d).
TRANSLATION("Unsupported colorspace", 22, 228, 195, 220, 30, 205, 146, 140, 199, 72) // Unsupported colorspace
TRANSLATION("Unsupported display bus type", 28, 228, 195, 220, 8, 252, 225, 169, 72, 119, 128) // Unsupported display bus type
TRANSLATION("Unsupported format", 18, 228, 195, 220, 193, 235, 0) // Unsupported format
TRANSLATION("Unsupported group type", 22, 228, 195, 220, 21, 36, 95, 128, 119, 128) // Unsupported group type
TRANSLATION("Value length != required fixed length", 37, 251, 102, 126, 86, 245, 7, 246, 111, 124, 132, 7, 85, 177, 79, 80) // Value length != required fixed length
TRANSLATION("Value length > max_length", 25, 251, 102, 126, 86, 245, 7, 164, 32, 54, 197, 29, 64) // Value length > max_length
TRANSLATION("Value not allowed", 17, 251, 102, 126, 86, 254, 46, 98, 239, 37, 0) // Value not allowed
TRANSLATION("WARNING: Your code filename has two extensions\n", 48, 245, 183, 220, 126, 30, 95, 15, 211, 222, 15, 247, 92, 178, 3, 173, 13, 251, 112, 154, 6, 244, 200, 50, 242, 198, 147, 52, 9, 81, 22, 200) // WARNING: Your code filename has two extensions\r\n
TRANSLATION("WatchDogTimer cannot be deinitialized once mode is set to RESET", 63, 255, 103, 1, 249, 205, 54, 132, 189, 93, 70, 125, 94, 42, 113, 29, 190, 187, 106, 33, 219, 197, 227, 240, 57, 28, 12, 192) // WatchDogTimer cannot be deinitialized once mode is set to RESET
TRANSLATION("WatchDogTimer is not currently running", 38, 255, 103, 48, 166, 158, 89, 45, 194, 206, 172, 146, 195, 13, 96) // WatchDogTimer is not currently running
TRANSLATION("WatchDogTimer.mode cannot be changed once set to WatchDogMode.RESET", 67, 255, 103, 40, 117, 219, 63, 57, 166, 207, 167, 13, 74, 113, 29, 190, 222, 47, 173, 72, 245, 119, 235, 169, 194, 90, 19, 67, 143, 192, 228, 112, 51, 0) // WatchDogTimer.mode cannot be changed once set to WatchDogMode.RESET
TRANSLATION("WatchDogTimer.timeout must be greater than 0", 44, 255, 103, 40, 119, 83, 173, 50, 165, 186, 78, 98, 102, 228, 0) // WatchDogTimer.timeout must be greater than 0
TRANSLATION("Watchdog timer expired.", 23, 245, 169, 30, 170, 23, 80, 119, 92, 26, 81, 170, 218, 40, 0) // Watchdog timer expired.
TRANSLATION("Welcome to Adafruit CircuitPython %s!\n\nVisit circuitpython.org for more information.\n\nTo list built-in modules type `help(\"modules\")`.\n", 140, 245, 146, 249, 215, 3, 108, 88, 223, 32, 206, 201, 45, 113, 254, 113, 15, 44, 191, 179, 101, 178, 251, 106, 42, 224, 234, 144, 242, 215, 142, 251, 42, 197, 66, 205, 76, 17, 5, 150, 222, 118, 207, 89, 81, 80, 217, 108, 179, 22, 31, 85, 192, 212, 170, 125, 152, 239, 14, 188, 182, 8, 119, 135, 253, 85, 75, 241, 237, 254, 159, 94, 91, 5, 244, 247, 31, 245, 67, 100) // Welcome to Adafruit CircuitPython %s!\r\n\r\nVisit circuitpython.org for more information.\r\n\r\nTo list built-in modules type `help(\"modules\")`.\r\n
TRANSLATION("Woken up by alarm.\n", 20, 245, 151, 212, 208, 30, 0, 213, 241, 247, 40, 108, 128) // Woken up by alarm.\r\n
TRANSLATION("Write not permitted", 19, 245, 164, 174, 223, 197, 27, 144, 87, 98, 80) // Write not permitted
TRANSLATION("Writes not supported on Characteristic", 38, 245, 164, 174, 146, 155, 220, 17, 12, 175, 200, 226, 174, 40, 224) // Writes not supported on Characteristic
TRANSLATION("You are in safe mode because:\n", 31, 255, 117, 202, 13, 108, 60, 8, 206, 183, 215, 109, 164, 156, 210, 146, 119, 155, 32) // You are in safe mode because:\r\n
TRANSLATION("You pressed the reset button during boot. Press again to exit safe mode.", 72, 255, 117, 202, 35, 182, 69, 77, 149, 91, 183, 219, 13, 74, 198, 68, 17, 44, 149, 131, 75, 91, 40, 14, 53, 178, 32, 106, 134, 123, 23, 74, 184, 35, 58, 223, 93, 52, 0) // You pressed the reset button during boot. Press again to exit safe mode.
TRANSLATION("You requested starting safe mode by ", 36, 255, 117, 202, 45, 254, 249, 83, 114, 157, 195, 72, 202, 192, 140, 235, 125, 118, 218, 190, 0) // You requested starting safe mode by 
TRANSLATION("\nCode done running.\n", 22, 217, 101, 45, 13, 162, 38, 228, 150, 24, 107, 80, 217, 0) // \r\nCode done running.\r\n
TRANSLATION("\nCode stopped by auto-reload. Reloading soon.\n", 48, 217, 101, 45, 13, 220, 92, 113, 211, 106, 248, 52, 172, 94, 61, 183, 214, 100, 80, 28, 116, 190, 179, 34, 176, 37, 197, 67, 100) // \r\nCode stopped by auto-reload. Reloading soon.\r\n
TRANSLATION("\nPlease file an issue with the contents of your CIRCUITPY drive at \nhttps://github.com/adafruit/circuitpython/issues\n", 120, 217, 113, 172, 24, 155, 246, 198, 106, 136, 165, 110, 245, 122, 184, 141, 158, 38, 104, 150, 29, 245, 203, 32, 255, 32, 137, 21, 117, 186, 67, 101, 85, 140, 140, 183, 155, 157, 205, 74, 245, 101, 106, 129, 215, 6, 228, 200, 51, 178, 75, 95, 114, 117, 72, 121, 107, 199, 125, 149, 98, 220, 168, 138, 84, 150, 200) // \r\nPlease file an issue with the contents of your CIRCUITPY drive at \r\nhttps://github.com/adafruit/circuitpython/issues\r\n
TRANSLATION("__init__() should return None, not '%q'", 39, 163, 69, 234, 244, 104, 249, 128, 170, 252, 130, 219, 37, 146, 17, 195, 137, 56, 223, 20, 249, 211, 192) // __init__() should return None, not \'%q\'
TRANSLATION("__new__ arg must be a user-type", 31, 163, 70, 20, 222, 163, 68, 115, 230, 27, 105, 38, 63, 120) // __new__ arg must be a user-type
TRANSLATION("a bytes-like object is required", 31, 48, 232, 22, 59, 234, 234, 55, 216, 194, 242, 16) // a bytes-like object is required
TRANSLATION("abort() called", 14, 51, 86, 89, 230, 3, 243, 18, 128) // abort() called
TRANSLATION("arg is an empty sequence", 24, 231, 225, 12, 212, 234, 178, 248, 47, 107, 64, 233) // arg is an empty sequence
TRANSLATION("argsort argument must be an ndarray", 35, 231, 149, 150, 12, 233, 153, 176, 163, 60) // argsort argument must be an ndarray
TRANSLATION("argsort is not implemented for flattened arrays", 47, 231, 149, 150, 97, 77, 252, 216, 33, 215, 233, 51, 66, 158, 121, 0) // argsort is not implemented for flattened arrays
TRANSLATION("argument has wrong type", 23, 206, 26, 100, 47, 73, 21, 65, 222) // argument has wrong type
TRANSLATION("argument name reused", 20, 206, 16, 154, 6, 237, 202, 73, 64) // argument name reused
TRANSLATION("argument num/types mismatch", 27, 206, 16, 203, 6, 231, 188, 66, 5, 23, 190) // argument num/types mismatch
TRANSLATION("argument should be a '%q' not a '%q'", 36, 206, 250, 70, 19, 231, 79, 154, 97, 62, 116, 240) // argument should be a \'%q\' not a \'%q\'
TRANSLATION("arguments must be ndarrays", 26, 206, 41, 144, 163, 60, 128) // arguments must be ndarrays
TRANSLATION("array and index length must be equal", 36, 207, 28, 215, 145, 164, 53, 38, 123, 70, 124) // array and index length must be equal
TRANSLATION("array/bytes required on right side", 34, 207, 220, 244, 11, 200, 64, 136, 73, 249, 65, 41, 9) // array/bytes required on right side
TRANSLATION("attempt to get (arg)min/(arg)max of empty sequence", 50, 164, 196, 234, 179, 22, 162, 88, 54, 252, 253, 196, 15, 110, 118, 252, 253, 196, 6, 216, 195, 78, 171, 47, 130, 246, 180, 14, 144) // attempt to get (arg)min/(arg)max of empty sequence
TRANSLATION("attempt to get argmin/argmax of an empty sequence", 49, 164, 196, 234, 179, 22, 162, 88, 57, 240, 61, 185, 231, 192, 109, 140, 60, 212, 234, 178, 248, 47, 107, 64, 233) // attempt to get argmin/argmax of an empty sequence
TRANSLATION("attributes not supported yet", 28, 165, 252, 210, 83, 123, 130, 250, 88) // attributes not supported yet
TRANSLATION("axis is out of bounds", 21, 54, 194, 139, 8, 107, 97, 181, 217, 65, 0) // axis is out of bounds
TRANSLATION("axis must be None, or an integer", 32, 54, 194, 138, 103, 14, 36, 227, 90, 205, 121, 137, 168, 224) // axis must be None, or an integer
TRANSLATION("axis too long", 13, 54, 194, 139, 202, 126, 42, 128) // axis too long
TRANSLATION("background value out of range of target", 39, 107, 215, 169, 39, 101, 3, 194, 53, 176, 254, 86, 214, 232, 103, 61, 44) // background value out of range of target
TRANSLATION("bad conversion specifier", 24, 104, 200, 7, 138, 235, 132, 168, 135, 206, 224) // bad conversion specifier
TRANSLATION("bad typecode", 12, 104, 200, 29, 227, 173, 9) // bad typecode
TRANSLATION("bitmap sizes must match", 23, 246, 60, 148, 150, 207, 223) // bitmap sizes must match
TRANSLATION("bits_per_sample must be 8 or 16", 31, 106, 185, 81, 141, 202, 36, 109, 91, 19, 61, 17, 107, 206) // bits_per_sample must be 8 or 16
TRANSLATION("buffer is smaller than requested size", 37, 107, 191, 132, 10, 14, 99, 152, 153, 182, 255, 124, 169, 185, 76, 149, 226, 72) // buffer is smaller than requested size
TRANSLATION("buffer size must be a multiple of element size", 46, 107, 191, 228, 183, 250, 155, 48, 248, 48, 211, 98, 13, 31, 37, 32) // buffer size must be a multiple of element size
TRANSLATION("buffer size must match format", 29, 107, 191, 228, 183, 4, 183, 7, 191, 131, 214) // buffer size must match format
TRANSLATION("buffer slices must be of equal length", 37, 107, 190, 11, 222, 73, 76, 91, 163, 218, 229, 234, 0) // buffer slices must be of equal length
TRANSLATION("buffer too small", 16, 107, 191, 229, 20, 28, 192) // buffer too small
TRANSLATION("byteorder is not a string", 25, 232, 89, 67, 152, 83, 76, 46, 73, 88) // byteorder is not a string
TRANSLATION("bytes length not a multiple of item size", 40, 232, 16, 212, 154, 97, 240, 97, 215, 76, 30, 74, 64) // bytes length not a multiple of item size
TRANSLATION("bytes value out of range", 24, 232, 16, 240, 141, 108, 63, 149, 32) // bytes value out of range
TRANSLATION("can only have one parent", 24, 62, 108, 93, 93, 59, 173, 196, 220, 102, 183, 11, 0) // can only have one parent
TRANSLATION("can't add special method to already-subclassed class", 52, 232, 153, 8, 5, 26, 78, 174, 92, 9, 101, 85, 163, 23, 238, 227, 255, 42, 103, 124, 196, 64) // can\'t add special method to already-subclassed class
TRANSLATION("can't assign to expression", 26, 232, 152, 190, 108, 93, 40, 237, 145, 42, 32) // can\'t assign to expression
TRANSLATION("can't cancel self", 17, 232, 156, 208, 157, 47, 130, 75, 238, 128) // can\'t cancel self
TRANSLATION("can't convert %q to %q", 22, 232, 158, 43, 174, 48, 78, 197, 156) // can\'t convert %q to %q
TRANSLATION("can't convert %q to int", 23, 232, 158, 43, 174, 48, 78, 197, 121, 128) // can\'t convert %q to int
TRANSLATION("can't convert %s to complex", 27, 232, 158, 43, 174, 48, 121, 101, 138, 117, 234, 216, 216) // can\'t convert %s to complex
TRANSLATION("can't convert '%q' object to %q implicitly", 42, 232, 158, 43, 174, 48, 79, 157, 60, 118, 49, 103, 5, 106, 251, 213, 223, 190) // can\'t convert \'%q\' object to %q implicitly
TRANSLATION("can't declare nonlocal in outer code", 36, 232, 161, 39, 124, 214, 196, 49, 62, 179, 242, 222, 26, 206, 3, 173, 9) // can\'t declare nonlocal in outer code
TRANSLATION("can't delete expression", 23, 232, 161, 54, 24, 222, 148, 118, 200, 149, 16) // can\'t delete expression
TRANSLATION("can't do truncated division of a complex number", 47, 232, 161, 97, 146, 75, 9, 233, 83, 66, 174, 168, 149, 22, 25, 129, 215, 171, 99, 96, 126, 183, 0) // can\'t do truncated division of a complex number
TRANSLATION("can't have multiple **x", 23, 232, 233, 221, 111, 224, 30, 111, 155, 176) // can\'t have multiple **x
TRANSLATION("can't have multiple *x", 22, 232, 233, 221, 111, 224, 30, 110, 192) // can\'t have multiple *x
TRANSLATION("can't perform relative import", 29, 232, 198, 227, 182, 96, 22, 223, 164, 171, 173, 171, 86, 203, 0) // can\'t perform relative import
TRANSLATION("can't send non-None value to a just-started generator", 53, 232, 150, 130, 4, 49, 99, 240, 226, 111, 195, 138, 97, 250, 37, 185, 143, 112, 210, 50, 157, 77, 7, 41, 89) // can\'t send non-None value to a just-started generator
TRANSLATION("can't set 512 block size", 24, 232, 246, 199, 247, 110, 183, 97, 175, 211, 228, 164) // can\'t set 512 block size
TRANSLATION("can't set attribute", 19, 232, 246, 197, 47, 230, 144) // can\'t set attribute
TRANSLATION("can't switch from automatic field numbering to manual field specification", 73, 232, 149, 234, 231, 170, 63, 17, 165, 98, 250, 202, 56, 117, 73, 125, 3, 245, 185, 91, 22, 3, 67, 47, 45, 213, 37, 244, 15, 156, 244, 149, 16) // can\'t switch from automatic field numbering to manual field specification
TRANSLATION("can't switch from manual field specification to automatic field numbering", 73, 232, 149, 234, 231, 170, 63, 20, 6, 134, 94, 91, 170, 75, 232, 31, 57, 233, 42, 44, 83, 74, 197, 245, 148, 112, 234, 146, 250, 7, 235, 114, 176) // can\'t switch from manual field specification to automatic field numbering
TRANSLATION("cannot assign new shape", 23, 63, 56, 197, 243, 8, 83, 120, 22, 156, 105) // cannot assign new shape
TRANSLATION("cannot cast output with casting rule", 36, 63, 56, 230, 184, 53, 187, 91, 80, 115, 92, 172, 36, 150, 192) // cannot cast output with casting rule
TRANSLATION("cannot create '%q' instances", 28, 63, 56, 246, 233, 55, 62, 116, 240, 245, 195, 66, 116, 144) // cannot create \'%q\' instances
TRANSLATION("cannot import name %q", 21, 63, 57, 90, 182, 88, 33, 52, 13, 206) // cannot import name %q
TRANSLATION("chr() arg not in range(0x110000)", 32, 61, 89, 60, 193, 207, 154, 240, 249, 83, 183, 200, 216, 221, 110, 178, 50, 50, 50, 55, 0) // chr() arg not in range(0x110000)
TRANSLATION("clip point must be (x,y) tuple", 30, 59, 234, 140, 70, 183, 153, 51, 111, 177, 255, 155, 251, 128, 207, 5, 128) // clip point must be (x,y) tuple
TRANSLATION("code outside range 0~127", 24, 58, 208, 222, 177, 41, 13, 252, 173, 228, 127, 255, 186, 221, 255, 244) // code outside range 0~127
TRANSLATION("color buffer must be 3 bytes (RGB) or 4 bytes (RGB + pad byte)", 62, 246, 109, 53, 223, 153, 231, 142, 129, 13, 191, 31, 211, 201, 220, 11, 94, 128, 232, 16, 219, 241, 253, 60, 145, 255, 129, 25, 144, 58, 27, 128) // color buffer must be 3 bytes (RGB) or 4 bytes (RGB + pad byte)
TRANSLATION("color buffer must be a buffer, tuple, list, or int", 50, 246, 109, 53, 223, 152, 96, 215, 127, 25, 158, 11, 24, 207, 170, 230, 53, 167, 152) // color buffer must be a buffer, tuple, list, or int
TRANSLATION("color buffer must be a bytearray or array of type 'b' or 'B'", 60, 246, 109, 53, 223, 152, 97, 208, 207, 22, 179, 240, 251, 194, 123, 83, 197, 169, 249, 51, 192) // color buffer must be a bytearray or array of type \'b\' or \'B\'
TRANSLATION("color must be between 0x000000 and 0xffffff", 43, 246, 109, 126, 166, 218, 75, 47, 39, 64, 100, 108, 100, 100, 100, 100, 100, 100, 14, 110, 70, 195, 174, 186, 235, 174, 128) // color must be between 0x000000 and 0xffffff
TRANSLATION("color should be an int", 22, 246, 109, 21, 95, 144, 52, 222, 107, 204) // color should be an int
TRANSLATION("complex division by zero", 24, 58, 245, 108, 108, 4, 42, 234, 137, 81, 6, 175, 143, 19, 139) // complex division by zero
TRANSLATION("constant must be an integer", 27, 60, 87, 13, 11, 38, 102, 188, 196, 212, 112) // constant must be an integer
TRANSLATION("convolve arguments must be linear arrays", 40, 60, 87, 86, 253, 214, 243, 138, 99, 239, 36, 210, 12, 242) // convolve arguments must be linear arrays
TRANSLATION("convolve arguments must be ndarrays", 35, 60, 87, 86, 253, 214, 243, 138, 100, 40, 207, 32) // convolve arguments must be ndarrays
TRANSLATION("convolve arguments must not be empty", 36, 60, 87, 86, 253, 214, 243, 139, 103, 241, 52, 218, 117, 89, 124) // convolve arguments must not be empty
TRANSLATION("could not invert Vandermonde matrix", 35, 63, 201, 53, 235, 174, 48, 125, 179, 66, 135, 32, 137, 13, 245, 164, 86, 192) // could not invert Vandermonde matrix
TRANSLATION("couldn't determine SD card version", 34, 63, 201, 240, 161, 44, 114, 7, 155, 255, 65, 117, 194, 84, 64) // couldn\'t determine SD card version
TRANSLATION("cross is defined for 1D arrays of length 3", 42, 60, 139, 34, 194, 8, 75, 175, 83, 118, 214, 235, 126, 51, 203, 15, 80, 121, 224) // cross is defined for 1D arrays of length 3
TRANSLATION("data type not understood", 24, 69, 35, 14, 244, 217, 97, 67, 151, 22, 180, 0) // data type not understood
TRANSLATION("default 'except' must be last", 29, 252, 34, 126, 145, 211, 27, 39, 204, 124, 215, 0) // default \'except\' must be last
TRANSLATION("default is not a function", 25, 252, 56, 83, 76, 58, 122, 224) // default is not a function
TRANSLATION("destination buffer must be a bytearray or array of type 'B' for bit_depth = 8", 77, 66, 110, 61, 73, 81, 6, 187, 243, 12, 58, 25, 226, 214, 126, 31, 120, 79, 201, 159, 130, 26, 175, 69, 9, 141, 149, 70, 244, 122, 32) // destination buffer must be a bytearray or array of type \'B\' for bit_depth = 8
TRANSLATION("destination buffer must be an array of type 'H' for bit_depth = 16", 66, 66, 110, 61, 73, 81, 6, 187, 243, 51, 115, 240, 251, 194, 127, 215, 159, 130, 26, 175, 69, 9, 141, 149, 70, 244, 121, 192) // destination buffer must be an array of type \'H\' for bit_depth = 16
TRANSLATION("destination_length must be an int >= 0", 38, 66, 110, 61, 73, 81, 81, 212, 153, 154, 243, 7, 165, 189, 25, 0) // destination_length must be an int >= 0
TRANSLATION("dict update sequence has wrong length", 37, 66, 142, 193, 224, 69, 38, 203, 218, 208, 59, 122, 100, 47, 73, 21, 65, 168) // dict update sequence has wrong length
TRANSLATION("diff argument must be an ndarray", 32, 66, 157, 116, 103, 76, 205, 133, 25, 224) // diff argument must be an ndarray
TRANSLATION("differentiation order out of range", 34, 66, 157, 117, 205, 21, 82, 84, 66, 202, 28, 26, 216, 127, 42, 64) // differentiation order out of range
TRANSLATION("dimensions do not match", 23, 66, 160, 208, 37, 68, 65, 11, 155, 239, 128) // dimensions do not match
TRANSLATION("divide by zero", 14, 66, 174, 169, 13, 181, 124, 120, 156, 88) // divide by zero
TRANSLATION("division by zero", 16, 66, 174, 168, 149, 16, 106, 248, 241, 56, 176) // division by zero
TRANSLATION("empty heap", 10, 78, 171, 47, 138, 169, 52, 96) // empty heap
TRANSLATION("empty separator", 15, 78, 171, 47, 130, 76, 102, 146, 149, 144) // empty separator
TRANSLATION("empty sequence", 14, 78, 171, 47, 130, 246, 180, 14, 144) // empty sequence
TRANSLATION("end_x should be an int", 22, 208, 69, 29, 143, 165, 154, 243, 0) // end_x should be an int
TRANSLATION("exceptions must derive from BaseException", 41, 210, 58, 99, 215, 45, 154, 28, 85, 214, 255, 22, 73, 137, 60, 13, 131, 166, 61, 112) // exceptions must derive from BaseException
TRANSLATION("expected ':' after format specifier", 35, 210, 143, 165, 78, 126, 242, 120, 51, 172, 115, 7, 172, 62, 119, 0) // expected \':\' after format specifier
TRANSLATION("expecting just a value for set", 30, 210, 143, 165, 88, 126, 137, 110, 3, 15, 14, 8, 237, 128) // expecting just a value for set
TRANSLATION("expecting key:value for dict", 28, 210, 143, 165, 88, 117, 19, 127, 121, 225, 193, 8, 81, 216) // expecting key:value for dict
TRANSLATION("ext_hook is not a function", 26, 210, 101, 26, 171, 95, 83, 10, 105, 135, 79, 92) // ext_hook is not a function
TRANSLATION("extra keyword arguments given", 29, 210, 100, 134, 30, 232, 206, 33, 248, 192) // extra keyword arguments given
TRANSLATION("extra positional arguments given", 32, 210, 100, 134, 17, 172, 171, 170, 46, 94, 113, 15, 198) // extra positional arguments given
TRANSLATION("file must be a file opened in byte mode", 39, 246, 230, 24, 123, 97, 113, 232, 83, 120, 116, 7, 93, 32) // file must be a file opened in byte mode
TRANSLATION("filesystem must provide mount method", 36, 246, 202, 253, 196, 193, 179, 253, 205, 193, 217, 96, 129, 44, 170, 180, 0) // filesystem must provide mount method
TRANSLATION("first argument must be a callable", 33, 247, 6, 116, 195, 3, 243, 57, 64) // first argument must be a callable
TRANSLATION("first argument must be a function", 33, 247, 6, 116, 195, 14, 158, 184) // first argument must be a function
TRANSLATION("first argument must be a tuple of ndarrays", 42, 247, 6, 116, 195, 6, 120, 44, 97, 194, 140, 242) // first argument must be a tuple of ndarrays
TRANSLATION("first argument must be an ndarray", 33, 247, 6, 116, 204, 216, 81, 158) // first argument must be an ndarray
TRANSLATION("first argument to super() must be type", 38, 247, 6, 118, 41, 120, 28, 243, 38, 119, 128) // first argument to super() must be type
TRANSLATION("first two arguments must be ndarrays", 36, 247, 3, 47, 44, 103, 20, 200, 81, 158, 64) // first two arguments must be ndarrays
TRANSLATION("flattening order must be either 'C', or 'F'", 43, 117, 250, 76, 208, 172, 44, 161, 201, 137, 175, 85, 193, 63, 42, 126, 53, 169, 252, 25, 224) // flattening order must be either \'C\', or \'F\'
TRANSLATION("flip argument must be an ndarray", 32, 117, 245, 70, 51, 166, 102, 194, 140, 240) // flip argument must be an ndarray
TRANSLATION("format requires a dict", 22, 118, 207, 91, 200, 32, 96, 133, 29, 128) // format requires a dict
TRANSLATION("frequency is read-only for this board", 37, 118, 223, 239, 151, 64, 247, 240, 133, 179, 35, 30, 46, 171, 182, 153, 85, 68, 26, 89, 164, 64) // frequency is read-only for this board
TRANSLATION("function doesn't take keyword arguments", 39, 233, 235, 248, 255, 11, 13, 212, 111, 221, 25, 196) // function doesn\'t take keyword arguments
TRANSLATION("function expected at most %d arguments, got %d", 46, 233, 235, 141, 40, 250, 84, 233, 8, 23, 115, 0, 103, 22, 53, 69, 179, 0) // function expected at most %d arguments, got %d
TRANSLATION("function got multiple values for argument '%q'", 46, 233, 235, 138, 139, 96, 248, 7, 132, 176, 70, 112, 159, 58, 120) // function got multiple values for argument \'%q\'
TRANSLATION("function has the same sign at the ends of interval", 50, 233, 235, 141, 50, 196, 108, 141, 3, 127, 48, 165, 136, 222, 130, 11, 13, 230, 57, 116, 207, 128) // function has the same sign at the ends of interval
TRANSLATION("function is defined for ndarrays only", 37, 233, 235, 225, 4, 37, 215, 169, 187, 106, 20, 103, 144, 137, 251, 224) // function is defined for ndarrays only
TRANSLATION("function missing %d required positional arguments", 49, 233, 235, 136, 20, 69, 91, 3, 200, 64, 141, 101, 93, 81, 114, 243, 136) // function missing %d required positional arguments
TRANSLATION("function missing keyword-only argument", 38, 233, 235, 136, 20, 69, 88, 123, 184, 241, 117, 115, 128) // function missing keyword-only argument
TRANSLATION("function missing required keyword argument '%q'", 47, 233, 235, 136, 20, 69, 91, 200, 64, 247, 70, 112, 159, 58, 120) // function missing required keyword argument \'%q\'
TRANSLATION("function missing required positional argument #%d", 49, 233, 235, 136, 20, 69, 91, 200, 64, 141, 101, 93, 81, 114, 243, 135, 246, 237, 128) // function missing required positional argument #%d
TRANSLATION("function takes %d positional arguments but %d were given", 56, 233, 235, 134, 27, 168, 146, 192, 17, 172, 171, 170, 46, 94, 113, 6, 165, 102, 0, 188, 227, 127, 140) // function takes %d positional arguments but %d were given
TRANSLATION("function takes exactly 9 arguments", 34, 233, 235, 134, 27, 168, 146, 26, 70, 59, 58, 191, 224, 51, 136) // function takes exactly 9 arguments
TRANSLATION("generator already executing", 27, 169, 160, 229, 43, 95, 116, 105, 36, 242, 178, 176) // generator already executing
TRANSLATION("generator ignored GeneratorExit", 31, 169, 160, 229, 43, 74, 169, 13, 154, 126, 158, 131, 148, 172, 240, 54, 43, 128) // generator ignored GeneratorExit
TRANSLATION("generator raised StopIteration", 30, 169, 160, 229, 43, 82, 25, 69, 79, 144, 197, 199, 150, 199, 41, 42, 32) // generator raised StopIteration
TRANSLATION("identifier redefined as global", 30, 82, 52, 84, 234, 156, 22, 208, 151, 94, 166, 98, 21, 31, 91, 70, 124) // identifier redefined as global
TRANSLATION("identifier redefined as nonlocal", 32, 82, 52, 84, 234, 156, 22, 208, 151, 94, 166, 98, 16, 196, 250, 206, 103, 192) // identifier redefined as nonlocal
TRANSLATION("import * not at module level", 28, 86, 173, 150, 15, 54, 109, 33, 215, 150, 192, 177, 117, 47, 128) // import * not at module level
TRANSLATION("incompatible native .mpy architecture", 37, 120, 235, 213, 164, 166, 172, 8, 105, 42, 235, 116, 53, 111, 131, 72, 122, 181, 250, 82, 219) // incompatible native .mpy architecture
TRANSLATION("incomplete format", 17, 120, 235, 213, 176, 198, 221, 179, 214) // incomplete format
TRANSLATION("incomplete format key", 21, 120, 235, 213, 176, 198, 221, 179, 214, 29, 68, 223) // incomplete format key
TRANSLATION("incorrect padding", 17, 120, 246, 109, 157, 130, 51, 33, 21, 128) // incorrect padding
TRANSLATION("index is out of bounds", 22, 121, 26, 88, 67, 91, 13, 174, 202, 8) // index is out of bounds
TRANSLATION("index out of range", 18, 121, 26, 67, 91, 15, 229, 72) // index out of range
TRANSLATION("indices must be integers, slices, or Boolean lists", 50, 121, 10, 58, 74, 99, 204, 77, 71, 11, 24, 189, 228, 150, 53, 172, 149, 174, 198, 107, 234, 184, 64) // indices must be integers, slices, or Boolean lists
TRANSLATION("initial_value length is wrong", 29, 122, 186, 140, 253, 31, 8, 212, 194, 23, 164, 138, 160) // initial_value length is wrong
TRANSLATION("input and output shapes are not compatible", 42, 123, 180, 57, 186, 221, 160, 90, 113, 164, 129, 173, 205, 58, 245, 105, 41, 171, 0) // input and output shapes are not compatible
TRANSLATION("input argument must be an integer, a tuple, or a list", 53, 123, 180, 51, 166, 102, 188, 196, 212, 115, 24, 193, 158, 11, 24, 214, 140, 31, 85, 192) // input argument must be an integer, a tuple, or a list
TRANSLATION("input array length must be power of 2", 37, 123, 180, 51, 198, 164, 200, 215, 121, 204, 61, 216) // input array length must be power of 2
TRANSLATION("input arrays are not compatible", 31, 123, 180, 51, 200, 26, 220, 211, 175, 86, 146, 154, 176) // input arrays are not compatible
TRANSLATION("input data must be an iterable", 30, 123, 180, 17, 72, 211, 51, 107, 185, 202) // input data must be an iterable
TRANSLATION("input matrix is asymmetric", 26, 123, 180, 58, 210, 43, 99, 8, 24, 175, 193, 2, 89, 34, 142) // input matrix is asymmetric
TRANSLATION("input matrix is singular", 24, 123, 180, 58, 210, 43, 99, 8, 21, 105, 95, 52, 128) // input matrix is singular
TRANSLATION("input must be a dense ndarray", 29, 123, 181, 48, 193, 26, 4, 220, 40, 207) // input must be a dense ndarray
TRANSLATION("input must be a tensor of rank 2", 32, 123, 181, 48, 193, 154, 5, 105, 110, 137, 13, 15, 80, 110, 192) // input must be a tensor of rank 2
TRANSLATION("input must be an ndarray", 24, 123, 181, 51, 54, 20, 103, 128) // input must be an ndarray
TRANSLATION("input must be one-dimensional", 29, 123, 181, 50, 36, 227, 161, 80, 104, 18, 162, 51, 224) // input must be one-dimensional
TRANSLATION("input must be square matrix", 27, 123, 181, 48, 191, 124, 166, 182, 58, 210, 43, 96) // input must be square matrix
TRANSLATION("input must be tuple, list, range, or ndarray", 44, 123, 181, 49, 158, 11, 24, 207, 170, 230, 55, 202, 156, 107, 80, 163, 60) // input must be tuple, list, range, or ndarray
TRANSLATION("input vectors must be of equal length", 37, 123, 180, 46, 244, 172, 148, 197, 186, 61, 174, 94, 160) // input vectors must be of equal length
TRANSLATION("inputs are not iterable", 23, 123, 180, 64, 214, 230, 215, 115, 148) // inputs are not iterable
TRANSLATION("int() arg 2 must be >= 2 and <= 36", 34, 121, 158, 96, 231, 141, 220, 207, 75, 122, 55, 99, 155, 245, 183, 163, 207, 250, 160) // int() arg 2 must be >= 2 and <= 36
TRANSLATION("interp is defined for 1D iterables of equal length", 50, 121, 142, 71, 132, 16, 151, 94, 166, 237, 173, 214, 252, 87, 115, 148, 88, 126, 215, 47, 80) // interp is defined for 1D iterables of equal length
TRANSLATION("interval must be in range %s-%s", 31, 121, 142, 93, 229, 254, 166, 222, 31, 43, 126, 89, 99, 249, 100) // interval must be in range %s-%s
TRANSLATION("invalid bits_per_pixel %d, must be, 1, 2, 4, 8, 16, 24, or 32", 61, 123, 232, 13, 87, 42, 49, 185, 71, 246, 224, 99, 126, 164, 227, 110, 177, 183, 120, 222, 134, 55, 163, 141, 231, 99, 110, 253, 12, 107, 94, 126, 236) // invalid bits_per_pixel %d, must be, 1, 2, 4, 8, 16, 24, or 32
TRANSLATION("invalid element size %d for bits_per_pixel %d\n", 47, 123, 232, 9, 177, 6, 143, 146, 222, 219, 4, 53, 92, 168, 198, 229, 31, 219, 129, 178) // invalid element size %d for bits_per_pixel %d\r\n
TRANSLATION("invalid element_size %d, must be, 1, 2, or 4", 44, 123, 232, 9, 177, 6, 141, 18, 87, 137, 189, 182, 55, 234, 78, 54, 235, 27, 119, 141, 107, 208) // invalid element_size %d, must be, 1, 2, or 4
TRANSLATION("invalid exception", 17, 123, 232, 26, 71, 76, 122, 224) // invalid exception
TRANSLATION("invalid format specifier", 24, 123, 232, 193, 235, 15, 157, 192) // invalid format specifier
TRANSLATION("invalid micropython decorator", 29, 123, 232, 16, 40, 242, 46, 59, 236, 171, 16, 66, 79, 102, 149, 144) // invalid micropython decorator
TRANSLATION("invalid step", 12, 123, 232, 23, 19, 24) // invalid step
TRANSLATION("invalid syntax", 14, 123, 232, 5, 126, 22, 27, 96) // invalid syntax
TRANSLATION("invalid syntax for integer with base %d", 39, 123, 232, 5, 126, 22, 27, 99, 4, 60, 196, 212, 115, 106, 26, 49, 55, 182) // invalid syntax for integer with base %d
TRANSLATION("invalid syntax for number", 25, 123, 232, 5, 126, 22, 27, 99, 4, 126, 183, 0) // invalid syntax for number
TRANSLATION("invalid traceback", 17, 123, 232, 12, 144, 199, 75, 94, 184) // invalid traceback
TRANSLATION("issubclass() arg 1 must be a class", 34, 81, 127, 47, 48, 115, 198, 234, 97, 129, 223, 49, 16) // issubclass() arg 1 must be a class
TRANSLATION("issubclass() arg 2 must be a class or a tuple of classes", 56, 81, 127, 47, 48, 115, 198, 238, 97, 129, 223, 49, 16, 180, 96, 207, 5, 140, 51, 190, 98, 36, 144) // issubclass() arg 2 must be a class or a tuple of classes
TRANSLATION("iterations did not converge", 27, 174, 229, 37, 68, 65, 10, 68, 211, 197, 117, 202, 137) // iterations did not converge
TRANSLATION("join expects a list of str/bytes objects consistent with self object", 68, 253, 11, 120, 105, 71, 210, 32, 96, 250, 174, 97, 220, 147, 115, 208, 33, 216, 32, 120, 137, 87, 52, 118, 160, 146, 251, 163, 176) // join expects a list of str/bytes objects consistent with self object
TRANSLATION("keyword argument(s) not yet implemented - use normal args instead", 65, 247, 70, 118, 220, 183, 19, 111, 165, 131, 243, 12, 125, 160, 134, 204, 28, 190, 121, 7, 174, 36, 200) // keyword argument(s) not yet implemented - use normal args instead
TRANSLATION("keywords must be strings", 24, 247, 74, 101, 201, 43, 16) // keywords must be strings
TRANSLATION("length argument not allowed for this type", 41, 212, 25, 211, 121, 139, 189, 77, 219, 76, 170, 162, 29, 224) // length argument not allowed for this type
TRANSLATION("level must be between 0 and 1", 29, 177, 117, 47, 204, 105, 44, 188, 157, 1, 144, 57, 187, 160) // level must be between 0 and 1
TRANSLATION("lhs and rhs should be compatible", 32, 126, 169, 14, 108, 149, 75, 233, 29, 122, 180, 148, 213, 128) // lhs and rhs should be compatible
TRANSLATION("local variable referenced before assignment", 43, 125, 103, 229, 221, 52, 138, 229, 11, 110, 185, 160, 122, 109, 37, 219, 45, 152, 190, 104, 52, 64) // local variable referenced before assignment
TRANSLATION("malformed f-string", 18, 128, 207, 187, 102, 10, 110, 227, 220, 146, 176) // malformed f-string
TRANSLATION("math domain error", 17, 235, 85, 8, 92, 6, 120, 57, 37, 144) // math domain error
TRANSLATION("matrix is not positive definite", 31, 235, 72, 173, 140, 41, 177, 172, 171, 170, 235, 104, 75, 175, 87, 72) // matrix is not positive definite
TRANSLATION("max_length must be 0-%d when fixed_length is %s", 47, 128, 219, 20, 117, 38, 100, 99, 237, 135, 244, 117, 91, 9, 69, 29, 76, 33, 229, 144) // max_length must be 0-%d when fixed_length is %s
TRANSLATION("maximum number of dimensions is 4", 33, 131, 239, 254, 183, 48, 208, 168, 52, 9, 81, 22, 16, 244, 0) // maximum number of dimensions is 4
TRANSLATION("maximum recursion depth exceeded", 32, 131, 239, 219, 60, 178, 18, 162, 8, 76, 108, 170, 52, 142, 148, 161, 40) // maximum recursion depth exceeded
TRANSLATION("maxiter must be > 0", 19, 128, 219, 21, 220, 153, 233, 12, 128) // maxiter must be > 0
TRANSLATION("maxiter should be > 0", 21, 128, 219, 21, 220, 250, 94, 144, 200) // maxiter should be > 0
TRANSLATION("median argument must be an ndarray", 34, 129, 40, 86, 110, 116, 204, 216, 81, 158) // median argument must be an ndarray
TRANSLATION("memory allocation failed, allocating %u bytes", 45, 129, 48, 89, 190, 57, 139, 61, 37, 68, 29, 50, 172, 35, 27, 152, 179, 210, 172, 60, 185, 71, 64, 128) // memory allocation failed, allocating %u bytes
TRANSLATION("memory allocation failed, heap is locked", 40, 129, 48, 89, 190, 57, 139, 61, 37, 68, 29, 50, 172, 35, 26, 170, 77, 30, 16, 253, 41, 64) // memory allocation failed, heap is locked
TRANSLATION("memoryview: length is not a multiple of itemsize", 48, 129, 48, 89, 191, 117, 73, 189, 188, 26, 152, 83, 76, 62, 12, 58, 233, 128, 149, 226, 72) // memoryview: length is not a multiple of itemsize
TRANSLATION("mode must be complete, or reduced", 33, 235, 183, 250, 155, 58, 245, 108, 49, 56, 214, 173, 162, 83, 165, 0) // mode must be complete, or reduced
TRANSLATION("more degrees of freedom than data points", 40, 130, 203, 104, 77, 75, 105, 44, 55, 109, 165, 11, 131, 19, 53, 20, 140, 35, 91, 204, 32) // more degrees of freedom than data points
TRANSLATION("multiple *x in assignment", 25, 248, 7, 155, 176, 30, 6, 47, 154, 13, 16) // multiple *x in assignment
TRANSLATION("multiple bases have instance lay-out conflict", 45, 248, 3, 70, 36, 144, 211, 186, 219, 215, 13, 9, 219, 124, 215, 241, 245, 129, 226, 119, 222, 96) // multiple bases have instance lay-out conflict
TRANSLATION("must use keyword argument for key function", 42, 130, 91, 155, 65, 238, 140, 236, 17, 212, 77, 241, 211, 215) // must use keyword argument for key function
TRANSLATION("name '%q' is not defined", 24, 132, 208, 55, 62, 116, 252, 41, 168, 75, 175, 37, 0) // name \'%q\' is not defined
TRANSLATION("need more than %d values to unpack", 34, 133, 52, 224, 178, 219, 52, 225, 192, 30, 18, 197, 150, 24, 253, 112) // need more than %d values to unpack
TRANSLATION("negative shift count", 20, 133, 53, 41, 42, 235, 101, 85, 78, 176, 31, 178, 192) // negative shift count
TRANSLATION("no SD card", 10, 133, 99, 253, 0) // no SD card
TRANSLATION("no active exception to reraise", 30, 133, 96, 199, 98, 174, 183, 164, 116, 199, 175, 139, 110, 67, 40, 146) // no active exception to reraise
TRANSLATION("no binding for nonlocal found", 29, 133, 97, 167, 145, 91, 4, 67, 19, 235, 63, 45, 222, 202, 0) // no binding for nonlocal found
TRANSLATION("no default packer", 17, 133, 99, 240, 136, 253, 119, 0) // no default packer
TRANSLATION("no module named '%q'", 20, 133, 99, 175, 45, 129, 9, 160, 167, 62, 116, 240) // no module named \'%q\'
TRANSLATION("no reset pin available", 22, 133, 98, 223, 108, 70, 240, 251, 220, 160) // no reset pin available
TRANSLATION("no response from SD card", 24, 133, 98, 217, 71, 17, 55, 248, 191, 208) // no response from SD card
TRANSLATION("non-Device in %q", 16, 134, 44, 125, 250, 110, 168, 237, 188, 39, 0) // non-Device in %q
TRANSLATION("non-default argument follows default argument", 45, 134, 44, 127, 194, 51, 131, 171, 125, 245, 222, 33, 248, 70, 112) // non-default argument follows default argument
TRANSLATION("non-hex digit found", 19, 134, 44, 122, 186, 65, 10, 169, 92, 59, 217, 64) // non-hex digit found
TRANSLATION("non-keyword arg after */**", 26, 134, 44, 127, 116, 115, 193, 157, 99, 131, 205, 220, 249, 190, 104) // non-keyword arg after */**
TRANSLATION("non-keyword arg after keyword arg", 33, 134, 44, 127, 116, 115, 193, 157, 99, 131, 221, 28, 240) // non-keyword arg after keyword arg
TRANSLATION("non-zero timeout must be >= interval", 36, 134, 44, 127, 19, 139, 29, 212, 235, 76, 244, 183, 161, 230, 57, 116, 207, 128) // non-zero timeout must be >= interval
TRANSLATION("not a 128-bit UUID", 18, 248, 140, 55, 91, 191, 71, 29, 170, 227, 253, 64) // not a 128-bit UUID
TRANSLATION("not all arguments converted during string formatting", 52, 248, 185, 131, 56, 129, 226, 186, 227, 41, 162, 89, 43, 11, 146, 86, 193, 235, 50, 176) // not all arguments converted during string formatting
TRANSLATION("not enough arguments for format string", 38, 248, 180, 23, 45, 74, 163, 56, 176, 112, 122, 194, 228, 149, 128) // not enough arguments for format string
TRANSLATION("number of points must be at least 2", 35, 253, 110, 97, 198, 183, 152, 83, 41, 11, 6, 184, 55, 96) // number of points must be at least 2
TRANSLATION("object ", 7, 236, 0) // object 
TRANSLATION("object '%s' isn't a tuple or list", 33, 236, 15, 169, 133, 240, 152, 51, 193, 96, 90, 125, 87, 0) // object \'%s\' isn\'t a tuple or list
TRANSLATION("object not in sequence", 22, 236, 77, 120, 23, 181, 160, 116, 128) // object not in sequence
TRANSLATION("object of type '%s' has no len()", 32, 236, 97, 247, 135, 212, 26, 100, 33, 88, 177, 15, 152) // object of type \'%s\' has no len()
TRANSLATION("object with buffer protocol required", 36, 236, 109, 67, 93, 241, 28, 139, 98, 253, 159, 33, 0) // object with buffer protocol required
TRANSLATION("odd-length string", 17, 90, 17, 143, 168, 46, 73, 88) // odd-length string
TRANSLATION("offset is too large", 19, 91, 174, 246, 240, 188, 167, 249, 233) // offset is too large
TRANSLATION("offset must be non-negative and no greater than buffer length", 61, 91, 174, 246, 230, 67, 22, 60, 41, 169, 73, 87, 91, 230, 194, 177, 82, 221, 39, 49, 51, 90, 239, 141, 64) // offset must be non-negative and no greater than buffer length
TRANSLATION("offset out of bounds", 20, 91, 174, 246, 198, 182, 27, 93, 148, 16) // offset out of bounds
TRANSLATION("only slices with step=1 (aka None) are supported", 48, 139, 170, 94, 242, 75, 106, 46, 38, 61, 238, 232, 109, 205, 212, 48, 225, 196, 157, 192, 53, 177, 220) // only slices with step=1 (aka None) are supported
TRANSLATION("opcode", 6, 92, 103, 90, 18) // opcode
TRANSLATION("operands could not be broadcast together", 40, 92, 110, 26, 20, 16, 63, 201, 53, 166, 218, 145, 102, 65, 205, 112, 49, 117, 18, 202, 174, 0) // operands could not be broadcast together
TRANSLATION("operation is defined for 2D arrays only", 39, 92, 110, 82, 84, 88, 65, 9, 117, 234, 110, 218, 221, 239, 198, 121, 8, 159, 190) // operation is defined for 2D arrays only
TRANSLATION("operation is defined for ndarrays only", 38, 92, 110, 82, 84, 88, 65, 9, 117, 234, 110, 218, 133, 25, 228, 34, 126, 248) // operation is defined for ndarrays only
TRANSLATION("operation is implemented for 1D Boolean arrays only", 51, 92, 110, 82, 84, 88, 67, 243, 96, 141, 214, 252, 100, 173, 118, 51, 115, 200, 68, 253, 240) // operation is implemented for 1D Boolean arrays only
TRANSLATION("operation is not implemented on ndarrays", 40, 92, 110, 82, 84, 88, 83, 127, 48, 136, 66, 140, 242) // operation is not implemented on ndarrays
TRANSLATION("operation is not supported for given type", 41, 92, 110, 82, 84, 88, 83, 123, 152, 35, 241, 142, 240) // operation is not supported for given type
TRANSLATION("ord() expected a character, but string of length %d found", 57, 178, 143, 48, 105, 71, 210, 166, 96, 127, 200, 230, 51, 82, 176, 92, 146, 182, 30, 166, 0, 119, 178, 128) // ord() expected a character, but string of length %d found
TRANSLATION("out array is too small", 22, 214, 25, 248, 94, 81, 65, 204) // out array is too small
TRANSLATION("out must be a float dense array", 31, 214, 152, 96, 235, 235, 164, 17, 160, 77, 231, 128) // out must be a float dense array
TRANSLATION("out of range of source", 22, 214, 195, 249, 91, 91, 163, 248, 164) // out of range of source
TRANSLATION("out of range of target", 22, 214, 195, 249, 91, 91, 161, 156, 244, 176) // out of range of target
TRANSLATION("overflow converting long int to machine word", 44, 93, 215, 29, 125, 119, 129, 226, 186, 227, 43, 7, 226, 168, 30, 102, 44, 6, 61, 87, 155, 189, 101, 0) // overflow converting long int to machine word
TRANSLATION("palette_index should be an int", 30, 140, 214, 24, 196, 209, 121, 26, 95, 75, 53, 230, 0) // palette_index should be an int
TRANSLATION("pixel coordinates out of bounds", 31, 253, 160, 235, 178, 135, 169, 36, 134, 182, 27, 93, 148, 16) // pixel coordinates out of bounds
TRANSLATION("pixel value requires too many bits", 34, 253, 163, 195, 228, 23, 149, 1, 161, 190, 26, 174, 64) // pixel value requires too many bits
TRANSLATION("pixel_shader must be displayio.Palette or displayio.ColorConverter", 66, 253, 180, 75, 77, 14, 76, 71, 231, 82, 232, 113, 141, 97, 140, 110, 210, 63, 58, 151, 67, 41, 111, 217, 202, 138, 235, 140, 112) // pixel_shader must be displayio.Palette or displayio.ColorConverter
TRANSLATION("pop from empty %q", 17, 141, 113, 143, 196, 157, 86, 95, 19, 128) // pop from empty %q
TRANSLATION("pow() 3rd argument cannot be 0", 30, 141, 119, 188, 193, 231, 200, 129, 156, 15, 206, 105, 188, 128) // pow() 3rd argument cannot be 0
TRANSLATION("pow() with 3 arguments requires integers", 40, 141, 119, 188, 205, 168, 243, 198, 113, 121, 4, 30, 98, 106, 56, 64) // pow() with 3 arguments requires integers
TRANSLATION("pull masks conflict with direction masks", 40, 142, 87, 223, 16, 24, 186, 132, 15, 19, 190, 243, 54, 161, 10, 182, 125, 113, 1, 139, 168, 64) // pull masks conflict with direction masks
TRANSLATION("raw f-strings are not supported", 31, 144, 215, 131, 184, 247, 36, 172, 64, 214, 230, 247, 0) // raw f-strings are not supported
TRANSLATION("real and imaginary parts must be of equal length", 48, 183, 203, 230, 170, 3, 84, 120, 210, 95, 17, 154, 70, 20, 197, 186, 61, 174, 94, 160) // real and imaginary parts must be of equal length
TRANSLATION("requested length %d but object has length %d", 44, 183, 251, 229, 77, 202, 122, 152, 1, 169, 88, 59, 3, 76, 134, 166, 0) // requested length %d but object has length %d
TRANSLATION("results cannot be cast to specified type", 40, 182, 82, 190, 194, 7, 231, 52, 217, 205, 115, 23, 231, 167, 222) // results cannot be cast to specified type
TRANSLATION("rgb_pins[%d] duplicates another pin assignment", 46, 146, 163, 84, 99, 120, 191, 227, 109, 255, 33, 30, 15, 122, 146, 72, 26, 21, 178, 171, 130, 55, 129, 139, 230, 131, 68) // rgb_pins[%d] duplicates another pin assignment
TRANSLATION("rgb_pins[%d] is not on the same port as clock", 45, 146, 163, 84, 99, 120, 191, 227, 109, 255, 56, 83, 98, 196, 108, 141, 3, 113, 217, 96, 49, 3, 254, 144) // rgb_pins[%d] is not on the same port as clock
TRANSLATION("roll argument must be an ndarray", 32, 145, 111, 190, 51, 166, 102, 194, 140, 240) // roll argument must be an ndarray
TRANSLATION("rsplit(None,n)", 14, 144, 163, 126, 190, 223, 135, 18, 127, 243, 14, 224) // rsplit(None,n)
TRANSLATION("sample_source buffer must be a bytearray or array of type 'h', 'H', 'b' or 'B'", 78, 35, 106, 216, 163, 252, 91, 107, 191, 48, 195, 161, 158, 45, 103, 225, 247, 132, 250, 179, 241, 167, 253, 121, 248, 211, 218, 158, 45, 79, 201, 158) // sample_source buffer must be a bytearray or array of type \'h\', \'H\', \'b\' or \'B\'
TRANSLATION("sampling rate out of range", 26, 35, 106, 191, 88, 73, 73, 189, 108, 63, 149, 32) // sampling rate out of range
TRANSLATION("shape must be a tuple", 21, 45, 56, 219, 253, 77, 152, 51, 193, 96) // shape must be a tuple
TRANSLATION("short read", 10, 42, 182, 88, 45, 153, 0) // short read
TRANSLATION("sign not allowed in string format specifier", 43, 249, 166, 243, 23, 122, 155, 194, 228, 149, 176, 122, 195, 231, 112) // sign not allowed in string format specifier
TRANSLATION("sign not allowed with integer format specifier 'c'", 50, 249, 166, 243, 23, 122, 157, 234, 245, 67, 204, 77, 71, 48, 122, 195, 231, 112, 79, 60, 240) // sign not allowed with integer format specifier \'c\'
TRANSLATION("single '}' encountered in format string", 39, 42, 214, 4, 255, 255, 167, 141, 3, 246, 88, 229, 55, 176, 122, 194, 228, 149, 128) // single \'}\' encountered in format string
TRANSLATION("size is defined for ndarrays only", 33, 37, 120, 155, 81, 4, 37, 215, 169, 187, 106, 20, 103, 144, 137, 251, 224) // size is defined for ndarrays only
TRANSLATION("sleep length must be non-negative", 33, 43, 9, 140, 106, 76, 134, 44, 120, 83, 82, 146, 174, 164) // sleep length must be non-negative
TRANSLATION("slice step cannot be zero", 25, 47, 121, 187, 137, 140, 31, 156, 211, 126, 39, 22) // slice step cannot be zero
TRANSLATION("small int overflow", 18, 40, 57, 129, 230, 5, 221, 113, 215, 215, 120) // small int overflow
TRANSLATION("soft reboot\n", 13, 37, 186, 193, 109, 165, 173, 155, 32) // soft reboot\r\n
TRANSLATION("sort argument must be an ndarray", 32, 43, 44, 25, 211, 51, 97, 70, 120) // sort argument must be an ndarray
TRANSLATION("sos array must be of shape (n_section, 6)", 41, 37, 144, 207, 152, 183, 65, 105, 198, 222, 222, 26, 37, 210, 84, 88, 223, 87, 112) // sos array must be of shape (n_section, 6)
TRANSLATION("sos[:, 3] should be all ones", 28, 37, 151, 252, 111, 49, 188, 255, 249, 250, 92, 193, 18, 72) // sos[:, 3] should be all ones
TRANSLATION("sosfilt requires iterable arguments", 35, 37, 147, 170, 125, 158, 65, 10, 238, 114, 134, 113, 0) // sosfilt requires iterable arguments
TRANSLATION("source palette too large", 24, 254, 45, 198, 107, 12, 99, 108, 90, 195, 252, 244, 128) // source palette too large
TRANSLATION("source_bitmap must have value_count of 2 or 65536", 49, 254, 41, 163, 236, 108, 244, 238, 183, 225, 162, 126, 203, 48, 247, 98, 215, 247, 128) // source_bitmap must have value_count of 2 or 65536
TRANSLATION("source_bitmap must have value_count of 65536", 44, 254, 41, 163, 236, 108, 244, 238, 183, 225, 162, 126, 203, 48, 255, 188) // source_bitmap must have value_count of 65536
TRANSLATION("source_bitmap must have value_count of 8", 40, 254, 41, 163, 236, 108, 244, 238, 183, 225, 162, 126, 203, 48, 253, 16) // source_bitmap must have value_count of 8
TRANSLATION("start/end indices", 17, 184, 105, 25, 185, 208, 64, 121, 10, 58, 72) // start/end indices
TRANSLATION("start_x should be an int", 24, 184, 105, 25, 71, 99, 233, 102, 188, 192) // start_x should be an int
TRANSLATION("step must be non-zero", 21, 184, 152, 230, 67, 22, 63, 137, 197, 128) // step must be non-zero
TRANSLATION("stop not reachable from start", 29, 184, 184, 230, 219, 49, 244, 218, 176, 63, 21, 195, 72, 192) // stop not reachable from start
TRANSLATION("stream operation not supported", 30, 185, 108, 208, 5, 198, 229, 37, 69, 55, 184) // stream operation not supported
TRANSLATION("string indices must be integers, not %q", 39, 185, 37, 96, 242, 20, 116, 148, 199, 152, 154, 142, 22, 55, 197, 56) // string indices must be integers, not %q
TRANSLATION("string not supported; use bytes or bytearray", 44, 185, 37, 105, 189, 207, 241, 218, 14, 129, 11, 93, 12, 240) // string not supported; use bytes or bytearray
TRANSLATION("substring not found", 19, 41, 90, 185, 37, 105, 174, 246, 80) // substring not found
TRANSLATION("super() can't find self", 23, 47, 3, 158, 96, 232, 186, 242, 1, 37, 247, 64) // super() can\'t find self
TRANSLATION("syntax error in JSON", 20, 43, 240, 176, 219, 1, 201, 45, 60, 63, 251, 228, 113, 120, 96) // syntax error in JSON
TRANSLATION("threshold must be in the range 0-65536", 38, 101, 91, 101, 85, 111, 162, 99, 216, 141, 252, 173, 228, 99, 255, 120) // threshold must be in the range 0-65536
TRANSLATION("time.struct_time() takes a 9-sequence", 37, 238, 166, 133, 201, 37, 59, 40, 247, 83, 230, 6, 27, 168, 146, 6, 31, 225, 142, 94, 214, 129, 210) // time.struct_time() takes a 9-sequence
TRANSLATION("timeout duration exceeded the maximum supported value", 53, 238, 167, 88, 34, 89, 41, 42, 33, 164, 116, 165, 20, 217, 85, 184, 62, 255, 112, 120, 64) // timeout duration exceeded the maximum supported value
TRANSLATION("timeout must be 0.0-100.0 seconds", 33, 238, 167, 90, 102, 69, 12, 140, 125, 214, 70, 69, 12, 128, 73, 60, 72, 32) // timeout must be 0.0-100.0 seconds
TRANSLATION("timeout waiting for v1 card", 27, 238, 167, 88, 94, 53, 122, 216, 34, 238, 232, 28, 210, 32) // timeout waiting for v1 card
TRANSLATION("timeout waiting for v2 card", 27, 238, 167, 88, 94, 53, 122, 216, 34, 238, 236, 28, 210, 32) // timeout waiting for v2 card
TRANSLATION("timestamp out of range for platform time_t", 42, 238, 166, 225, 181, 70, 182, 31, 202, 219, 182, 163, 126, 147, 182, 96, 29, 212, 209, 96) // timestamp out of range for platform time_t
TRANSLATION("tobytes can be invoked for dense arrays only", 44, 98, 250, 4, 15, 154, 211, 111, 93, 95, 82, 155, 182, 145, 160, 77, 231, 144, 137, 251, 224) // tobytes can be invoked for dense arrays only
TRANSLATION("too many arguments provided with the given format", 49, 103, 236, 206, 33, 251, 169, 222, 175, 87, 17, 191, 199, 131, 214) // too many arguments provided with the given format
TRANSLATION("too many dimensions", 19, 103, 236, 66, 160, 208, 37, 68, 64) // too many dimensions
TRANSLATION("too many indices", 16, 103, 236, 121, 10, 58, 72) // too many indices
TRANSLATION("too many values to unpack (expected %d)", 39, 103, 236, 240, 150, 44, 176, 199, 235, 141, 190, 148, 125, 42, 123, 109, 192) // too many values to unpack (expected %d)
TRANSLATION("trapz is defined for 1D arrays of equal length", 46, 100, 134, 143, 197, 132, 16, 151, 94, 166, 237, 173, 214, 252, 103, 150, 31, 181, 203, 212) // trapz is defined for 1D arrays of equal length
TRANSLATION("trapz is defined for 1D iterables", 33, 100, 134, 143, 197, 132, 16, 151, 94, 166, 237, 173, 214, 252, 87, 115, 148, 64) // trapz is defined for 1D iterables
TRANSLATION("tx and rx cannot both be None", 29, 102, 192, 230, 201, 176, 15, 206, 105, 108, 170, 26, 111, 135, 18, 64) // tx and rx cannot both be None
TRANSLATION("type '%q' is not an acceptable base type", 40, 239, 9, 243, 167, 225, 77, 205, 49, 206, 152, 217, 202, 13, 24, 155, 239, 0) // type \'%q\' is not an acceptable base type
TRANSLATION("type is not an acceptable base type", 35, 239, 97, 77, 205, 49, 206, 152, 217, 202, 13, 24, 155, 239, 0) // type is not an acceptable base type
TRANSLATION("type object '%q' has no attribute '%q'", 38, 239, 14, 192, 159, 58, 120, 211, 33, 10, 197, 47, 230, 220, 249, 211, 192) // type object \'%q\' has no attribute \'%q\'
TRANSLATION("type object 'generator' has no attribute '__await__'", 52, 239, 14, 192, 159, 83, 65, 202, 86, 103, 141, 50, 16, 172, 82, 254, 109, 207, 163, 68, 215, 141, 94, 141, 25, 224) // type object \'generator\' has no attribute \'__await__\'
TRANSLATION("type takes 1 or 3 arguments", 27, 239, 6, 27, 168, 146, 27, 161, 107, 207, 25, 196) // type takes 1 or 3 arguments
TRANSLATION("unexpected indent", 17, 150, 29, 40, 250, 84, 222, 70, 136) // unexpected indent
TRANSLATION("unexpected keyword argument '%q'", 32, 150, 29, 40, 250, 84, 253, 209, 156, 39, 206, 158) // unexpected keyword argument \'%q\'
TRANSLATION("unicode name escapes", 20, 150, 21, 29, 104, 110, 19, 64, 218, 72, 230, 141, 36) // unicode name escapes
TRANSLATION("unindent doesn't match any outer indent level", 45, 150, 23, 145, 163, 227, 252, 62, 248, 52, 55, 198, 179, 129, 228, 104, 139, 23, 82, 248) // unindent doesn\'t match any outer indent level
TRANSLATION("unknown format code '%c' for object of type '%q'", 48, 151, 254, 240, 122, 192, 235, 67, 115, 252, 179, 207, 193, 29, 140, 62, 240, 159, 58, 120) // unknown format code \'%c\' for object of type \'%q\'
TRANSLATION("unmatched '{' in format", 23, 150, 31, 126, 156, 255, 255, 103, 135, 176, 122, 192) // unmatched \'{\' in format
TRANSLATION("unreadable attribute", 20, 150, 27, 102, 71, 40, 82, 254, 105) // unreadable attribute
TRANSLATION("unsupported %q type", 19, 150, 30, 224, 156, 59, 192) // unsupported %q type
TRANSLATION("unsupported colorspace for GifWriter", 36, 150, 30, 224, 246, 108, 148, 102, 59, 110, 218, 244, 212, 239, 173, 37, 119, 0) // unsupported colorspace for GifWriter
TRANSLATION("unsupported colorspace for dither", 33, 150, 30, 224, 246, 108, 148, 102, 59, 110, 218, 69, 122, 174, 0) // unsupported colorspace for dither
TRANSLATION("unsupported format character '%c' (0x%x) at index %d", 52, 150, 30, 230, 15, 88, 31, 242, 56, 39, 249, 103, 158, 54, 249, 27, 30, 94, 198, 224, 82, 15, 35, 75, 0) // unsupported format character \'%c\' (0x%x) at index %d
TRANSLATION("unsupported type for %q: '%q'", 29, 150, 30, 224, 239, 96, 137, 219, 193, 62, 116, 240) // unsupported type for %q: \'%q\'
TRANSLATION("unsupported types for %q: '%q', '%q'", 36, 150, 30, 224, 239, 22, 8, 157, 188, 19, 231, 79, 198, 159, 58, 120) // unsupported types for %q: \'%q\', \'%q\'
TRANSLATION("value must fit in %d byte(s)", 28, 240, 236, 221, 174, 30, 192, 29, 13, 185, 110, 0) // value must fit in %d byte(s)
TRANSLATION("value out of range of target", 28, 240, 141, 108, 63, 149, 181, 186, 25, 207, 75, 0) // value out of range of target
TRANSLATION("value_count must be > 0", 23, 240, 209, 63, 101, 147, 61, 33, 144) // value_count must be > 0
TRANSLATION("watchdog timeout must be greater than 0", 39, 189, 72, 245, 80, 186, 131, 186, 157, 105, 149, 45, 210, 115, 19, 55, 32) // watchdog timeout must be greater than 0
TRANSLATION("window must be <= interval", 26, 188, 242, 23, 122, 103, 214, 222, 135, 152, 229, 211, 62) // window must be <= interval
TRANSLATION("wrong axis index", 16, 189, 36, 85, 1, 182, 20, 65, 228, 105, 0) // wrong axis index
TRANSLATION("wrong axis specified", 20, 189, 36, 85, 1, 182, 20, 67, 231, 74, 0) // wrong axis specified
TRANSLATION("wrong input type", 16, 189, 36, 85, 3, 221, 161, 222) // wrong input type
TRANSLATION("wrong length of condition array", 31, 189, 36, 85, 6, 166, 25, 226, 69, 117, 68, 51, 192) // wrong length of condition array
TRANSLATION("wrong number of arguments", 25, 189, 36, 85, 7, 235, 115, 15, 56, 128) // wrong number of arguments
TRANSLATION("wrong output type", 17, 189, 36, 85, 6, 183, 104, 119, 128) // wrong output type
TRANSLATION("x value out of bounds", 21, 216, 30, 17, 173, 134, 215, 101, 4) // x value out of bounds
TRANSLATION("y should be an int", 18, 191, 244, 179, 94, 96) // y should be an int
TRANSLATION("y value out of bounds", 21, 190, 60, 35, 91, 13, 174, 202, 8) // y value out of bounds
TRANSLATION("zero step", 9, 241, 56, 177, 113, 49, 128) // zero step
TRANSLATION("zi must be an ndarray", 21, 241, 42, 102, 108, 40, 207) // zi must be an ndarray
TRANSLATION("zi must be of float type", 24, 241, 42, 98, 221, 14, 190, 186, 67, 188) // zi must be of float type
TRANSLATION("zi must be of shape (n_section, 2)", 34, 241, 42, 98, 221, 5, 167, 27, 123, 120, 104, 151, 73, 81, 99, 110, 247, 0) // zi must be of shape (n_section, 2)

// 12886 bytes worth of qstr
// 22584 bytes worth of translations
// 10673 bytes worth of translations compressed
// 11911 bytes saved
