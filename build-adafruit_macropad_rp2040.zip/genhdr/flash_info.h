// This file is auto-generated using gen_stage2.py

#pragma once

#define FLASH_DEFAULT_POWER_OF_TWO 21